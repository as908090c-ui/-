DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_sessions','visitor_commands','blocked_visitors','chat_blocked_visitors','sms_logs','sms_settings','telegram_settings'] LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
END $$;

DROP POLICY IF EXISTS "realtime_read_all" ON realtime.messages;
CREATE POLICY "realtime_read_all" ON realtime.messages FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "visitor_uploads_admin_all" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_select" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_insert" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_update" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_delete" ON storage.objects;

CREATE POLICY "visitor_uploads_admin_all" ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'visitor-uploads' AND public.is_admin_user())
WITH CHECK (bucket_id = 'visitor-uploads' AND public.is_admin_user());

CREATE POLICY "visitor_uploads_owner_select" ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'visitor-uploads' AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id());

CREATE POLICY "visitor_uploads_owner_insert" ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'visitor-uploads' AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id());

CREATE POLICY "visitor_uploads_owner_update" ON storage.objects FOR UPDATE TO anon, authenticated
USING (bucket_id = 'visitor-uploads' AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id())
WITH CHECK (bucket_id = 'visitor-uploads' AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id());

CREATE POLICY "visitor_uploads_owner_delete" ON storage.objects FOR DELETE TO anon, authenticated
USING (bucket_id = 'visitor-uploads' AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id());