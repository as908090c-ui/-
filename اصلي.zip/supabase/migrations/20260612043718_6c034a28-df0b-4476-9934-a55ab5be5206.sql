-- Recreate visitor_sessions with the columns the app uses
DROP TABLE IF EXISTS public.visitor_sessions CASCADE;
CREATE TABLE public.visitor_sessions (
  visitor_id TEXT PRIMARY KEY,
  last_path TEXT,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  country TEXT,
  country_code TEXT,
  city TEXT,
  ip TEXT,
  is_mobile BOOLEAN,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO authenticated, anon;
GRANT ALL ON public.visitor_sessions TO service_role;
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_sessions REPLICA IDENTITY FULL;
CREATE POLICY "vs_all" ON public.visitor_sessions FOR ALL USING (true) WITH CHECK (true);
DO $$ BEGIN
  BEGIN EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.visitor_sessions';
  EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;

-- Add missing telegram_settings columns
ALTER TABLE public.telegram_settings
  ADD COLUMN IF NOT EXISTS send_live_card BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS send_steps BOOLEAN NOT NULL DEFAULT true;