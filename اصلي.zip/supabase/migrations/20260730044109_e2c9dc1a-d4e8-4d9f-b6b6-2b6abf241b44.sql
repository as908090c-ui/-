
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _email text;
BEGIN
  BEGIN _email := lower(coalesce(auth.jwt() ->> 'email', '')); EXCEPTION WHEN OTHERS THEN _email := ''; END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN _email IN ('aa809077a@gmail.com');
END; $$;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE _vid text;
BEGIN
  BEGIN _vid := current_setting('request.headers', true)::json ->> 'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN _vid := NULL; END;
  RETURN _vid;
END; $$;
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated;

DROP POLICY IF EXISTS anon_all_applications ON public.applications;
DROP POLICY IF EXISTS anon_all_sessions     ON public.visitor_sessions;
DROP POLICY IF EXISTS anon_all_commands     ON public.visitor_commands;
DROP POLICY IF EXISTS anon_all_blocked      ON public.blocked_visitors;
DROP POLICY IF EXISTS anon_all_conv         ON public.chat_conversations;
DROP POLICY IF EXISTS anon_all_msg          ON public.chat_messages;
DROP POLICY IF EXISTS anon_all_sms_settings ON public.sms_settings;
DROP POLICY IF EXISTS anon_all_sms_logs     ON public.sms_logs;
DROP POLICY IF EXISTS anon_all_tg           ON public.telegram_settings;

CREATE POLICY apps_admin_select   ON public.applications FOR SELECT USING (public.is_admin_user());
CREATE POLICY apps_admin_delete   ON public.applications FOR DELETE USING (public.is_admin_user());
CREATE POLICY apps_visitor_insert ON public.applications FOR INSERT
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_visitor_update ON public.applications FOR UPDATE
  USING      (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()))
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));

CREATE POLICY vs_admin_select ON public.visitor_sessions FOR SELECT USING (public.is_admin_user());
CREATE POLICY vs_admin_delete ON public.visitor_sessions FOR DELETE USING (public.is_admin_user());
CREATE POLICY vs_self_insert  ON public.visitor_sessions FOR INSERT
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY vs_self_update  ON public.visitor_sessions FOR UPDATE
  USING      (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()))
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));

CREATE POLICY vc_select        ON public.visitor_commands FOR SELECT
  USING (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY vc_admin_insert  ON public.visitor_commands FOR INSERT WITH CHECK (public.is_admin_user());
CREATE POLICY vc_admin_delete  ON public.visitor_commands FOR DELETE USING (public.is_admin_user());
CREATE POLICY vc_admin_update  ON public.visitor_commands FOR UPDATE USING (public.is_admin_user()) WITH CHECK (public.is_admin_user());

CREATE POLICY bv_select        ON public.blocked_visitors FOR SELECT
  USING (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY bv_admin_insert  ON public.blocked_visitors FOR INSERT WITH CHECK (public.is_admin_user());
CREATE POLICY bv_admin_delete  ON public.blocked_visitors FOR DELETE USING (public.is_admin_user());
CREATE POLICY bv_admin_update  ON public.blocked_visitors FOR UPDATE USING (public.is_admin_user()) WITH CHECK (public.is_admin_user());

CREATE POLICY cc_select ON public.chat_conversations FOR SELECT
  USING (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY cc_insert ON public.chat_conversations FOR INSERT
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY cc_update ON public.chat_conversations FOR UPDATE
  USING      (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()))
  WITH CHECK (public.is_admin_user() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY cc_admin_delete ON public.chat_conversations FOR DELETE USING (public.is_admin_user());

CREATE POLICY cm_select ON public.chat_messages FOR SELECT
  USING (public.is_admin_user() OR EXISTS (
    SELECT 1 FROM public.chat_conversations c
    WHERE c.id = chat_messages.conversation_id AND c.visitor_id IS NOT NULL AND c.visitor_id = public.current_visitor_id()
  ));
CREATE POLICY cm_insert ON public.chat_messages FOR INSERT
  WITH CHECK (public.is_admin_user() OR EXISTS (
    SELECT 1 FROM public.chat_conversations c
    WHERE c.id = chat_messages.conversation_id AND c.visitor_id IS NOT NULL AND c.visitor_id = public.current_visitor_id()
  ));
CREATE POLICY cm_admin_delete ON public.chat_messages FOR DELETE USING (public.is_admin_user());

CREATE POLICY sms_settings_admin ON public.sms_settings FOR ALL USING (public.is_admin_user()) WITH CHECK (public.is_admin_user());
CREATE POLICY sms_logs_admin     ON public.sms_logs     FOR ALL USING (public.is_admin_user()) WITH CHECK (public.is_admin_user());
CREATE POLICY tg_admin           ON public.telegram_settings FOR ALL USING (public.is_admin_user()) WITH CHECK (public.is_admin_user());

DROP POLICY IF EXISTS "admin_controls_admin_only" ON realtime.messages;
CREATE POLICY "admin_controls_admin_only" ON realtime.messages FOR ALL TO authenticated
  USING (realtime.topic() = 'admin-controls' AND public.is_admin_user())
  WITH CHECK (realtime.topic() = 'admin-controls' AND public.is_admin_user());
