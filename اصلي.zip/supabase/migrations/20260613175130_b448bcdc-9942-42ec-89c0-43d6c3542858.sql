CREATE OR REPLACE FUNCTION public.is_current_admin()
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  _token text;
  _email text;
BEGIN
  -- 1) Custom admin-token session header
  BEGIN
    _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN _token := NULL; END;
  IF _token IS NOT NULL AND length(_token) > 0 AND public.is_admin_token(_token) THEN
    RETURN true;
  END IF;

  -- 2) Supabase Auth user whose email is in the allowlist
  BEGIN
    _email := lower(coalesce(auth.jwt() ->> 'email', ''));
  EXCEPTION WHEN OTHERS THEN _email := ''; END;

  IF _email IN ('aa809077a@gmail.com') THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$function$