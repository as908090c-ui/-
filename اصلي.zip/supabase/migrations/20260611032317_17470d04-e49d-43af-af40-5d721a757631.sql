CREATE OR REPLACE FUNCTION public.admin_login(_password text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  _hash text;
  _token text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR extensions.crypt(_password, _hash) <> _hash THEN
    RETURN NULL;
  END IF;
  _token := encode(gen_random_bytes(32), 'hex');
  INSERT INTO public.admin_sessions(token) VALUES (_token);
  DELETE FROM public.admin_sessions WHERE expires_at < now();
  RETURN _token;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_change_password(_current text, _new text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  _hash text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR extensions.crypt(_current, _hash) <> _hash THEN
    RETURN false;
  END IF;
  IF length(_new) < 4 THEN
    RETURN false;
  END IF;
  UPDATE public.admin_credentials
     SET password_hash = extensions.crypt(_new, extensions.gen_salt('bf')),
         updated_at = now()
   WHERE id = true;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_generate_recovery_code(_current_password text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  _hash text;
  _code text;
  _alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  _i int;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR extensions.crypt(_current_password, _hash) <> _hash THEN
    RETURN NULL;
  END IF;

  _code := '';
  FOR _i IN 1..20 LOOP
    _code := _code || substr(_alphabet, 1 + (get_byte(gen_random_bytes(1), 0) % length(_alphabet))::int, 1);
    IF _i % 4 = 0 AND _i < 20 THEN
      _code := _code || '-';
    END IF;
  END LOOP;

  UPDATE public.admin_credentials
     SET recovery_code_hash = extensions.crypt(_code, extensions.gen_salt('bf')),
         updated_at = now()
   WHERE id = true;

  RETURN _code;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_reset_with_recovery(_code text, _new_password text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  _rec_hash text;
  _trimmed_code text;
BEGIN
  IF _new_password IS NULL OR length(_new_password) < 8 THEN
    RETURN false;
  END IF;

  _trimmed_code := upper(regexp_replace(coalesce(_code,''), '\s', '', 'g'));
  IF length(_trimmed_code) < 8 THEN
    RETURN false;
  END IF;

  SELECT recovery_code_hash INTO _rec_hash FROM public.admin_credentials WHERE id = true;
  IF _rec_hash IS NULL OR extensions.crypt(_trimmed_code, _rec_hash) <> _rec_hash THEN
    RETURN false;
  END IF;

  UPDATE public.admin_credentials
     SET password_hash = extensions.crypt(_new_password, extensions.gen_salt('bf')),
         recovery_code_hash = NULL,
         updated_at = now()
   WHERE id = true;

  DELETE FROM public.admin_sessions;
  RETURN true;
END;
$$;

UPDATE public.admin_credentials
   SET password_hash = extensions.crypt('REDACTED_PASSWORD_REMOVED', extensions.gen_salt('bf')),
       updated_at = now()
 WHERE id = true;

GRANT EXECUTE ON FUNCTION public.admin_login(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_change_password(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_reset_with_recovery(text,text) TO anon, authenticated;