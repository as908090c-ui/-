-- Allow Google-authenticated admins (per is_admin_user email allowlist) to
-- pass the is_current_admin() check used by RLS policies, in addition to the
-- legacy x-admin-token header path.
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_current_admin()
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _token text;
  _email text;
BEGIN
  -- Google-authenticated admin path
  BEGIN
    _email := lower(coalesce(auth.jwt() ->> 'email', ''));
  EXCEPTION WHEN OTHERS THEN
    _email := '';
  END;
  IF _email IN ('aa809077a@gmail.com') THEN
    RETURN true;
  END IF;

  -- Legacy password admin path via x-admin-token header
  BEGIN
    _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN
    _token := NULL;
  END;
  IF _token IS NULL OR length(_token) = 0 THEN
    RETURN false;
  END IF;
  RETURN public.is_admin_token(_token);
END;
$$;