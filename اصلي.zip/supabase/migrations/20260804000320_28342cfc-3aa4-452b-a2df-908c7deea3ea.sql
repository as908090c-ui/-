-- Drop all policies on public tables
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT policyname, tablename FROM pg_policies WHERE schemaname = 'public'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- Drop all triggers in public
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT trigger_name, event_object_table FROM information_schema.triggers WHERE event_object_schema = 'public'
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON public.%I', r.trigger_name, r.event_object_table);
  END LOOP;
END $$;

-- Drop all tables in public
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
  LOOP
    EXECUTE format('DROP TABLE IF EXISTS public.%I CASCADE', r.table_name);
  END LOOP;
END $$;

-- Drop all functions in public
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT routine_name, pg_get_function_identity_arguments(p.oid) AS args
           FROM information_schema.routines i
           JOIN pg_proc p ON p.proname = i.routine_name
           WHERE i.routine_schema = 'public'
  LOOP
    EXECUTE format('DROP FUNCTION IF EXISTS public.%I(%s) CASCADE', r.routine_name, r.args);
  END LOOP;
END $$;