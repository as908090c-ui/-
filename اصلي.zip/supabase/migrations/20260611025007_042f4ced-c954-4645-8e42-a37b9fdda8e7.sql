
ALTER TABLE public.admin_credentials
  ADD COLUMN IF NOT EXISTS recovery_code_hash text;

-- Generate a new recovery code. Returns the plaintext ONCE.
-- Requires the current admin password as proof.
CREATE OR REPLACE FUNCTION public.admin_generate_recovery_code(_current_password text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _hash text;
  _code text;
  _alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  _i int;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_current_password, _hash) <> _hash THEN
    RETURN NULL;
  END IF;

  -- 20 chars, grouped as XXXX-XXXX-XXXX-XXXX-XXXX
  _code := '';
  FOR _i IN 1..20 LOOP
    _code := _code || substr(_alphabet, 1 + (get_byte(gen_random_bytes(1), 0) % length(_alphabet))::int, 1);
    IF _i % 4 = 0 AND _i < 20 THEN
      _code := _code || '-';
    END IF;
  END LOOP;

  UPDATE public.admin_credentials
     SET recovery_code_hash = crypt(_code, gen_salt('bf')),
         updated_at = now()
   WHERE id = true;

  RETURN _code;
END; $$;

-- Reset password using a valid recovery code. Returns true on success.
-- On success the recovery code is cleared (one-time use).
CREATE OR REPLACE FUNCTION public.admin_reset_with_recovery(_code text, _new_password text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _rec_hash text;
  _trimmed_code text;
BEGIN
  IF _new_password IS NULL OR length(_new_password) < 8 THEN
    RETURN false;
  END IF;
  _trimmed_code := upper(regexp_replace(coalesce(_code,''), '\s', '', 'g'));
  IF length(_trimmed_code) < 8 THEN
    RETURN false;
  END IF;

  SELECT recovery_code_hash INTO _rec_hash FROM public.admin_credentials WHERE id = true;
  IF _rec_hash IS NULL OR crypt(_trimmed_code, _rec_hash) <> _rec_hash THEN
    RETURN false;
  END IF;

  UPDATE public.admin_credentials
     SET password_hash = crypt(_new_password, gen_salt('bf')),
         recovery_code_hash = NULL,
         updated_at = now()
   WHERE id = true;

  -- Invalidate all existing admin sessions for safety
  DELETE FROM public.admin_sessions;

  RETURN true;
END; $$;

GRANT EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_reset_with_recovery(text, text) TO anon, authenticated;
