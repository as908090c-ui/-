DROP POLICY IF EXISTS apps_visitor_select ON public.applications;
DROP POLICY IF EXISTS apps_visitor_insert ON public.applications;
DROP POLICY IF EXISTS apps_visitor_update ON public.applications;

CREATE POLICY apps_visitor_select ON public.applications
  FOR SELECT
  USING (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );

CREATE POLICY apps_visitor_insert ON public.applications
  FOR INSERT
  WITH CHECK (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );

CREATE POLICY apps_visitor_update ON public.applications
  FOR UPDATE
  USING (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  )
  WITH CHECK (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );