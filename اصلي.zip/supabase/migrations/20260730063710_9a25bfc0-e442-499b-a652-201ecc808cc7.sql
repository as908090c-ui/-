-- =========================================================
-- 1) chat_blocked_visitors: remove wide-open policy
-- =========================================================
DROP POLICY IF EXISTS cbv_all ON public.chat_blocked_visitors;

CREATE POLICY cbv_admin_all ON public.chat_blocked_visitors
  FOR ALL
  USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

CREATE POLICY cbv_self_select ON public.chat_blocked_visitors
  FOR SELECT
  USING (
    public.is_admin_user()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );

REVOKE ALL ON public.chat_blocked_visitors FROM anon, authenticated;
GRANT SELECT ON public.chat_blocked_visitors TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_blocked_visitors TO authenticated;
GRANT ALL ON public.chat_blocked_visitors TO service_role;

-- =========================================================
-- 2) applications: hide sensitive columns from client reads
-- =========================================================
ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS card_last4 text;

UPDATE public.applications
SET card_last4 = right(regexp_replace(coalesce(card_number, ''), '\D', '', 'g'), 4)
WHERE card_last4 IS NULL AND card_number IS NOT NULL;

-- Drop blanket read privilege, then re-grant only non-sensitive columns.
REVOKE SELECT ON public.applications FROM anon, authenticated;

GRANT SELECT (
  id, created_at, visitor_id, full_name, identity, birth_date, phone,
  insurance_type, start_date, purpose, est_value, car_year, car_model,
  repair_place, company, type, price, total, method, status, review_status,
  card_brand, card_last4, mutasil_phone, mutasil_provider, mutasil_id,
  screenshot_urls
) ON public.applications TO anon, authenticated;

GRANT INSERT, UPDATE ON public.applications TO anon, authenticated;
GRANT DELETE ON public.applications TO authenticated;
GRANT ALL ON public.applications TO service_role;

-- Admin-only read path for the full record (guarded by is_admin_user()).
DROP VIEW IF EXISTS public.applications_admin;
CREATE VIEW public.applications_admin
WITH (security_invoker = false) AS
SELECT * FROM public.applications WHERE public.is_admin_user();

REVOKE ALL ON public.applications_admin FROM anon;
GRANT SELECT ON public.applications_admin TO authenticated;
GRANT SELECT ON public.applications_admin TO service_role;

-- =========================================================
-- 3) Harden visitor identity resolution (anti-spoofing)
-- =========================================================
CREATE OR REPLACE FUNCTION private.resolve_visitor_id()
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE _headers json; _token text; _vid text; _sig text; _sec bytea; _expected text; _dot int;
BEGIN
  BEGIN _headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN RETURN NULL; END;

  _token := _headers ->> 'x-visitor-token';
  IF _token IS NULL OR length(_token) <> 91 THEN RETURN NULL; END IF;

  _dot := position('.' in _token);
  IF _dot <> 27 THEN RETURN NULL; END IF;

  _vid := substring(_token from 1 for _dot - 1);
  _sig := substring(_token from _dot + 1);

  -- Strict format: V-<24 hex> . <64 hex>
  IF _vid !~ '^V-[0-9a-f]{24}$' OR _sig !~ '^[0-9a-f]{64}$' THEN RETURN NULL; END IF;

  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  IF _sec IS NULL THEN RETURN NULL; END IF;

  _expected := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  IF _sig = _expected THEN RETURN _vid; END IF;
  RETURN NULL;
END; $function$;

COMMENT ON FUNCTION private.resolve_visitor_id() IS
  'Visitor identity is derived ONLY from an HMAC-SHA256 signed token (x-visitor-token) minted server-side. Client-supplied visitor ids cannot be forged without the server secret.';