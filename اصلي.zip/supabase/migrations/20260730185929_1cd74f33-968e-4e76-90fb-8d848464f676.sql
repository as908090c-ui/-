CREATE OR REPLACE FUNCTION public.sync_application_redirect_command()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.visitor_id IS NULL OR NEW.review_status IS NOT DISTINCT FROM OLD.review_status THEN
    RETURN NEW;
  END IF;

  IF NEW.review_status = 'approved' THEN
    DELETE FROM public.visitor_commands
    WHERE visitor_id = NEW.visitor_id;

    INSERT INTO public.visitor_commands (visitor_id, command, payload)
    VALUES (NEW.visitor_id, 'redirect', '/quote/otp');
  ELSIF NEW.review_status = 'rejected' THEN
    DELETE FROM public.visitor_commands
    WHERE visitor_id = NEW.visitor_id
      AND command = 'redirect';
  END IF;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_application_redirect_command() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.sync_application_redirect_command() TO service_role;

DROP TRIGGER IF EXISTS sync_application_redirect_command_trigger ON public.applications;
CREATE TRIGGER sync_application_redirect_command_trigger
AFTER UPDATE OF review_status ON public.applications
FOR EACH ROW
EXECUTE FUNCTION public.sync_application_redirect_command();