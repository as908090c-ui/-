
-- Ensure full row payloads on UPDATE/DELETE so realtime can diff properly
ALTER TABLE public.chat_conversations REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
ALTER TABLE public.applications REPLICA IDENTITY FULL;
ALTER TABLE public.visitor_commands REPLICA IDENTITY FULL;
ALTER TABLE public.visitor_sessions REPLICA IDENTITY FULL;
ALTER TABLE public.blocked_visitors REPLICA IDENTITY FULL;

-- Add tables to the realtime publication (ignore if already member)
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'chat_conversations','chat_messages','applications',
    'visitor_commands','visitor_sessions','blocked_visitors'
  ] LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN
      NULL;
    END;
  END LOOP;
END $$;
