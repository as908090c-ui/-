-- 1) Lock down internal identity functions: only the owner/public wrappers may call them
REVOKE ALL ON FUNCTION private.resolve_visitor_id() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.mint_visitor_token() FROM PUBLIC, anon, authenticated;

-- 2) Public wrappers become SECURITY DEFINER so they can call the locked-down private functions
CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'private', 'public'
AS $function$
  SELECT private.resolve_visitor_id();
$function$;

CREATE OR REPLACE FUNCTION public.issue_visitor_token()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'private', 'public'
AS $function$
  SELECT private.mint_visitor_token();
$function$;

-- 3) Hard fail-closed guard: never return rows without a signature-verified visitor id
CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE(id text, created_at timestamp with time zone, visitor_id text, status text, review_status text, method text, card_brand text, card_last4 text, total numeric, price numeric, company text, insurance_type text, mutasil_provider text, mutasil_phone text, mutasil_id text, screenshot_urls text[])
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _vid text;
BEGIN
  _vid := public.current_visitor_id();
  IF _vid IS NULL OR _vid !~ '^V-[0-9a-f]{24}$' THEN
    RETURN;
  END IF;
  RETURN QUERY
    SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
           a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
           a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls
    FROM public.applications a
    WHERE a.visitor_id = _vid
    ORDER BY a.created_at DESC
    LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
END;
$function$;

-- 4) Minimum required grants on the only three publicly callable functions
REVOKE ALL ON FUNCTION public.current_visitor_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.issue_visitor_token() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_my_applications(integer) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.issue_visitor_token() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_applications(integer) TO anon, authenticated, service_role;