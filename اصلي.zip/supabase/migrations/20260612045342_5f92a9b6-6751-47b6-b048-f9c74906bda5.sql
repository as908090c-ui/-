
-- =====================================================================
-- Lock down all public-permissive RLS policies, scope to admin + visitor.
-- =====================================================================

-- Helper: admin check via Google OAuth email allowlist
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE sql STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT lower(coalesce(auth.jwt() ->> 'email', '')) = 'aa809077a@gmail.com'
$$;

-- Helper: read visitor id from request header (anon-friendly, SECURITY INVOKER)
CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text
LANGUAGE plpgsql STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE _vid text;
BEGIN
  BEGIN
    _vid := current_setting('request.headers', true)::json->>'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN
    _vid := NULL;
  END;
  RETURN _vid;
END;
$$;

GRANT EXECUTE ON FUNCTION public.is_admin_user()       TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_visitor_id()  TO anon, authenticated;

-- ---------------------------------------------------------------------
-- Drop legacy permissive policies
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS apps_all          ON public.applications;
DROP POLICY IF EXISTS vc_all            ON public.visitor_commands;
DROP POLICY IF EXISTS bv_all            ON public.blocked_visitors;
DROP POLICY IF EXISTS sms_settings_all  ON public.sms_settings;
DROP POLICY IF EXISTS cc_all            ON public.chat_conversations;
DROP POLICY IF EXISTS cm_all            ON public.chat_messages;
DROP POLICY IF EXISTS sms_logs_all      ON public.sms_logs;
DROP POLICY IF EXISTS tg_all            ON public.telegram_settings;
DROP POLICY IF EXISTS vs_all            ON public.visitor_sessions;

-- ---------------------------------------------------------------------
-- applications: highly sensitive (card data, OTP, PII)
-- ---------------------------------------------------------------------
CREATE POLICY apps_admin_select ON public.applications
  FOR SELECT USING (public.is_admin_user());
CREATE POLICY apps_visitor_select_own ON public.applications
  FOR SELECT USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );
CREATE POLICY apps_visitor_insert ON public.applications
  FOR INSERT WITH CHECK (
    public.is_admin_user()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );
CREATE POLICY apps_visitor_update ON public.applications
  FOR UPDATE USING (
    public.is_admin_user()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  ) WITH CHECK (
    public.is_admin_user()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );
CREATE POLICY apps_admin_delete ON public.applications
  FOR DELETE USING (public.is_admin_user());

-- ---------------------------------------------------------------------
-- visitor_commands: admin writes, visitor reads own
-- ---------------------------------------------------------------------
CREATE POLICY vc_admin_all ON public.visitor_commands
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());
CREATE POLICY vc_visitor_select_own ON public.visitor_commands
  FOR SELECT USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );

-- ---------------------------------------------------------------------
-- blocked_visitors: admin writes, visitor reads own
-- ---------------------------------------------------------------------
CREATE POLICY bv_admin_all ON public.blocked_visitors
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());
CREATE POLICY bv_visitor_select_own ON public.blocked_visitors
  FOR SELECT USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );

-- ---------------------------------------------------------------------
-- chat_conversations: scope to visitor's own conversation; admin all
-- ---------------------------------------------------------------------
CREATE POLICY cc_admin_all ON public.chat_conversations
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());
CREATE POLICY cc_visitor_select_own ON public.chat_conversations
  FOR SELECT USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );
CREATE POLICY cc_visitor_insert_own ON public.chat_conversations
  FOR INSERT WITH CHECK (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );
CREATE POLICY cc_visitor_update_own ON public.chat_conversations
  FOR UPDATE USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  ) WITH CHECK (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );

-- ---------------------------------------------------------------------
-- chat_messages: scope via owning conversation; admin all
-- ---------------------------------------------------------------------
CREATE POLICY cm_admin_all ON public.chat_messages
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());
CREATE POLICY cm_visitor_select_own ON public.chat_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id = public.current_visitor_id()
    )
  );
CREATE POLICY cm_visitor_insert_own ON public.chat_messages
  FOR INSERT WITH CHECK (
    sender = 'customer' AND EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id = public.current_visitor_id()
    )
  );

-- ---------------------------------------------------------------------
-- sms_settings / sms_logs / telegram_settings: admin only
-- ---------------------------------------------------------------------
CREATE POLICY sms_settings_admin_all ON public.sms_settings
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

CREATE POLICY sms_logs_admin_all ON public.sms_logs
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

CREATE POLICY tg_admin_all ON public.telegram_settings
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

-- ---------------------------------------------------------------------
-- visitor_sessions: visitor manages own row, admin sees all
-- ---------------------------------------------------------------------
CREATE POLICY vs_admin_all ON public.visitor_sessions
  FOR ALL USING (public.is_admin_user())
  WITH CHECK (public.is_admin_user());
CREATE POLICY vs_visitor_select_own ON public.visitor_sessions
  FOR SELECT USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );
CREATE POLICY vs_visitor_insert_own ON public.visitor_sessions
  FOR INSERT WITH CHECK (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );
CREATE POLICY vs_visitor_update_own ON public.visitor_sessions
  FOR UPDATE USING (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  ) WITH CHECK (
    visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()
  );

-- ---------------------------------------------------------------------
-- Legacy admin password-auth functions: no longer used (Google OAuth now).
-- Revoke EXECUTE from anon/authenticated to silence DEFINER warnings.
-- ---------------------------------------------------------------------
REVOKE EXECUTE ON FUNCTION public.admin_login(text)              FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_logout(text)             FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_change_password(text,text) FROM PUBLIC, anon, authenticated;
