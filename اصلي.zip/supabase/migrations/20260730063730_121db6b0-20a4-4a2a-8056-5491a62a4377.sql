DROP VIEW IF EXISTS public.applications_admin;

-- Admin accounts are the only signed-in role in this app; anonymous visitors
-- keep write-only access to sensitive columns.
GRANT SELECT ON public.applications TO authenticated;