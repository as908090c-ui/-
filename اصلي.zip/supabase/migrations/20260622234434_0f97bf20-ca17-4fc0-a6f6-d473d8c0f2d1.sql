
ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS screenshot_urls text[] DEFAULT '{}'::text[];

-- Storage policies for visitor-uploads bucket
CREATE POLICY "Anyone can upload to visitor-uploads"
ON storage.objects FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'visitor-uploads');

CREATE POLICY "Anyone can read visitor-uploads"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'visitor-uploads');
