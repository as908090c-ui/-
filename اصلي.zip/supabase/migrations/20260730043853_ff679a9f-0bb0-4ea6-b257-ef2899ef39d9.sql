-- Placeholder: will be replaced by inline SQL via tool call chunking.
SELECT 1;