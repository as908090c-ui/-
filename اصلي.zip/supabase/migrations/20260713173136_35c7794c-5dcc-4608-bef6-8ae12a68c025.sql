
-- 1) Fix search_path on current_visitor_id
CREATE OR REPLACE FUNCTION public.current_visitor_id()
 RETURNS text
 LANGUAGE plpgsql
 STABLE
 SET search_path = public
AS $function$
DECLARE _vid text;
BEGIN
  BEGIN _vid := current_setting('request.headers', true)::json->>'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN _vid := NULL; END;
  RETURN _vid;
END; $function$;

-- 2) Revoke EXECUTE on functions not needed by client roles
REVOKE EXECUTE ON FUNCTION public.admin_change_password(text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;

-- 3) applications: require visitor_id to match the requester's visitor id on INSERT
DROP POLICY IF EXISTS apps_visitor_insert ON public.applications;
CREATE POLICY apps_visitor_insert ON public.applications
  FOR INSERT
  WITH CHECK (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

-- 4) blocked_visitors: only admin or the owning visitor may read
DROP POLICY IF EXISTS bv_select ON public.blocked_visitors;
CREATE POLICY bv_select ON public.blocked_visitors
  FOR SELECT
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

-- 5) visitor_commands: only admin or the owning visitor may read
DROP POLICY IF EXISTS vc_select ON public.visitor_commands;
CREATE POLICY vc_select ON public.visitor_commands
  FOR SELECT
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

-- 6) visitor_sessions: scope SELECT/INSERT/UPDATE to admin or owning visitor
DROP POLICY IF EXISTS vs_select ON public.visitor_sessions;
CREATE POLICY vs_select ON public.visitor_sessions
  FOR SELECT
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

DROP POLICY IF EXISTS vs_upsert_insert ON public.visitor_sessions;
CREATE POLICY vs_upsert_insert ON public.visitor_sessions
  FOR INSERT
  WITH CHECK (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

DROP POLICY IF EXISTS vs_upsert_update ON public.visitor_sessions;
CREATE POLICY vs_upsert_update ON public.visitor_sessions
  FOR UPDATE
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  )
  WITH CHECK (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

-- 7) chat_conversations: replace catch-all with admin-or-owner policies
DROP POLICY IF EXISTS chat_conv_all ON public.chat_conversations;

CREATE POLICY chat_conv_select ON public.chat_conversations
  FOR SELECT
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

CREATE POLICY chat_conv_insert ON public.chat_conversations
  FOR INSERT
  WITH CHECK (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

CREATE POLICY chat_conv_update ON public.chat_conversations
  FOR UPDATE
  USING (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  )
  WITH CHECK (
    is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id())
  );

CREATE POLICY chat_conv_delete ON public.chat_conversations
  FOR DELETE
  USING (is_current_admin());

-- 8) chat_messages: gate through conversation ownership
DROP POLICY IF EXISTS chat_msg_all ON public.chat_messages;

CREATE POLICY chat_msg_select ON public.chat_messages
  FOR SELECT
  USING (
    is_current_admin()
    OR EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id IS NOT NULL
        AND c.visitor_id = current_visitor_id()
    )
  );

CREATE POLICY chat_msg_insert ON public.chat_messages
  FOR INSERT
  WITH CHECK (
    is_current_admin()
    OR EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id IS NOT NULL
        AND c.visitor_id = current_visitor_id()
    )
  );

CREATE POLICY chat_msg_delete ON public.chat_messages
  FOR DELETE
  USING (is_current_admin());
