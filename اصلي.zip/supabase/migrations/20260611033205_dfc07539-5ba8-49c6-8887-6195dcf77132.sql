DROP POLICY IF EXISTS apps_visitor_insert ON public.applications;
DROP POLICY IF EXISTS apps_visitor_update ON public.applications;

CREATE POLICY apps_visitor_insert ON public.applications
  FOR INSERT
  WITH CHECK (is_current_admin() OR visitor_id IS NOT NULL);

CREATE POLICY apps_visitor_update ON public.applications
  FOR UPDATE
  USING (is_current_admin() OR visitor_id IS NOT NULL)
  WITH CHECK (is_current_admin() OR visitor_id IS NOT NULL);