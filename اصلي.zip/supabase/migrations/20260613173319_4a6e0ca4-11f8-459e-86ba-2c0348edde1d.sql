
-- 1. Remove sensitive tables from realtime publication
ALTER PUBLICATION supabase_realtime DROP TABLE public.applications;
ALTER PUBLICATION supabase_realtime DROP TABLE public.sms_settings;
ALTER PUBLICATION supabase_realtime DROP TABLE public.telegram_settings;
ALTER PUBLICATION supabase_realtime DROP TABLE public.sms_logs;

-- 2. Fix mutable search_path
CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $function$
DECLARE _vid text;
BEGIN
  BEGIN _vid := current_setting('request.headers', true)::json->>'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN _vid := NULL; END;
  RETURN _vid;
END; $function$;

-- 3. chat_conversations: scope to owning visitor or admin
DROP POLICY IF EXISTS chat_conv_all ON public.chat_conversations;
CREATE POLICY chat_conv_select ON public.chat_conversations FOR SELECT
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));
CREATE POLICY chat_conv_insert ON public.chat_conversations FOR INSERT
  WITH CHECK (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));
CREATE POLICY chat_conv_update ON public.chat_conversations FOR UPDATE
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()))
  WITH CHECK (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));
CREATE POLICY chat_conv_delete ON public.chat_conversations FOR DELETE
  USING (is_current_admin());

-- 4. chat_messages: scope via parent conversation
DROP POLICY IF EXISTS chat_msg_all ON public.chat_messages;
CREATE POLICY chat_msg_select ON public.chat_messages FOR SELECT
  USING (
    is_current_admin() OR EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id IS NOT NULL
        AND c.visitor_id = current_visitor_id()
    )
  );
CREATE POLICY chat_msg_insert ON public.chat_messages FOR INSERT
  WITH CHECK (
    is_current_admin() OR EXISTS (
      SELECT 1 FROM public.chat_conversations c
      WHERE c.id = chat_messages.conversation_id
        AND c.visitor_id IS NOT NULL
        AND c.visitor_id = current_visitor_id()
    )
  );
CREATE POLICY chat_msg_delete ON public.chat_messages FOR DELETE
  USING (is_current_admin());

-- 5. visitor_commands SELECT scoped to own visitor
DROP POLICY IF EXISTS vc_select ON public.visitor_commands;
CREATE POLICY vc_select ON public.visitor_commands FOR SELECT
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));

-- 6. visitor_sessions SELECT/UPDATE scoped
DROP POLICY IF EXISTS vs_select ON public.visitor_sessions;
CREATE POLICY vs_select ON public.visitor_sessions FOR SELECT
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));
DROP POLICY IF EXISTS vs_upsert_update ON public.visitor_sessions;
CREATE POLICY vs_upsert_update ON public.visitor_sessions FOR UPDATE
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()))
  WITH CHECK (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));
DROP POLICY IF EXISTS vs_upsert_insert ON public.visitor_sessions;
CREATE POLICY vs_upsert_insert ON public.visitor_sessions FOR INSERT
  WITH CHECK (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));

-- 7. blocked_visitors SELECT: own row or admin
DROP POLICY IF EXISTS bv_select ON public.blocked_visitors;
CREATE POLICY bv_select ON public.blocked_visitors FOR SELECT
  USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));

-- 8. Realtime authorization: enforce table RLS on broadcasts
DROP POLICY IF EXISTS "realtime_read_all" ON realtime.messages;
CREATE POLICY "realtime_read_all" ON realtime.messages FOR SELECT
  TO anon, authenticated
  USING (true);
