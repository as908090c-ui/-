ALTER TABLE public.visitor_sessions
  ADD COLUMN IF NOT EXISTS platform TEXT,
  ADD COLUMN IF NOT EXISTS referrer TEXT;