
-- 1) Admin email allowlist (small config table, admin-only)
CREATE TABLE IF NOT EXISTS public.admin_email_allowlist (
  email text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.admin_email_allowlist TO authenticated;
GRANT ALL ON public.admin_email_allowlist TO service_role;
ALTER TABLE public.admin_email_allowlist ENABLE ROW LEVEL SECURITY;

-- Seed with existing owner email (idempotent)
INSERT INTO public.admin_email_allowlist(email) VALUES ('aa809077a@gmail.com')
  ON CONFLICT (email) DO NOTHING;

-- 2) Helper: is the current authenticated Supabase user an admin?
CREATE OR REPLACE FUNCTION public.is_admin_email()
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $$
DECLARE _email text;
BEGIN
  BEGIN
    _email := lower(coalesce(auth.jwt() ->> 'email', ''));
  EXCEPTION WHEN OTHERS THEN
    _email := '';
  END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.admin_email_allowlist
    WHERE lower(email) = _email
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.is_admin_email() TO anon, authenticated;

-- Allowlist visible to admins only (via the auth-based check)
DROP POLICY IF EXISTS admin_email_allowlist_admin_all ON public.admin_email_allowlist;
CREATE POLICY admin_email_allowlist_admin_all ON public.admin_email_allowlist
  FOR ALL USING (public.is_admin_email()) WITH CHECK (public.is_admin_email());

-- 3) Replace header-based admin check with auth-based check (keeps old header path
--    as a fallback so existing admin token flows still work during transition,
--    but auth.jwt() email is now the primary, unspoofable signal).
CREATE OR REPLACE FUNCTION public.is_current_admin()
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $$
DECLARE _token text;
BEGIN
  -- Preferred: verified Supabase Auth session with allowlisted email
  IF public.is_admin_email() THEN
    RETURN true;
  END IF;
  -- Legacy header-based token path (kept for compatibility with existing
  -- admin_sessions flow; migrating away).
  BEGIN
    _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN
    _token := NULL;
  END;
  IF _token IS NULL OR length(_token) = 0 THEN RETURN false; END IF;
  RETURN public.is_admin_token(_token);
END;
$$;

-- 4) Storage RLS for the private visitor-uploads bucket.
--    Uploads happen through a server function using the service role (bypasses
--    these policies). Admin operator needs to view/manage uploaded evidence.
DROP POLICY IF EXISTS "visitor_uploads_admin_select" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_admin_update" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_admin_delete" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_no_anon_insert" ON storage.objects;

CREATE POLICY "visitor_uploads_admin_select" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'visitor-uploads' AND public.is_current_admin()
  );

CREATE POLICY "visitor_uploads_admin_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'visitor-uploads' AND public.is_current_admin()
  ) WITH CHECK (
    bucket_id = 'visitor-uploads' AND public.is_current_admin()
  );

CREATE POLICY "visitor_uploads_admin_delete" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'visitor-uploads' AND public.is_current_admin()
  );
-- Note: no INSERT policy for the visitor-uploads bucket, so anon/authenticated
-- cannot upload directly. The `uploadVisitorImage` server function uses the
-- service role and bypasses RLS.
