-- =============================================================
-- Admin auth + RLS lockdown for sensitive tables.
-- =============================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------- Admin credentials (single row) ----------
CREATE TABLE IF NOT EXISTS public.admin_credentials (
  id            boolean PRIMARY KEY DEFAULT true CHECK (id = true),
  password_hash text    NOT NULL,
  updated_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_credentials ENABLE ROW LEVEL SECURITY;

INSERT INTO public.admin_credentials (id, password_hash)
VALUES (true, crypt('101010', gen_salt('bf')))
ON CONFLICT (id) DO NOTHING;

-- ---------- Admin sessions ----------
CREATE TABLE IF NOT EXISTS public.admin_sessions (
  token      text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days'
);
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

-- ---------- Helper functions ----------
CREATE OR REPLACE FUNCTION public.is_admin_token(_token text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_sessions
    WHERE token = _token AND expires_at > now()
  );
$$;

CREATE OR REPLACE FUNCTION public.is_current_admin()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _token text;
BEGIN
  BEGIN
    _token := current_setting('request.headers', true)::json->>'x-admin-token';
  EXCEPTION WHEN OTHERS THEN
    _token := NULL;
  END;
  IF _token IS NULL OR length(_token) = 0 THEN RETURN false; END IF;
  RETURN public.is_admin_token(_token);
END;
$$;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE _vid text;
BEGIN
  BEGIN
    _vid := current_setting('request.headers', true)::json->>'x-visitor-id';
  EXCEPTION WHEN OTHERS THEN
    _vid := NULL;
  END;
  RETURN _vid;
END;
$$;

-- ---------- Auth RPCs ----------
CREATE OR REPLACE FUNCTION public.admin_login(_password text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text; _token text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_password, _hash) <> _hash THEN
    RETURN NULL;
  END IF;
  _token := encode(gen_random_bytes(32), 'hex');
  INSERT INTO public.admin_sessions(token) VALUES (_token);
  DELETE FROM public.admin_sessions WHERE expires_at < now();
  RETURN _token;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_logout(_token text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  DELETE FROM public.admin_sessions WHERE token = _token;
$$;

CREATE OR REPLACE FUNCTION public.admin_change_password(_current text, _new text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_current, _hash) <> _hash THEN RETURN false; END IF;
  IF length(_new) < 4 THEN RETURN false; END IF;
  UPDATE public.admin_credentials
     SET password_hash = crypt(_new, gen_salt('bf')), updated_at = now()
   WHERE id = true;
  RETURN true;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_login(text)              TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_logout(text)             TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_change_password(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_current_admin()             TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin_token(text)           TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_visitor_id()           TO anon, authenticated;

-- =============================================================
-- Replace permissive policies.
-- =============================================================

-- applications: sensitive — lock SELECT to admin.
DROP POLICY IF EXISTS "public_select_applications" ON public.applications;
DROP POLICY IF EXISTS "public_insert_applications" ON public.applications;
DROP POLICY IF EXISTS "public_update_applications" ON public.applications;
DROP POLICY IF EXISTS "public_delete_applications" ON public.applications;

CREATE POLICY "apps_admin_select" ON public.applications FOR SELECT
  USING (public.is_current_admin());
CREATE POLICY "apps_visitor_insert" ON public.applications FOR INSERT
  WITH CHECK (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );
CREATE POLICY "apps_visitor_update" ON public.applications FOR UPDATE
  USING (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  )
  WITH CHECK (
    public.is_current_admin()
    OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())
  );
CREATE POLICY "apps_admin_delete" ON public.applications FOR DELETE
  USING (public.is_current_admin());

-- visitor_commands: SELECT stays public (realtime needs it); writes admin-only.
DROP POLICY IF EXISTS "vc_select" ON public.visitor_commands;
DROP POLICY IF EXISTS "vc_insert" ON public.visitor_commands;
DROP POLICY IF EXISTS "vc_delete" ON public.visitor_commands;
CREATE POLICY "vc_select"        ON public.visitor_commands FOR SELECT USING (true);
CREATE POLICY "vc_admin_insert"  ON public.visitor_commands FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY "vc_admin_delete"  ON public.visitor_commands FOR DELETE USING (public.is_current_admin());

-- blocked_visitors: SELECT stays public; writes admin-only.
DROP POLICY IF EXISTS "bv_select" ON public.blocked_visitors;
DROP POLICY IF EXISTS "bv_insert" ON public.blocked_visitors;
DROP POLICY IF EXISTS "bv_delete" ON public.blocked_visitors;
CREATE POLICY "bv_select"       ON public.blocked_visitors FOR SELECT USING (true);
CREATE POLICY "bv_admin_insert" ON public.blocked_visitors FOR INSERT WITH CHECK (public.is_current_admin());
CREATE POLICY "bv_admin_delete" ON public.blocked_visitors FOR DELETE USING (public.is_current_admin());

-- sms_settings: highly sensitive (API credentials) — admin only.
DROP POLICY IF EXISTS "sms_settings_select" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_insert" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_update" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_delete" ON public.sms_settings;
CREATE POLICY "sms_settings_admin_all" ON public.sms_settings FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());

-- sms_logs: admin only.
DROP POLICY IF EXISTS "sms_logs_select" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_insert" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_update" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_delete" ON public.sms_logs;
CREATE POLICY "sms_logs_admin_all" ON public.sms_logs FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());

-- telegram_settings: highly sensitive (bot token) — admin only.
DROP POLICY IF EXISTS "tg_select" ON public.telegram_settings;
DROP POLICY IF EXISTS "tg_insert" ON public.telegram_settings;
DROP POLICY IF EXISTS "tg_update" ON public.telegram_settings;
DROP POLICY IF EXISTS "tg_delete" ON public.telegram_settings;
CREATE POLICY "tg_admin_all" ON public.telegram_settings FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());