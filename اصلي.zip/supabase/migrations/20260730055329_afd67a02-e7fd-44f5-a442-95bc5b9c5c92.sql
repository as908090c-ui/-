
CREATE TABLE IF NOT EXISTS public.chat_blocked_visitors (
  visitor_id TEXT PRIMARY KEY,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.chat_blocked_visitors TO authenticated, anon;
GRANT ALL ON public.chat_blocked_visitors TO service_role;
ALTER TABLE public.chat_blocked_visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_blocked_visitors REPLICA IDENTITY FULL;
DROP POLICY IF EXISTS "cbv_all" ON public.chat_blocked_visitors;
CREATE POLICY "cbv_all" ON public.chat_blocked_visitors FOR ALL USING (true) WITH CHECK (true);
DO $$
BEGIN
  BEGIN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_blocked_visitors';
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;
