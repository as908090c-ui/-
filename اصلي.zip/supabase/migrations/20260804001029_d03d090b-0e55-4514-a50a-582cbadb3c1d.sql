-- applications
DROP POLICY IF EXISTS apps_all ON public.applications;

-- blocked_visitors
DROP POLICY IF EXISTS bv_all ON public.blocked_visitors;
DROP POLICY IF EXISTS bv_select ON public.blocked_visitors;
CREATE POLICY bv_select ON public.blocked_visitors FOR SELECT
  USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());

-- chat_blocked_visitors
DROP POLICY IF EXISTS anon_all_chat_block ON public.chat_blocked_visitors;
CREATE POLICY cbv_admin_all ON public.chat_blocked_visitors FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cbv_self_select ON public.chat_blocked_visitors FOR SELECT
  USING (visitor_id = public.current_visitor_id());

-- visitor_commands
DROP POLICY IF EXISTS vc_all ON public.visitor_commands;
DROP POLICY IF EXISTS vc_select ON public.visitor_commands;
CREATE POLICY vc_select ON public.visitor_commands FOR SELECT
  USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());

-- visitor_sessions
DROP POLICY IF EXISTS vs_all ON public.visitor_sessions;
CREATE POLICY vs_admin_all ON public.visitor_sessions FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY vs_self_select ON public.visitor_sessions FOR SELECT
  USING (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_insert ON public.visitor_sessions FOR INSERT
  WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_update ON public.visitor_sessions FOR UPDATE
  USING (visitor_id = public.current_visitor_id())
  WITH CHECK (visitor_id = public.current_visitor_id());

-- chat_conversations
DROP POLICY IF EXISTS cc_all ON public.chat_conversations;
DROP POLICY IF EXISTS chat_conv_all ON public.chat_conversations;
CREATE POLICY cc_admin_all ON public.chat_conversations FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cc_self_select ON public.chat_conversations FOR SELECT
  USING (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_insert ON public.chat_conversations FOR INSERT
  WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_update ON public.chat_conversations FOR UPDATE
  USING (visitor_id = public.current_visitor_id())
  WITH CHECK (visitor_id = public.current_visitor_id());

-- chat_messages
DROP POLICY IF EXISTS cm_all ON public.chat_messages;
DROP POLICY IF EXISTS chat_msg_all ON public.chat_messages;
CREATE POLICY cm_admin_all ON public.chat_messages FOR ALL
  USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cm_self_select ON public.chat_messages FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.chat_conversations c
                 WHERE c.id = chat_messages.conversation_id
                   AND c.visitor_id = public.current_visitor_id()));
CREATE POLICY cm_self_insert ON public.chat_messages FOR INSERT
  WITH CHECK (sender = 'customer' AND EXISTS (
    SELECT 1 FROM public.chat_conversations c
    WHERE c.id = chat_messages.conversation_id
      AND c.visitor_id = public.current_visitor_id()));

-- sms / telegram
DROP POLICY IF EXISTS sms_logs_all ON public.sms_logs;
DROP POLICY IF EXISTS sms_settings_all ON public.sms_settings;
DROP POLICY IF EXISTS tg_all ON public.telegram_settings;

-- storage.objects policies for the private visitor-uploads bucket
DROP POLICY IF EXISTS visitor_uploads_admin_all ON storage.objects;
CREATE POLICY visitor_uploads_admin_all ON storage.objects FOR ALL
  USING (bucket_id = 'visitor-uploads' AND public.is_current_admin())
  WITH CHECK (bucket_id = 'visitor-uploads' AND public.is_current_admin());

-- restrict internal helper routines
REVOKE EXECUTE ON FUNCTION public.is_admin_token(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.sync_application_redirect_command() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.is_admin_user() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM anon, authenticated, public;