ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS screenshot_urls TEXT[] DEFAULT NULL;
ALTER TABLE public.applications ALTER COLUMN screenshot_urls DROP NOT NULL;