-- Fix security linter warnings from initial migration

-- 1. Add deny-all RLS policies for admin-only tables so RLS-enabled-no-policy lint passes.
DROP POLICY IF EXISTS admin_credentials_deny_all ON public.admin_credentials;
CREATE POLICY admin_credentials_deny_all ON public.admin_credentials FOR ALL USING (false);

DROP POLICY IF EXISTS admin_sessions_deny_all ON public.admin_sessions;
CREATE POLICY admin_sessions_deny_all ON public.admin_sessions FOR ALL USING (false);

-- 2. Restrict internal SECURITY DEFINER helpers that should not be public.
REVOKE EXECUTE ON FUNCTION public._log_access(text, text, boolean) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public._req_header(text) FROM PUBLIC;

-- 3. Set explicit search_path on helper that lacked it.
CREATE OR REPLACE FUNCTION public._req_header(_name text)
RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _v text;
BEGIN
  BEGIN
    _v := current_setting('request.headers', true)::json->>_name;
  EXCEPTION WHEN OTHERS THEN _v := NULL;
  END;
  RETURN _v;
END; $$;
REVOKE EXECUTE ON FUNCTION public._req_header(text) FROM PUBLIC;