
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;

CREATE TABLE IF NOT EXISTS private.visitor_secret (
  id int PRIMARY KEY,
  secret bytea NOT NULL,
  CONSTRAINT visitor_secret_singleton CHECK (id = 1)
);
INSERT INTO private.visitor_secret(id, secret)
VALUES (1, extensions.gen_random_bytes(32))
ON CONFLICT (id) DO NOTHING;
REVOKE ALL ON private.visitor_secret FROM PUBLIC;
REVOKE ALL ON private.visitor_secret FROM anon, authenticated;
GRANT ALL ON private.visitor_secret TO service_role;

CREATE OR REPLACE FUNCTION private.mint_visitor_token()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  _vid text;
  _sec bytea;
  _sig text;
BEGIN
  _vid := 'V-' || encode(extensions.gen_random_bytes(12), 'hex');
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  _sig := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  RETURN _vid || '.' || _sig;
END;
$$;

CREATE OR REPLACE FUNCTION private.resolve_visitor_id()
RETURNS text
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  _headers json;
  _token text;
  _vid text;
  _sig text;
  _sec bytea;
  _expected text;
  _dot int;
BEGIN
  BEGIN
    _headers := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
  END;
  _token := _headers ->> 'x-visitor-token';
  IF _token IS NULL OR _token = '' THEN RETURN NULL; END IF;
  _dot := position('.' in _token);
  IF _dot < 2 THEN RETURN NULL; END IF;
  _vid := substring(_token from 1 for _dot - 1);
  _sig := substring(_token from _dot + 1);
  IF _vid = '' OR _sig = '' THEN RETURN NULL; END IF;
  SELECT secret INTO _sec FROM private.visitor_secret WHERE id = 1;
  IF _sec IS NULL THEN RETURN NULL; END IF;
  _expected := encode(extensions.hmac(_vid::bytea, _sec, 'sha256'), 'hex');
  IF _sig = _expected THEN RETURN _vid; END IF;
  RETURN NULL;
END;
$$;

REVOKE ALL ON FUNCTION private.mint_visitor_token() FROM PUBLIC;
REVOKE ALL ON FUNCTION private.resolve_visitor_id() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.mint_visitor_token() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.resolve_visitor_id() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.current_visitor_id()
RETURNS text
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = private, public
AS $$
  SELECT private.resolve_visitor_id();
$$;

CREATE OR REPLACE FUNCTION public.issue_visitor_token()
RETURNS text
LANGUAGE sql
SECURITY INVOKER
SET search_path = private, public
AS $$
  SELECT private.mint_visitor_token();
$$;

GRANT EXECUTE ON FUNCTION public.current_visitor_id() TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.issue_visitor_token() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE _email text;
BEGIN
  BEGIN
    _email := lower(coalesce(auth.jwt() ->> 'email', ''));
  EXCEPTION WHEN OTHERS THEN
    _email := '';
  END;
  IF _email = '' THEN RETURN false; END IF;
  RETURN _email IN ('aa809077a@gmail.com');
END;
$$;
GRANT EXECUTE ON FUNCTION public.is_admin_user() TO anon, authenticated;

DROP POLICY IF EXISTS "visitor_uploads_admin_all" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_select" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_insert" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_update" ON storage.objects;
DROP POLICY IF EXISTS "visitor_uploads_owner_delete" ON storage.objects;

CREATE POLICY "visitor_uploads_admin_all"
ON storage.objects
FOR ALL
TO authenticated
USING (bucket_id = 'visitor-uploads' AND public.is_admin_user())
WITH CHECK (bucket_id = 'visitor-uploads' AND public.is_admin_user());

CREATE POLICY "visitor_uploads_owner_select"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (
  bucket_id = 'visitor-uploads'
  AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id()
);

CREATE POLICY "visitor_uploads_owner_insert"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (
  bucket_id = 'visitor-uploads'
  AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id()
);

CREATE POLICY "visitor_uploads_owner_update"
ON storage.objects
FOR UPDATE
TO anon, authenticated
USING (
  bucket_id = 'visitor-uploads'
  AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id()
)
WITH CHECK (
  bucket_id = 'visitor-uploads'
  AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id()
);

CREATE POLICY "visitor_uploads_owner_delete"
ON storage.objects
FOR DELETE
TO anon, authenticated
USING (
  bucket_id = 'visitor-uploads'
  AND public.current_visitor_id() IS NOT NULL
  AND (storage.foldername(name))[1] = public.current_visitor_id()
);
