
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE sql STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT coalesce(
    nullif(current_setting('request.headers', true), '')::json->>'x-admin-token',
    ''
  ) = 'bcare-admin-direct-2026'
$$;
