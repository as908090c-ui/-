
ALTER PUBLICATION supabase_realtime ADD TABLE public.applications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.sms_settings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.sms_logs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.telegram_settings;

ALTER TABLE public.applications REPLICA IDENTITY FULL;
ALTER TABLE public.sms_settings REPLICA IDENTITY FULL;
ALTER TABLE public.sms_logs REPLICA IDENTITY FULL;
ALTER TABLE public.telegram_settings REPLICA IDENTITY FULL;
ALTER TABLE public.visitor_commands REPLICA IDENTITY FULL;
ALTER TABLE public.visitor_sessions REPLICA IDENTITY FULL;
ALTER TABLE public.blocked_visitors REPLICA IDENTITY FULL;
ALTER TABLE public.chat_conversations REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
