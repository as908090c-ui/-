DROP POLICY IF EXISTS apps_visitor_select ON public.applications;
CREATE POLICY apps_visitor_select
ON public.applications
FOR SELECT
TO anon, authenticated
USING (
  public.is_admin_user()
  OR (
    visitor_id IS NOT NULL
    AND visitor_id = public.current_visitor_id()
  )
);