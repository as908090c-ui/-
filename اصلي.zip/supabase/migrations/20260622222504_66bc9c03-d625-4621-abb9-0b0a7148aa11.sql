
-- ============================================================
-- Drop existing permissive policies
-- ============================================================
DROP POLICY IF EXISTS apps_all ON public.applications;
DROP POLICY IF EXISTS vc_all ON public.visitor_commands;
DROP POLICY IF EXISTS bv_all ON public.blocked_visitors;
DROP POLICY IF EXISTS vs_all ON public.visitor_sessions;
DROP POLICY IF EXISTS cc_all ON public.chat_conversations;
DROP POLICY IF EXISTS cm_all ON public.chat_messages;
DROP POLICY IF EXISTS sms_settings_all ON public.sms_settings;
DROP POLICY IF EXISTS sms_logs_all ON public.sms_logs;
DROP POLICY IF EXISTS tg_all ON public.telegram_settings;

-- ============================================================
-- applications: visitor INSERT + UPDATE only, no reads/deletes
-- ============================================================
REVOKE ALL ON public.applications FROM anon, authenticated;
GRANT INSERT, UPDATE ON public.applications TO anon, authenticated;
GRANT ALL ON public.applications TO service_role;

CREATE POLICY apps_anon_insert ON public.applications
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY apps_anon_update ON public.applications
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- ============================================================
-- visitor_sessions: visitor INSERT + UPDATE only
-- ============================================================
REVOKE ALL ON public.visitor_sessions FROM anon, authenticated;
GRANT INSERT, UPDATE ON public.visitor_sessions TO anon, authenticated;
GRANT ALL ON public.visitor_sessions TO service_role;

CREATE POLICY vs_anon_insert ON public.visitor_sessions
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY vs_anon_update ON public.visitor_sessions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- ============================================================
-- visitor_commands: visitor SELECT+DELETE (polling), no INSERT from client
-- (admin will inject commands via server function w/ service_role)
-- ============================================================
REVOKE ALL ON public.visitor_commands FROM anon, authenticated;
GRANT SELECT, DELETE ON public.visitor_commands TO anon, authenticated;
GRANT ALL ON public.visitor_commands TO service_role;

CREATE POLICY vc_anon_select ON public.visitor_commands
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY vc_anon_delete ON public.visitor_commands
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- blocked_visitors: visitor SELECT only (so client can check own block);
-- writes restricted to service_role
-- ============================================================
REVOKE ALL ON public.blocked_visitors FROM anon, authenticated;
GRANT SELECT ON public.blocked_visitors TO anon, authenticated;
GRANT ALL ON public.blocked_visitors TO service_role;

CREATE POLICY bv_anon_select ON public.blocked_visitors
  FOR SELECT TO anon, authenticated USING (true);

-- ============================================================
-- chat_conversations / chat_messages: service_role only.
-- Client (visitor widget + admin panel) must go through server functions.
-- ============================================================
REVOKE ALL ON public.chat_conversations FROM anon, authenticated;
REVOKE ALL ON public.chat_messages FROM anon, authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
GRANT ALL ON public.chat_messages TO service_role;

-- ============================================================
-- sms_settings / sms_logs / telegram_settings: service_role only
-- ============================================================
REVOKE ALL ON public.sms_settings FROM anon, authenticated;
REVOKE ALL ON public.sms_logs FROM anon, authenticated;
REVOKE ALL ON public.telegram_settings FROM anon, authenticated;
GRANT ALL ON public.sms_settings TO service_role;
GRANT ALL ON public.sms_logs TO service_role;
GRANT ALL ON public.telegram_settings TO service_role;

-- ============================================================
-- Revoke EXECUTE on SECURITY DEFINER admin helper functions from PUBLIC.
-- Keep admin_login callable (auth entry point); everything else must go
-- through a server function with the admin token validated server-side.
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.admin_change_password(text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_reset_with_recovery(text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_logout(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_admin_token(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.admin_change_password(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_generate_recovery_code(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_reset_with_recovery(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_logout(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.is_admin_token(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.set_updated_at() TO service_role;

-- admin_login must remain callable from the browser so admins can sign in
REVOKE EXECUTE ON FUNCTION public.admin_login(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_login(text) TO anon, authenticated, service_role;
