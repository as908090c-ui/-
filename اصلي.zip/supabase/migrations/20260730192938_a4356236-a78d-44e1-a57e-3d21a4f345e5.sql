GRANT ALL ON SCHEMA public TO sandbox_exec;
GRANT CREATE ON DATABASE postgres TO sandbox_exec;
GRANT anon, authenticated, service_role TO sandbox_exec;