CREATE POLICY apps_visitor_select ON public.applications
FOR SELECT TO public
USING (is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = current_visitor_id()));