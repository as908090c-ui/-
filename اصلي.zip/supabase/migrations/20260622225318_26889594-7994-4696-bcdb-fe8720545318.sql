
-- applications: restore full access
DROP POLICY IF EXISTS apps_anon_insert ON public.applications;
DROP POLICY IF EXISTS apps_anon_update ON public.applications;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.applications TO anon, authenticated;
CREATE POLICY apps_all ON public.applications FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- visitor_commands: restore full access
DROP POLICY IF EXISTS vc_anon_select ON public.visitor_commands;
DROP POLICY IF EXISTS vc_anon_delete ON public.visitor_commands;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_commands TO anon, authenticated;
CREATE POLICY vc_all ON public.visitor_commands FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- blocked_visitors: restore full access
DROP POLICY IF EXISTS bv_anon_select ON public.blocked_visitors;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blocked_visitors TO anon, authenticated;
CREATE POLICY bv_all ON public.blocked_visitors FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- visitor_sessions: restore full access
DROP POLICY IF EXISTS vs_anon_insert ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_anon_update ON public.visitor_sessions;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visitor_sessions TO anon, authenticated;
CREATE POLICY vs_all ON public.visitor_sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- chat_conversations / chat_messages: restore full access
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_messages TO anon, authenticated;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY cc_all ON public.chat_conversations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY cm_all ON public.chat_messages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- sms_settings / sms_logs / telegram_settings: restore admin-panel access
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_settings TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sms_logs TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.telegram_settings TO anon, authenticated;
ALTER TABLE public.sms_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sms_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY sms_settings_all ON public.sms_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY sms_logs_all ON public.sms_logs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY tg_all ON public.telegram_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
