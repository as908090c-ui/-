// Edge function: send-sms
// Sends SMS via a generic, admin-configured provider.
// Body: { recipients: [{ phone, applicationId? }], message: string, senderId?: string }
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface Recipient {
  phone: string;
  applicationId?: string | null;
}

interface ReqBody {
  recipients: Recipient[];
  message: string;
  senderId?: string;
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

function normalizePhone(raw: string, fmt: string): string {
  const digits = (raw || "").replace(/[^\d+]/g, "");
  if (!digits) return "";
  if (fmt === "raw") return digits;
  // e164: ensure leading +; default Saudi country code 966 if local 05XXXXXXXX
  if (digits.startsWith("+")) return digits;
  if (digits.startsWith("00")) return "+" + digits.slice(2);
  if (digits.startsWith("966")) return "+" + digits;
  if (digits.startsWith("0") && digits.length === 10) {
    return "+966" + digits.slice(1);
  }
  // Fallback: assume already has country code
  return "+" + digits;
}

function applyTemplate(tpl: string, vars: Record<string, string>): string {
  return tpl.replace(/\{(\w+)\}/g, (_, k) =>
    vars[k] !== undefined ? vars[k] : "",
  );
}

function jsonEscape(s: string): string {
  return JSON.stringify(s).slice(1, -1);
}

function toWesternDigits(value: string): string {
  return value
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
}

function extractOtpCode(message: string): string | null {
  const normalized = toWesternDigits(message);
  const contextual = normalized.match(/(?:رمز|كود|OTP|code|verification)[^\d]{0,60}(\d{4,6})/i)?.[1];
  if (contextual) return contextual;
  return normalized.match(/(^|\D)(\d{4,6})(?=\D|$)/)?.[2] ?? null;
}

function getWebOtpHost(req: Request): string | null {
  const explicit = Deno.env.get("WEBOTP_DOMAIN")?.trim();
  if (explicit) return explicit.replace(/^https?:\/\//, "").split("/")[0];

  const source = req.headers.get("origin") || req.headers.get("referer") || "";
  try {
    const host = new URL(source).hostname;
    return host || null;
  } catch {
    return null;
  }
}

function withWebOtpLine(message: string, req: Request): string {
  const trimmed = message.trimEnd();
  if (/(^|\n)@[^\s@]+\s+#\w{4,10}$/.test(trimmed)) return trimmed;

  const code = extractOtpCode(trimmed);
  const host = getWebOtpHost(req);
  if (!code || !host) return trimmed;

  return `${trimmed}\n\n@${host} #${code}`;
}

const ADMIN_EMAILS = new Set(["aa809077a@gmail.com"]);

async function requireAdmin(req: Request): Promise<{ ok: true } | { ok: false; resp: Response }> {
  const authHeader = req.headers.get("Authorization") || req.headers.get("authorization");
  const token = authHeader?.replace(/^Bearer\s+/i, "");
  if (!token) {
    return { ok: false, resp: new Response(JSON.stringify({ error: "unauthorized" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }) };
  }
  const authClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data, error } = await authClient.auth.getUser(token);
  const email = (data?.user?.email || "").toLowerCase();
  if (error || !data?.user || !ADMIN_EMAILS.has(email)) {
    return { ok: false, resp: new Response(JSON.stringify({ error: "forbidden" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }) };
  }
  return { ok: true };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const auth = await requireAdmin(req);
  if (!auth.ok) return auth.resp;

  try {
    const body = (await req.json()) as ReqBody;
    if (!body || !Array.isArray(body.recipients) || body.recipients.length === 0) {
      return new Response(
        JSON.stringify({ error: "recipients array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!body.message || typeof body.message !== "string") {
      return new Response(
        JSON.stringify({ error: "message is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: settings, error: sErr } = await admin
      .from("sms_settings")
      .select("*")
      .eq("id", "default")
      .maybeSingle();

    if (sErr || !settings) {
      return new Response(
        JSON.stringify({ error: "SMS settings not found" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!settings.enabled) {
      return new Response(
        JSON.stringify({ error: "SMS provider is disabled in settings" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!settings.api_url) {
      return new Response(
        JSON.stringify({ error: "SMS provider api_url is not configured" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const senderId = (body.senderId ?? settings.default_sender_id ?? "").toString();
    const smsMessage = withWebOtpLine(body.message.trim(), req);
    const method = (settings.http_method || "POST").toUpperCase();
    const contentType = settings.content_type || "application/json";
    let headers: Record<string, string> = {};
    try {
      headers = settings.headers_json ? JSON.parse(settings.headers_json) : {};
    } catch {
      headers = {};
    }

    const results: Array<{ phone: string; ok: boolean; status?: number; error?: string }>
      = [];

    for (const r of body.recipients) {
      const phone = normalizePhone(r.phone, settings.phone_format || "e164");
      if (!phone) {
        results.push({ phone: r.phone, ok: false, error: "invalid phone" });
        await admin.from("sms_logs").insert({
          application_id: r.applicationId ?? null,
          phone: r.phone,
          sender_id: senderId,
          message: smsMessage,
          status: "failed",
          error: "invalid phone",
        });
        continue;
      }

      const vars = {
        phone,
        message: smsMessage,
        sender_id: senderId,
        senderId,
      } as Record<string, string>;

      // For JSON bodies, escape user values to keep template valid JSON
      const isJson = contentType.toLowerCase().includes("json");
      const escapedVars = isJson
        ? Object.fromEntries(
            Object.entries(vars).map(([k, v]) => [k, jsonEscape(v)]),
          )
        : vars;

      const url = applyTemplate(settings.api_url, vars);
      const finalHeaders: Record<string, string> = {
        "Content-Type": contentType,
        ...Object.fromEntries(
          Object.entries(headers).map(([k, v]) => [k, applyTemplate(String(v), vars)]),
        ),
      };

      let fetchInit: RequestInit = { method, headers: finalHeaders };
      if (method !== "GET" && method !== "DELETE") {
        const tpl = settings.body_template || "";
        fetchInit.body = applyTemplate(tpl, escapedVars as Record<string, string>);
      }

      let httpStatus: number | undefined;
      let providerResp = "";
      let ok = false;
      let errMsg: string | undefined;
      try {
        const resp = await fetch(url, fetchInit);
        httpStatus = resp.status;
        providerResp = await resp.text();
        ok = resp.ok;
        if (!ok) errMsg = `HTTP ${resp.status}`;
      } catch (e) {
        errMsg = e instanceof Error ? e.message : String(e);
      }

      await admin.from("sms_logs").insert({
        application_id: r.applicationId ?? null,
        phone,
        sender_id: senderId,
        message: smsMessage,
        status: ok ? "sent" : "failed",
        http_status: httpStatus ?? null,
        provider_response: providerResp.slice(0, 4000),
        error: errMsg ?? null,
      });

      results.push({ phone, ok, status: httpStatus, error: errMsg });
    }

    const sent = results.filter((r) => r.ok).length;
    const failed = results.length - sent;

    return new Response(
      JSON.stringify({ success: true, sent, failed, results }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[send-sms] error", msg);
    return new Response(
      JSON.stringify({ error: msg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});