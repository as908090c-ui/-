DROP FUNCTION IF EXISTS public.get_my_applications(integer);

CREATE OR REPLACE FUNCTION public.get_my_applications(p_limit integer DEFAULT 5)
RETURNS TABLE(
  id text, created_at timestamp with time zone, visitor_id text,
  status text, review_status text, method text,
  card_brand text, card_last4 text, total numeric, price numeric,
  company text, insurance_type text,
  mutasil_provider text, mutasil_phone text, mutasil_id text,
  screenshot_urls text[],
  full_name text, identity text, birth_date text, phone text,
  start_date text, purpose text, est_value text,
  car_year text, car_model text, repair_place text, type text
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _vid text;
BEGIN
  _vid := public.current_visitor_id();
  IF _vid IS NULL OR _vid !~ '^V-[0-9a-f]{24}$' THEN RETURN; END IF;
  RETURN QUERY
    SELECT a.id, a.created_at, a.visitor_id, a.status, a.review_status, a.method,
           a.card_brand, a.card_last4, a.total, a.price, a.company, a.insurance_type,
           a.mutasil_provider, a.mutasil_phone, a.mutasil_id, a.screenshot_urls,
           a.full_name, a.identity, a.birth_date, a.phone,
           a.start_date, a.purpose, a.est_value,
           a.car_year, a.car_model, a.repair_place, a.type
    FROM public.applications a WHERE a.visitor_id = _vid
    ORDER BY a.created_at DESC LIMIT greatest(1, least(coalesce(p_limit, 5), 20));
END; $function$;