ALTER TABLE public.applications ADD COLUMN IF NOT EXISTS otp_resend_at timestamptz;
