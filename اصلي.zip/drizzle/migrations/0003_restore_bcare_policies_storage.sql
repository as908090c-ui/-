
-- Applications
DROP POLICY IF EXISTS apps_admin_select ON public.applications;
DROP POLICY IF EXISTS apps_visitor_insert ON public.applications;
DROP POLICY IF EXISTS apps_visitor_update ON public.applications;
DROP POLICY IF EXISTS apps_visitor_select ON public.applications;
DROP POLICY IF EXISTS apps_admin_delete ON public.applications;
CREATE POLICY apps_visitor_select ON public.applications FOR SELECT TO public USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_visitor_insert ON public.applications FOR INSERT TO public WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_visitor_update ON public.applications FOR UPDATE TO public USING (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id())) WITH CHECK (public.is_current_admin() OR (visitor_id IS NOT NULL AND visitor_id = public.current_visitor_id()));
CREATE POLICY apps_admin_delete ON public.applications FOR DELETE TO public USING (public.is_current_admin());

-- Visitor commands
DROP POLICY IF EXISTS vc_select ON public.visitor_commands;
DROP POLICY IF EXISTS vc_admin_insert ON public.visitor_commands;
DROP POLICY IF EXISTS vc_admin_delete ON public.visitor_commands;
CREATE POLICY vc_select ON public.visitor_commands FOR SELECT TO public USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());
CREATE POLICY vc_admin_insert ON public.visitor_commands FOR INSERT TO public WITH CHECK (public.is_current_admin());
CREATE POLICY vc_admin_delete ON public.visitor_commands FOR DELETE TO public USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());

-- Blocked visitors
DROP POLICY IF EXISTS bv_select ON public.blocked_visitors;
DROP POLICY IF EXISTS bv_admin_insert ON public.blocked_visitors;
DROP POLICY IF EXISTS bv_admin_delete ON public.blocked_visitors;
CREATE POLICY bv_select ON public.blocked_visitors FOR SELECT TO public USING (public.is_current_admin() OR visitor_id = public.current_visitor_id());
CREATE POLICY bv_admin_insert ON public.blocked_visitors FOR INSERT TO public WITH CHECK (public.is_current_admin());
CREATE POLICY bv_admin_delete ON public.blocked_visitors FOR DELETE TO public USING (public.is_current_admin());

-- Chat conversations
DROP POLICY IF EXISTS cc_admin_all ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_select ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_insert ON public.chat_conversations;
DROP POLICY IF EXISTS cc_self_update ON public.chat_conversations;
CREATE POLICY cc_admin_all ON public.chat_conversations FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cc_self_select ON public.chat_conversations FOR SELECT TO public USING (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_insert ON public.chat_conversations FOR INSERT TO public WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY cc_self_update ON public.chat_conversations FOR UPDATE TO public USING (visitor_id = public.current_visitor_id()) WITH CHECK (visitor_id = public.current_visitor_id());

-- Chat messages
DROP POLICY IF EXISTS cm_admin_all ON public.chat_messages;
DROP POLICY IF EXISTS cm_self_select ON public.chat_messages;
DROP POLICY IF EXISTS cm_self_insert ON public.chat_messages;
CREATE POLICY cm_admin_all ON public.chat_messages FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cm_self_select ON public.chat_messages FOR SELECT TO public USING (EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = chat_messages.conversation_id AND c.visitor_id = public.current_visitor_id()));
CREATE POLICY cm_self_insert ON public.chat_messages FOR INSERT TO public WITH CHECK (sender = 'customer' AND EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = chat_messages.conversation_id AND c.visitor_id = public.current_visitor_id()));

-- Chat blocked visitors
DROP POLICY IF EXISTS cbv_admin_all ON public.chat_blocked_visitors;
DROP POLICY IF EXISTS cbv_self_select ON public.chat_blocked_visitors;
CREATE POLICY cbv_admin_all ON public.chat_blocked_visitors FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY cbv_self_select ON public.chat_blocked_visitors FOR SELECT TO public USING (visitor_id = public.current_visitor_id());

-- SMS / Telegram settings
DROP POLICY IF EXISTS sms_settings_admin_all ON public.sms_settings;
CREATE POLICY sms_settings_admin_all ON public.sms_settings FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
DROP POLICY IF EXISTS sms_logs_admin_all ON public.sms_logs;
CREATE POLICY sms_logs_admin_all ON public.sms_logs FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
DROP POLICY IF EXISTS tg_admin_all ON public.telegram_settings;
CREATE POLICY tg_admin_all ON public.telegram_settings FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());

-- Visitor sessions
DROP POLICY IF EXISTS vs_admin_all ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_select ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_insert ON public.visitor_sessions;
DROP POLICY IF EXISTS vs_self_update ON public.visitor_sessions;
CREATE POLICY vs_admin_all ON public.visitor_sessions FOR ALL TO public USING (public.is_current_admin()) WITH CHECK (public.is_current_admin());
CREATE POLICY vs_self_select ON public.visitor_sessions FOR SELECT TO public USING (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_insert ON public.visitor_sessions FOR INSERT TO public WITH CHECK (visitor_id = public.current_visitor_id());
CREATE POLICY vs_self_update ON public.visitor_sessions FOR UPDATE TO public USING (visitor_id = public.current_visitor_id()) WITH CHECK (visitor_id = public.current_visitor_id());

-- Access logs (admin read only)
DROP POLICY IF EXISTS access_logs_admin_select ON public.access_logs;
CREATE POLICY access_logs_admin_select ON public.access_logs FOR SELECT TO public USING (public.is_current_admin());

-- Deny-all for internal admin tables
DROP POLICY IF EXISTS admin_credentials_deny_all ON public.admin_credentials;
CREATE POLICY admin_credentials_deny_all ON public.admin_credentials FOR ALL USING (false);
DROP POLICY IF EXISTS admin_sessions_deny_all ON public.admin_sessions;
CREATE POLICY admin_sessions_deny_all ON public.admin_sessions FOR ALL USING (false);

-- Restrict internal SECURITY DEFINER helpers
REVOKE EXECUTE ON FUNCTION public._log_access(text, text, boolean) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public._req_header(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.sync_application_redirect_command() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.log_admin_action(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.log_admin_action(text) TO authenticated;

DROP POLICY IF EXISTS visitor_uploads_admin_all ON storage.objects;
CREATE POLICY visitor_uploads_admin_all ON storage.objects FOR ALL
  USING (bucket_id = 'visitor-uploads' AND public.is_current_admin())
  WITH CHECK (bucket_id = 'visitor-uploads' AND public.is_current_admin());

-- Realtime publication
DO $$ DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['applications','chat_conversations','chat_messages','visitor_commands','blocked_visitors','sms_settings','sms_logs','telegram_settings','visitor_sessions','chat_blocked_visitors']
  LOOP
    BEGIN EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL; END;
  END LOOP;
END $$;
