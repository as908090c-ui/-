# Roadmap

## Done
- [x] Enable Lovable Cloud for this project
- [x] Restore database schema + policies + realtime from `drizzle/migrations/0000_*`, `0001_*`, `0004_*`
- [x] Point the build at the new backend (`vite.config.ts` baked URL + publishable key)
- [x] Create `visitor-uploads` storage bucket (private, 5MB)

## Open
- [x] Fit mobile form controls without automatic focus zoom and reset scrolling on every page transition — scroll tests pass; offers-to-checkout starts at zero on 320px, 390px and 430px phone widths with no horizontal overflow.
- [x] Verify the live quote flow writes to the new backend (visitor token mint → application insert) — confirmed: rows APP-MV4N1NP2 / MV4N3586 / MV4N4NCE written by the new backend
- [x] Confirm admin approval (review_status=approved) still auto-redirects the visitor to /quote/otp — verified on the new backend: approved row produced visitor_commands {command: redirect, payload: /quote/otp} for that visitor
- [x] Google sign-in button in the site header (Google provider enabled; signed-in email + sign out verified)
- [x] Charge receipt shows each visitor's own card last-4 instead of fixed digits — real flow verified: card entered at /quote/payment shows as in-card digits at /quote/custom2, full number never shown
