-- =============================================================
-- Access logs: track admin login attempts and admin actions.
-- Run this in Lovable Cloud > SQL Editor.
-- =============================================================

CREATE TABLE IF NOT EXISTS public.access_logs (
  id          bigserial PRIMARY KEY,
  created_at  timestamptz NOT NULL DEFAULT now(),
  event_type  text NOT NULL,
  details     text,
  visitor_id  text,
  ip_address  text,
  user_agent  text,
  is_admin    boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS access_logs_created_at_idx ON public.access_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS access_logs_event_type_idx ON public.access_logs (event_type);

ALTER TABLE public.access_logs ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.access_logs TO authenticated;
GRANT ALL ON public.access_logs TO service_role;

DROP POLICY IF EXISTS "admins read access_logs" ON public.access_logs;
CREATE POLICY "admins read access_logs" ON public.access_logs
  FOR SELECT TO anon, authenticated
  USING (public.is_current_admin());

CREATE OR REPLACE FUNCTION public._req_header(_name text)
RETURNS text LANGUAGE plpgsql STABLE AS $$
DECLARE _v text;
BEGIN
  BEGIN
    _v := current_setting('request.headers', true)::json->>_name;
  EXCEPTION WHEN OTHERS THEN _v := NULL;
  END;
  RETURN _v;
END;
$$;

CREATE OR REPLACE FUNCTION public._log_access(
  _event_type text, _details text, _is_admin boolean
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.access_logs (event_type, details, visitor_id, ip_address, user_agent, is_admin)
  VALUES (
    _event_type, _details,
    public._req_header('x-visitor-id'),
    COALESCE(public._req_header('x-forwarded-for'), public._req_header('cf-connecting-ip')),
    public._req_header('user-agent'),
    _is_admin
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_login(_password text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text; _token text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_password, _hash) <> _hash THEN
    PERFORM public._log_access('admin_login_failed', 'Wrong password', false);
    RETURN NULL;
  END IF;
  _token := encode(gen_random_bytes(32), 'hex');
  INSERT INTO public.admin_sessions(token) VALUES (_token);
  DELETE FROM public.admin_sessions WHERE expires_at < now();
  PERFORM public._log_access('admin_login_success', 'Login OK', true);
  RETURN _token;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_logout(_token text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.admin_sessions WHERE token = _token;
  PERFORM public._log_access('admin_logout', 'Logout', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_change_password(_current text, _new text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _hash text;
BEGIN
  SELECT password_hash INTO _hash FROM public.admin_credentials WHERE id = true;
  IF _hash IS NULL OR crypt(_current, _hash) <> _hash THEN
    PERFORM public._log_access('admin_password_change_failed', 'Wrong current password', false);
    RETURN false;
  END IF;
  IF length(_new) < 4 THEN RETURN false; END IF;
  UPDATE public.admin_credentials
     SET password_hash = crypt(_new, gen_salt('bf')), updated_at = now()
   WHERE id = true;
  PERFORM public._log_access('admin_password_changed', 'Password updated', true);
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.log_admin_action(_details text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_current_admin() THEN RETURN; END IF;
  PERFORM public._log_access('admin_action', _details, true);
END;
$$;

CREATE OR REPLACE FUNCTION public.get_access_logs(_limit int DEFAULT 200)
RETURNS SETOF public.access_logs
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_current_admin() THEN
    RAISE EXCEPTION 'unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.access_logs
    ORDER BY created_at DESC
    LIMIT GREATEST(1, LEAST(_limit, 1000));
END;
$$;

GRANT EXECUTE ON FUNCTION public.log_admin_action(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_access_logs(int)   TO anon, authenticated;
