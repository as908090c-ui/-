-- =============================================================
-- Active admin sessions counter (heartbeat-based)
-- Run this in Lovable Cloud > SQL Editor (after access_logs.sql).
-- =============================================================

-- 1) Track last activity time per session
ALTER TABLE public.admin_sessions
  ADD COLUMN IF NOT EXISTS last_seen timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS admin_sessions_last_seen_idx
  ON public.admin_sessions (last_seen DESC);

-- 2) Heartbeat: each open dashboard pings this every ~30s
CREATE OR REPLACE FUNCTION public.admin_heartbeat(_token text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.admin_sessions
     SET last_seen = now()
   WHERE token = _token
     AND expires_at > now();
END;
$$;

-- 3) Count admins active in the last 90 seconds (admin-only)
CREATE OR REPLACE FUNCTION public.count_active_admins()
RETURNS integer
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _c integer;
BEGIN
  IF NOT public.is_current_admin() THEN
    RETURN 0;
  END IF;
  SELECT count(*) INTO _c
    FROM public.admin_sessions
   WHERE expires_at > now()
     AND last_seen > now() - interval '90 seconds';
  RETURN COALESCE(_c, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_heartbeat(text)   TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.count_active_admins()   TO anon, authenticated;
