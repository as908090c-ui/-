<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Shared quote navigation and offer actions use the `btn-pay` utility backed by primary theme tokens so every step retains a consistent action color.
- Keep scroll resetting in the shared client page shell and mobile input sizing in global CSS, so every existing quote step starts at the top and avoids native focus zoom without disabling accessible pinch zoom.
- The standalone payment-options route uses local selection state only and must not import visitor tracking or payment submission logic, keeping the demonstration isolated from sensitive data flows.
- The database schema is restored from `drizzle/migrations/0000_*` and `0001_*`; keep new columns and policies in step with those files so a fresh backend can be rebuilt from them.
- The migration tool replays every entry in `drizzle/migrations/meta/_journal.json` before the SQL you submit, so a migration that redefines a function must `DROP FUNCTION` it first whenever an earlier journal entry already changed its return type.
- `vite.config.ts` bakes the backend URL and publishable key into the build, so both must be updated whenever the project is pointed at a different backend — otherwise the preview keeps calling the old one.
- Card digits shown to a visitor come from that visitor's own application row, read through `src/lib/card-display.ts`; never hardcode example digits in a receipt, so every screen shows only the last four digits the person actually submitted.
