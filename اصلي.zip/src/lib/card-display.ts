// Card digits shown on the visitor's charge receipt.
// Only the last four digits of the card the visitor themselves submitted may
// ever reach the screen — never the full number, and never a fixed example.
export type CardSource = {
  cardLast4?: string | null;
  cardNumber?: string | null;
  cardBrand?: string | null;
};

export const last4Of = (app?: CardSource | null): string => {
  const stored = (app?.cardLast4 ?? "").replace(/\D/g, "");
  if (stored.length >= 4) return stored.slice(-4);
  const digits = (app?.cardNumber ?? "").replace(/\D/g, "");
  return digits.length >= 4 ? digits.slice(-4) : "";
};

const BRAND_LABELS: Record<string, string> = {
  mada: "مدى",
  visa: "فيزا",
  mastercard: "ماستر كارد",
  amex: "أمريكان إكسبرس",
};

export const brandLabelOf = (brand?: string | null): string =>
  BRAND_LABELS[(brand ?? "").toLowerCase()] ?? "بطاقة";
