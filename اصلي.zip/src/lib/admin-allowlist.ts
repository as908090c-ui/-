// Allowed admin Gmail accounts (lowercase). Only these emails can access the admin dashboard.
export const ADMIN_LAST_EMAIL_KEY = "bcare_admin_last_google_email";

export const ADMIN_ALLOWED_EMAILS: string[] = [
  "aa809077a@gmail.com",
];


/** The "owner" admin — the first email in the allowlist. Only the owner can
 *  warn or force-logout other admins from the dashboard. */
export const ADMIN_OWNER_EMAIL = ADMIN_ALLOWED_EMAILS[0];

export function isAllowedAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return ADMIN_ALLOWED_EMAILS.includes(email.trim().toLowerCase());
}

export function isOwnerAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return email.trim().toLowerCase() === ADMIN_OWNER_EMAIL;
}

