// Display-only translations for offer data (companies, coverages, addons, fees).
// The underlying data stays Arabic; this maps it to English when needed.

const MAP: Record<string, string> = {
  // Companies
  "ولاء للتأمين": "Walaa Insurance",
  "ولاء": "Walaa",
  "تكافل الراجحي": "Al Rajhi Takaful",
  "التعاونية": "Tawuniya",
  "سلامة": "Salama",
  "ليفا للتأمين": "LIVA Insurance",
  "ميدغلف": "MedGulf",
  "الاتحاد الخليجي": "Gulf Union",
  "الإتحاد للتأمين": "Alettihad Insurance",
  "أسيج": "ACIG",
  "الاتحاد للتأمين التعاوني": "Alettihad Cooperative Insurance",
  "بروج": "Buruj",
  "جي آي جي": "GIG",
  "العربية للتأمين": "Arabia Insurance",
  "الصقر للتأمين": "Al Sagr Insurance",
  "الدرع العربي": "Arabian Shield",
  "أليانز": "Allianz",
  "الخليج العامة": "Gulf General",
  "أمانة": "Amana",
  "الوطنية للتأمين": "Wataniya Insurance",

  // Main coverage
  "المسؤولية المدنية تجاه الغير بحد أقصى 10,000,000 ريال":
    "Third party liability up to a maximum of SAR 10,000,000",
  "تغطية شاملة حتى 10,000 ريال سعودي": "Comprehensive coverage up to SAR 10,000",
  "تغطية الخسارة الكلية أو الجزئية للمركبة": "Total or partial loss coverage for the vehicle",
  "مسؤولية الطرف الثالث عن الاضرار الجسدية": "Third party liability for bodily injury",
  "خسارة او تلف المركبة": "Loss of or damage to the vehicle",
  "المسؤولية تجاه الغير (الطرف الثالث): الحد الأقصى لمسؤولية الشركة في الواقعة الواحدة وخلال فترة سريان وثيقة التأمين بالنسبة للأضرار الجسدية بما في ذلك الديات والمبالغ المقدرة عن الإصابات والمصاريف الطبية) والأضرار المادية معاً لن تتجاوز مبلغاً إجمالياً قدره 10,000,000 ريال (عشرة ملايين ريال سعودي) حداً أقصى لمسئولية الشركة":
    "Third party liability: the company's maximum liability per incident and during the policy period, for bodily injury (including blood money, assessed injury amounts and medical expenses) and material damage combined, shall not exceed a total of SAR 10,000,000 (ten million Saudi riyals).",

  // Addons
  "المساعدة على الطريق": "Roadside assistance",
  "المساعدة على الطريق البلاتينية": "Platinum roadside assistance",
  "المساعدة على الطريق + درايف مجانا": "Roadside assistance + free Drive",
  "تغطية الحوادث الشخصية للسائق": "Personal accident coverage for the driver",
  "تغطية الحوادث الشخصية للسائق فقط": "Personal accident coverage for the driver only",
  "تغطية الحوادث الشخصية للركاب فقط": "Personal accident coverage for passengers only",
  "تغطية الحوادث الشخصية للسائق والركاب": "Personal accident coverage for driver and passengers",
  "تغطية ضد كسر الزجاج والحرائق والسرقة": "Coverage against glass breakage, fire and theft",
  "تغطية الكوارث الطبيعية": "Natural disasters coverage",
  "الاخطار الطبيعية": "Natural perils",
  "الاصابات الجسدية للغير": "Third party bodily injury",
  "تلف ممتلكات الغير": "Third party property damage",
  "مسؤولية الطرف الثالث": "Third party liability",
  "إعفاء من نسبة استهلاك قطع الغيار": "Waiver of spare parts depreciation",
  "تكاليف حالات الطوارئ الطبية": "Medical emergency costs",
  "سيارة بديلة": "Replacement car",
  "ضرر كامل": "Total damage",
  "تغطية السرقة والحرائق": "Theft and fire coverage",
  "تغطية دول مجلس التعاون الخليجي": "GCC countries coverage",
  "تغطية مجانية للتكاليف الطبية الطارئة لحد 5000 ريال لكل شخص":
    "Free emergency medical cost coverage up to SAR 5,000 per person",
  "الوفاة و الاصابة الجسدية والمصاريف الطبية للمؤمن له او السائق المسمى":
    "Death, bodily injury and medical expenses for the insured or the named driver",
  "ايجار المركيبة البديلة بحد يومي 100 ريال لمدة 10 ايام":
    "Replacement vehicle rental at SAR 100 per day for 10 days",
  "الحوادث التي تقع خارج الحدود الاقليمية للمملكة العربية السعودية لجميع دول مجلس التعاون الخليجي و الاردن":
    "Accidents outside the territorial borders of Saudi Arabia, in all GCC countries and Jordan",
  "الحوادث التي تقع خارج الحدود الاقليمية للمملكة العربية السعودية":
    "Accidents outside the territorial borders of Saudi Arabia",
  "استئجار سيارة بحد أقصى 2,000 ريال سعودي لكل مركبة، بحد اقصى 100 ريال سعودي في اليوم. وبمدة لا تتجاوز 20 يوم":
    "Car rental up to SAR 2,000 per vehicle, max SAR 100 per day, for no more than 20 days",
  "استئجار سيارة بحد أقصى 5,000 ريال سعودي لكل مركبة، بحد اقصى 250 ريال سعودي في اليوم. وبمدة لا تتجاوز 20 يوم":
    "Car rental up to SAR 5,000 per vehicle, max SAR 250 per day, for no more than 20 days",
  "باستئجار سيارة بحد أقصى 4,000 ريال سعودي لكل مركبة، بحد اقصى 200 ريال سعودي في اليوم. وبمدة لا تتجاوز 20 يوم":
    "Car rental up to SAR 4,000 per vehicle, max SAR 200 per day, for no more than 20 days",
  "مصاريف السحب (الرسوم الفعلية ، بحد أقصى 500 ريال سعودي / - لكل حادث داخل المدينة و 1،000 ريال سعودي / - خارج المدينة : بشرط تقديم إيصال النقل عند تقديم المطالبة ..)":
    "Towing expenses (actual charges, up to SAR 500 per accident inside the city and SAR 1,000 outside the city, subject to providing the towing receipt with the claim)",

  // Fees
  "خصم عدم وجود مطالبات": "No-claims discount",
  "ضريبة القيمة المضافة": "VAT",
  "تحميل اضافي (بسبب الحوادث)": "Additional loading (due to accidents)",
  "عمولة نهاية الوسيط": "Broker commission",
  "عمولة عناية الوسيط": "Broker service commission",
  "رسوم إدارية": "Administrative fees",
  "خصم خاص": "Special discount",
  "خصم استضافة السعودية ل اكسبو 2030": "Saudi Expo 2030 hosting discount",
  "خصم بي كير": "Bcare discount",

  // Types
  "ضد الغير": "Third Party",
  "شامل": "Comprehensive",
};

/** Translate an Arabic offer string to English; returns the input unchanged in Arabic mode or when unknown. */
export const trOffer = (text: string | undefined, isAr: boolean): string => {
  if (!text) return text || "";
  if (isAr) return text;
  return MAP[text.trim()] ?? text;
};
