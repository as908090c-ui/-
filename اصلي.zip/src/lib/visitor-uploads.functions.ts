import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const ALLOWED_CONTENT_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "image/gif",
]);
// 5 MB decoded upload cap.
const MAX_BYTES = 5 * 1024 * 1024;
// base64 encodes 3 bytes into 4 chars; cap the encoded length accordingly.
const MAX_BASE64_LENGTH = Math.ceil((MAX_BYTES * 4) / 3) + 8;

const SAFE_PATH_SEGMENT = /^[A-Za-z0-9_.-]+$/;

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const len = binary.length;
  const arr = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    arr[i] = binary.charCodeAt(i);
  }
  return arr;
}

export const uploadVisitorImage = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      visitorId: z.string().min(1).max(128).regex(SAFE_PATH_SEGMENT),
      path: z.string().min(1).max(256),
      contentType: z.string().min(1),
      base64: z.string().min(1).max(MAX_BASE64_LENGTH),
    }),
  )
  .handler(async ({ data }) => {
    // Constrain the stored path to the caller's own visitor namespace so a
    // malicious caller cannot overwrite objects owned by other visitors.
    const prefix = `${data.visitorId}/`;
    if (!data.path.startsWith(prefix)) {
      throw new Error("Invalid path: must be inside the caller's visitor folder");
    }
    const remainder = data.path.slice(prefix.length);
    if (
      remainder.length === 0 ||
      remainder.includes("..") ||
      remainder.includes("//") ||
      !/^[A-Za-z0-9_./-]+$/.test(remainder)
    ) {
      throw new Error("Invalid path");
    }

    if (!ALLOWED_CONTENT_TYPES.has(data.contentType.toLowerCase())) {
      throw new Error("Unsupported content type");
    }

    const file = base64ToUint8Array(data.base64);
    if (file.byteLength === 0 || file.byteLength > MAX_BYTES) {
      throw new Error("File size out of range");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.storage
      .from("visitor-uploads")
      // upsert:false — do not let callers overwrite existing objects at the
      // same path. Callers must pick a unique filename.
      .upload(data.path, file, { upsert: false, contentType: data.contentType });
    if (error) {
      console.error("[uploadVisitorImage] upload error:", error);
      throw new Error(`Upload failed: ${error.message}`);
    }
    const { data: signed, error: signErr } = await supabaseAdmin.storage
      .from("visitor-uploads")
      .createSignedUrl(data.path, 60 * 60 * 24 * 365);
    if (signErr || !signed) {
      console.error("[uploadVisitorImage] sign error:", signErr);
      throw signErr ?? new Error("Failed to generate signed URL");
    }
    return { url: signed.signedUrl };
  });
