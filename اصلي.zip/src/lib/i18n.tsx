import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type Lang = "ar" | "en";

const STORAGE_KEY = "site-lang";

type I18nValue = {
  lang: Lang;
  dir: "rtl" | "ltr";
  isAr: boolean;
  setLang: (lang: Lang) => void;
  toggleLang: () => void;
  /** Pick the string for the active language. */
  t: (ar: string, en: string) => string;
};

const I18nContext = createContext<I18nValue | null>(null);

const readStored = (): Lang => {
  if (typeof window === "undefined") return "ar";
  try {
    const v = window.localStorage.getItem(STORAGE_KEY);
    return v === "en" ? "en" : "ar";
  } catch {
    return "ar";
  }
};

export const I18nProvider = ({ children }: { children: React.ReactNode }) => {
  const [lang, setLangState] = useState<Lang>("ar");

  // Read the stored choice after hydration to avoid SSR mismatches.
  useEffect(() => {
    setLangState(readStored());
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const el = document.documentElement;
    el.lang = lang;
    el.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<I18nValue>(() => {
    const isAr = lang === "ar";
    return {
      lang,
      isAr,
      dir: isAr ? "rtl" : "ltr",
      setLang,
      toggleLang: () => setLang(isAr ? "en" : "ar"),
      t: (ar: string, en: string) => (isAr ? ar : en),
    };
  }, [lang, setLang]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export const useI18n = (): I18nValue => {
  const ctx = useContext(I18nContext);
  if (ctx) return ctx;
  // Safe fallback (e.g. components rendered outside the provider).
  return {
    lang: "ar",
    dir: "rtl",
    isAr: true,
    setLang: () => {},
    toggleLang: () => {},
    t: (ar: string) => ar,
  };
};
