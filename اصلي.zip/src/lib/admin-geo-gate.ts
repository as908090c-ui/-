import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

type GeoInfo = { country?: string; country_code?: string };
const CACHE_KEY = "bcare_admin_geo_v1";

async function fetchGeo(): Promise<GeoInfo> {
  try {
    const cached = sessionStorage.getItem(CACHE_KEY);
    if (cached) return JSON.parse(cached) as GeoInfo;
  } catch {}

  const tryEndpoint = async (url: string, mapper: (d: any) => GeoInfo) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      const d = await res.json();
      return mapper(d);
    } catch {
      return null;
    }
  };

  let geo: GeoInfo | null = await tryEndpoint("https://ipapi.co/json/", (d) => ({
    country: d.country_name,
    country_code: d.country_code,
  }));
  if (!geo || !geo.country_code) {
    geo = await tryEndpoint("https://ipwho.is/", (d) => ({
      country: d.country,
      country_code: d.country_code,
    }));
  }
  const result = geo || {};
  try {
    sessionStorage.setItem(CACHE_KEY, JSON.stringify(result));
  } catch {}
  return result;
}

/** Block access to admin pages from outside Saudi Arabia. */
export function useAdminGeoGate() {
  const navigate = useNavigate();
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const geo = await fetchGeo();
      if (cancelled) return;
      const code = (geo.country_code || "").toUpperCase();
      // Only block when we positively detect a non-SA country.
      if (code && code !== "SA") {
        navigate("/blocked", {
          replace: true,
          state: { reason: "geo", country: geo.country },
        });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [navigate]);
}
