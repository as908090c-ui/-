import { CalendarSync, BadgeDollarSign, ListChecks, Timer, MapPin, HandCoins, BadgePercent, FileSignature, Flame, ListTodo } from "lucide-react";
import { useI18n } from "@/lib/i18n";

const SafePathSection = () => {
  const { t } = useI18n();

  const ITEMS = [
    { Icon: CalendarSync, label: t("جدول تأمينك", "Schedule your insurance") },
    { Icon: BadgeDollarSign, label: t("أسعار أقل", "Lower prices") },
    { Icon: ListChecks, label: t("فضّل تأمينك", "Choose your coverage") },
    { Icon: Timer, label: t("تأمينك في دقيقة", "Insured in a minute") },
    { Icon: MapPin, label: t("مكان واحد", "All in one place") },
    { Icon: HandCoins, label: t("منافع تحميك", "Benefits that protect you") },
    { Icon: BadgePercent, label: t("خصومات", "Discounts") },
    { Icon: FileSignature, label: t("هب ريح", "Total peace of mind") },
  ];

  return (
    <section className="px-4 py-10" aria-labelledby="safe-path-title">
      <div className="mx-auto mb-8 max-w-5xl overflow-hidden rounded-2xl bg-white p-4 shadow-soft">
        <img
          src="/insurance-partners-strip.png"
          alt={t("شركاء بي كير من شركات التأمين", "Bcare's insurance company partners")}
          className="w-full object-contain"
          loading="lazy"
        />
      </div>

      <h2 id="safe-path-title" className="text-center text-2xl font-black text-brand-blue">
        {t("طريقك آمن مع بي كير", "Your path is safe with Bcare")}
      </h2>

      <div className="mx-auto mt-8 grid max-w-md grid-cols-2 gap-4 sm:grid-cols-4 sm:max-w-3xl">
        {ITEMS.map(({ Icon, label }) => (
          <div
            key={label}
            className="flex aspect-square flex-col items-center justify-center gap-3 rounded-2xl bg-white p-4 shadow-soft"
          >
            <Icon className="h-10 w-10 text-brand-blue" strokeWidth={1.8} />
            <span className="text-center text-sm font-bold text-brand-blue">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
};

export default SafePathSection;
