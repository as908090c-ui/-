import { useEffect, useLayoutEffect } from "react";
import { useLocation } from "react-router-dom";

/** Shared by the existing client-side pages, including the quote steps. */
export default function PageScrollReset() {
  const { pathname, search } = useLocation();

  useEffect(() => {
    const previous = window.history.scrollRestoration;
    window.history.scrollRestoration = "manual";
    return () => {
      window.history.scrollRestoration = previous;
    };
  }, []);

  useLayoutEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [pathname, search]);

  return null;
}