import { useEffect, useState } from "react";
import { ArrowUp, Headphones } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";

const FloatingButtons = () => {
  const [showTop, setShowTop] = useState(false);
  const { t } = useI18n();

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed bottom-5 left-4 z-40 flex flex-col gap-3 sm:left-[max(1rem,calc(50%-240px+1rem))]">
      <button
        onClick={() => toast(t("تواصل معنا على 8001180044", "Contact us at 8001180044"))}
        aria-label={t("مركز الدعم", "Support center")}
        className="grid h-12 w-12 place-items-center rounded-full bg-brand-orange text-white shadow-float transition-transform hover:scale-105"
      >
        <Headphones className="h-5 w-5" />
      </button>
      {showTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label={t("العودة للأعلى", "Back to top")}
          className="grid h-12 w-12 place-items-center rounded-full bg-brand-blue text-white shadow-float transition-transform hover:scale-105"
        >
          <ArrowUp className="h-5 w-5" />
        </button>
      )}
    </div>
  );
};

export default FloatingButtons;
