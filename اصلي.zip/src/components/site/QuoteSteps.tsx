import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

const QuoteSteps = ({ current = 2 }: { current?: number }) => {
  const { t, dir } = useI18n();

  const steps = [
    { id: 1, label: t("البيانات الرئيسية", "Main information") },
    { id: 2, label: t("تفاصيل وثيقة التأمين", "Policy details") },
    { id: 3, label: t("الشركات والعروض", "Companies and offers") },
    { id: 4, label: t("الملخص والدفع", "Summary and payment") },
  ];

  return (
    <div className="w-full bg-white px-2 pt-2 pb-1.5 sm:px-3 sm:pt-4 sm:pb-3" dir={dir}>
      <div className="mx-auto flex w-full max-w-[1100px] items-start justify-between gap-1">
        {steps.map((s, idx) => {
          const isActive = s.id === current;
          const isDone = s.id < current;
          // bcare: completed = orange, current = blue, future = grey
          const circleCls = isActive
            ? "bg-brand-blue"
            : isDone
              ? "bg-brand-orange"
              : "bg-muted-foreground/40";
          const labelCls = isActive
            ? "text-brand-blue"
            : isDone
              ? "text-brand-orange"
              : "text-muted-foreground/70";
          return (
            <div key={s.id} className="flex flex-1 items-start">
              <div className="flex min-w-0 flex-col items-center gap-1 sm:gap-1.5">
                <div
                  className={cn(
                    "grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-extrabold text-white sm:h-10 sm:w-10 sm:text-[15px]",
                    circleCls,
                  )}
                >
                  {s.id}
                </div>
                <span
                  className={cn(
                    "text-center text-[8px] font-bold leading-tight sm:text-[12px]",
                    labelCls,
                  )}
                >
                  {s.label}
                </span>
              </div>
              {idx < steps.length - 1 && (
                <div className="mx-1 mt-3 h-[2px] flex-1 bg-muted-foreground/30 sm:mt-5" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default QuoteSteps;
