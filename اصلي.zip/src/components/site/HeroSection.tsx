import { useState } from "react";
import InsuranceTabs, { TabKey } from "./InsuranceTabs";
import QuoteForm from "./QuoteForm";
import { useDesktopSite } from "@/hooks/use-desktop-site";
import { useI18n } from "@/lib/i18n";
import heroPromo from "@/assets/hero-promo.jpeg.asset.json";

const DESKTOP_FRAME_WIDTH = 1120;

const HeroSection = () => {
  const [tab, setTab] = useState<TabKey>("car");
  const { isDesktopSite, scale } = useDesktopSite();
  const { t } = useI18n();

  if (isDesktopSite) {
    return (
      <section className="relative overflow-hidden bg-background">
        <div className="px-1 pb-6">
          <div className="mx-auto w-[1120px]" style={{ zoom: scale }}>
            <div className="mx-auto max-w-[1120px] bg-transparent pt-0 shadow-none">
              <InsuranceTabs active={tab} onChange={setTab} desktopSite />
            </div>

            <img
              src={heroPromo.url}
              alt={t(
                "عرض تربحك ثلاث سيارات جينيسيس",
                "Win three Genesis cars promotion",
              )}
              className="w-full"
            />

            <div className="bg-white px-0 pb-6 pt-1 shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
              <div className="mx-auto max-w-[1100px]">
                <QuoteForm desktopSite />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative lg:bg-muted/30">
      {/* Tabs strip — sits above the promo image */}
      <div className="lg:mt-0">
        <div className="mx-auto max-w-[420px] bg-white pt-2 shadow-[0_-2px_12px_rgba(0,0,0,0.04)] lg:max-w-[1120px] lg:rounded-none lg:bg-transparent lg:pt-0 lg:shadow-none">
          <InsuranceTabs active={tab} onChange={setTab} />
        </div>
        <div className="mx-auto h-2 max-w-[420px] bg-muted/40 lg:hidden" />
      </div>

      {/* Promo hero image — contained and centered on desktop */}
      <div className="lg:bg-muted/30 lg:px-4">
        <img
          src={heroPromo.url}
          alt={t(
            "عرض تربحك ثلاث سيارات جينيسيس",
            "Win three Genesis cars promotion",
          )}
          className="w-full lg:mx-auto lg:max-w-[1120px] lg:rounded-2xl lg:shadow-[0_4px_24px_rgba(0,0,0,0.08)]"
        />
      </div>

      {/* Form — flat bar on desktop, no card border */}
      <div className="bg-muted/40 px-2 pb-6 pt-2 lg:bg-white lg:px-0 lg:pb-6 lg:pt-1 lg:shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
        <div className="mx-auto max-w-[420px] lg:max-w-[1100px]">
          <QuoteForm />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
