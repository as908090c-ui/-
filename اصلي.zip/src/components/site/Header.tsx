import logo from "@/assets/bcare-logo.svg";
import { useI18n } from "@/lib/i18n";

const Header = () => {
  const { isAr, toggleLang, t } = useI18n();

  return (
    <header className="bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-3 py-1.5 sm:px-4 sm:py-4">
        <div className="flex items-center gap-2">
          <button
            onClick={toggleLang}
            className="rounded-full border border-brand-blue/30 px-3 py-1 text-xs font-bold text-brand-blue transition hover:bg-brand-blue/5 sm:text-sm"
            aria-label={isAr ? "Switch language to English" : "التبديل إلى العربية"}
          >
            {isAr ? "EN" : "عربي"}
          </button>
        </div>

        <a
          href="/"
          aria-label={t("بي كير - الصفحة الرئيسية", "Bcare - Home")}
          className="shrink-0"
        >
          <img src={logo} alt="Bcare" className="h-9 w-auto sm:h-16" />
        </a>

        <div className="min-w-8" />
      </div>
    </header>
  );
};

export default Header;
