import { FileText, MapPinned, Gauge, Wallet, Flame, Layers, BadgePercent } from "lucide-react";
import { useI18n } from "@/lib/i18n";

const WhyBcareSection = () => {
  const { t, isAr } = useI18n();

  const ITEMS = [
    { Icon: FileText, label: t("عروض تفهمك", "Offers that understand you") },
    { Icon: MapPinned, label: t("منك وفيك", "Local and personal") },
    { Icon: Gauge, label: t("إصدار سريع", "Fast issuance") },
    { Icon: Wallet, label: t("سعر يرضيك", "A price you'll like") },
    { Icon: Flame, label: t("نفزع لك", "We're here for you") },
    { Icon: Layers, label: t("نقّسط تأمينك", "Installments available") },
  ];

  return (
    <section className="px-4 py-10" aria-labelledby="why-title">
      <div className="mx-auto max-w-md text-center sm:max-w-3xl">
        <div className="mx-auto mb-8 flex max-w-4xl items-center justify-center gap-4 rounded-2xl bg-white p-5 shadow-soft">
          <BadgePercent className="h-10 w-10 shrink-0 text-brand-blue" strokeWidth={1.8} />
          <p className={`${isAr ? "text-right" : "text-left"} text-sm font-bold leading-relaxed text-brand-blue sm:text-base`}>
            {t(
              "خصومات وريف لعملاء بي كير على أكثر من ١٠٠ متجر وخدمة",
              "Discounts and perks for Bcare customers at more than 100 stores and services",
            )}
          </p>
        </div>


        <h2 id="why-title" className="text-2xl font-black leading-snug text-brand-blue">
          {t("ليش بي كير خيارك الأول في التأمين؟", "Why is Bcare your first choice for insurance?")}
        </h2>

        <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3">
          {ITEMS.map(({ Icon, label }) => (
            <div key={label} className="flex flex-col items-center gap-3">
              <Icon className="h-12 w-12 text-brand-blue" strokeWidth={1.8} />
              <span className="text-sm font-bold text-brand-blue">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyBcareSection;
