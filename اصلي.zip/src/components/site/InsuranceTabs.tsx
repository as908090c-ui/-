import type { ComponentType } from "react";
import { HeartPulse, Stethoscope, Plane, Activity, Home } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";
import { CarFrontIcon } from "./icons/CarFrontIcon";

export type TabKey = "car" | "medical" | "malpractice" | "travel" | "health" | "domestic";

type TabIcon = ComponentType<{ className?: string; strokeWidth?: number }>;

interface Props {
  active: TabKey;
  onChange: (k: TabKey) => void;
  desktopSite?: boolean;
}

const InsuranceTabs = ({ active, onChange, desktopSite = false }: Props) => {
  const { t } = useI18n();

  // DOM order matters in RTL: first item appears on the right.
  // In the original screenshot, "مركبات" is the active tab on the right.
  const TABS: { key: TabKey; label: string; Icon: TabIcon }[] = [
    { key: "car", label: t("المركبات", "Vehicles"), Icon: CarFrontIcon },
    { key: "medical", label: t("طبي", "Medical"), Icon: HeartPulse },
    { key: "malpractice", label: t("أخطاء طبية", "Malpractice"), Icon: Stethoscope },
    { key: "travel", label: t("سفر", "Travel"), Icon: Plane },
    { key: "health", label: t("طبي", "Health"), Icon: Activity },
    { key: "domestic", label: t("العمالة المنزلية", "Domestic workers"), Icon: Home },
  ];

  return (
    <div
      className={cn(
        "grid grid-cols-6 items-stretch gap-0 px-0.5",
        desktopSite ? "pt-2" : "lg:flex lg:justify-end lg:gap-0 lg:px-0 lg:pt-2",
      )}
      role="tablist"
      aria-label={t("أنواع التأمين", "Insurance types")}
    >
      {TABS.map(({ key, label, Icon }) => {
        const isActive = active === key;
        return (
          <button
            key={key}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(key)}
            className={cn(
              "relative flex min-w-0 flex-col items-center transition-colors",
              desktopSite
                ? "gap-1 px-2 pb-2.5 pt-2"
                : "gap-1.5 px-0.5 pb-2.5 pt-3 lg:min-w-[78px] lg:gap-1 lg:px-3 lg:pb-2.5 lg:pt-2",
              isActive ? "text-brand-blue-dark" : "text-brand-blue/60 hover:text-brand-blue",
            )}
          >
            <Icon
              className={cn(
                "shrink-0",
                key === "car"
                  ? desktopSite
                    ? "h-[22px] w-[22px]"
                    : "h-[26px] w-[26px] lg:h-[22px] lg:w-[22px]"
                  : desktopSite
                    ? "h-5 w-5"
                    : "h-6 w-6 lg:h-5 lg:w-5",
              )}
              strokeWidth={2.2}
            />
            <span className={cn("block w-full break-words text-center font-bold leading-tight", desktopSite ? "text-[12px]" : "text-[10px] lg:text-[12px]")}>
              {label}
            </span>
            {isActive && (
              <span className={cn("absolute bottom-0 rounded-full bg-brand-orange", desktopSite ? "left-2 right-2 h-[3px]" : "left-1 right-1 h-1 lg:left-2 lg:right-2 lg:h-[3px]")} />
            )}
          </button>
        );
      })}
    </div>
  );
};

export default InsuranceTabs;
