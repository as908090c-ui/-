interface Props {
  className?: string;
  strokeWidth?: number;
}

/**
 * Solid front-view vehicle glyph: roof + windscreen + two round headlights
 * rendered as negative space, with the wheel arches cut out along the bottom.
 */
export const CarFrontIcon = ({ className }: Props) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
    focusable="false"
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M6.2 2.5H17.8C18.9 2.5 19.9 3.2 20.3 4.3L21.6 8.6C21.9 9.5 22 10.5 22 11.4V18.8C22 19.6 21.4 20.2 20.6 20.2H17.6C16.8 20.2 16.2 19.6 16.2 18.8V17.6H7.8V18.8C7.8 19.6 7.2 20.2 6.4 20.2H3.4C2.6 20.2 2 19.6 2 18.8V11.4C2 10.5 2.1 9.5 2.4 8.6L3.7 4.3C4.1 3.2 5.1 2.5 6.2 2.5ZM7.6 5.2H16.4C17 5.2 17.5 5.6 17.7 6.2L18.4 8.4C18.6 9 18.2 9.5 17.6 9.5H6.4C5.8 9.5 5.4 9 5.6 8.4L6.3 6.2C6.5 5.6 7 5.2 7.6 5.2ZM5.2 12.6A1.7 1.7 0 1 0 8.6 12.6A1.7 1.7 0 1 0 5.2 12.6ZM15.4 12.6A1.7 1.7 0 1 0 18.8 12.6A1.7 1.7 0 1 0 15.4 12.6Z"
    />
  </svg>
);

export default CarFrontIcon;
