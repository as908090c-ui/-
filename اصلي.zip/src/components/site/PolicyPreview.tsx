import { X } from "lucide-react";
import { useEffect } from "react";
import bcareLogo from "@/assets/bcare-logo.svg";
import { insurerLogos } from "@/data/insurer-logos";
import { useI18n } from "@/lib/i18n";
import { trOffer } from "@/lib/offer-text";

export type PolicyData = {
  company: string;
  companyId?: string;
  type: string; // شامل / ضد الغير
  price: number;
  // insured person
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  // vehicle
  brand?: string;
  year?: string;
  estValue?: string;
  purpose?: string;
  repairPlace?: string;
  docType?: string;
  // policy meta
  startDate?: string;
  // coverage
  mainCoverage?: string;
  addons?: { label: string; price?: number }[];
  // payment (after successful purchase)
  paid?: boolean;
  total?: number;
  method?: string;
  cardBrand?: string;
  cardLast4?: string;
};

const InfoRow = ({ label, value, accent }: { label: string; value: string; accent?: "blue" | "orange" | "red" }) => {
  const valueCls =
    accent === "orange"
      ? "text-brand-orange"
      : accent === "red"
        ? "text-red-500"
        : "text-brand-blue";
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 py-2.5 text-[12.5px] sm:text-[13px]">
      <span className="text-muted-foreground">{label}:</span>
      <span className={`font-extrabold ${valueCls}`}>{value || "—"}</span>
    </div>
  );
};

const SectionHead = ({ n, title }: { n: number; title: string }) => (
  <div className="mt-5 mb-2">
    <div className="flex items-center justify-end gap-2.5">
      <h3 className="text-[15px] font-extrabold text-brand-blue sm:text-[16px]">{title}</h3>
      <div className="grid h-7 w-7 place-items-center rounded-full bg-brand-orange text-[12px] font-extrabold text-white sm:h-8 sm:w-8 sm:text-[13px]">
        {n}
      </div>
    </div>
    <div className="mt-1.5 h-[3px] w-full rounded-full bg-brand-orange/70" />
  </div>
);

const InfoBox = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-xl border border-border bg-[hsl(210_40%_97%)] p-3 text-center">
    <div className="text-[11px] text-muted-foreground sm:text-[12px]">{label}</div>
    <div className="mt-1 text-[13px] font-extrabold text-brand-blue sm:text-[14px]">{value}</div>
  </div>
);

const generatePolicyNumber = () => {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ123456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return `POL-${s}-2026`;
};

const PolicyPreview = ({
  open,
  onClose,
  data,
}: {
  open: boolean;
  onClose: () => void;
  data: PolicyData;
}) => {
  const { t, dir, isAr } = useI18n();

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!open) return null;

  const policyNumber = generatePolicyNumber();
  const vat = +(data.price * 0.15).toFixed(2);
  const total = +(data.price + vat).toFixed(2);
  const companyLogo = data.companyId ? insurerLogos[data.companyId] : undefined;

  // Build coverage list
  const coverageList: string[] = [];
  if (data.mainCoverage) coverageList.push(trOffer(data.mainCoverage, isAr));
  (data.addons || []).forEach((a) => coverageList.push(trOffer(a.label, isAr)));

  return (
    <div
      dir={dir}
      className="fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-black/60 sm:px-6 sm:py-10"
      style={{ WebkitOverflowScrolling: "touch" }}
      onClick={onClose}
    >
      <div
        className="relative min-h-screen w-full max-w-[820px] overflow-hidden bg-white shadow-2xl sm:min-h-0 sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div className="flex items-center justify-between gap-3 bg-brand-blue px-4 py-3.5 sm:px-5 sm:py-4">
          <button
            type="button"
            onClick={onClose}
            aria-label={t("إغلاق", "Close")}
            className="grid h-9 w-9 place-items-center rounded-full text-white transition-colors hover:bg-white/10"
          >
            <X className="h-5 w-5" strokeWidth={2.4} />
          </button>
          <h2 className="text-[16px] font-extrabold text-white sm:text-[18px]">
            {t("معاينة وثيقة التأمين", "Insurance policy preview")}
          </h2>
        </div>

        {/* Document body */}
        <div className="relative overflow-hidden p-4 sm:p-6">
          {/* Top accent gradient bar */}
          <div className="mb-4 h-[5px] w-full rounded-full bg-gradient-to-l from-brand-blue via-brand-orange to-brand-blue/40" />

          {/* watermark */}
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            {data.paid ? (
              <div className="-rotate-[28deg] select-none whitespace-pre text-center text-[30px] font-extrabold leading-tight text-emerald-300/50 sm:text-[40px]">
                {t("وثيقة سارية\nومكتملة", "Valid and\ncomplete policy")}
              </div>
            ) : (
              <div className="-rotate-[28deg] select-none whitespace-pre text-center text-[28px] font-extrabold leading-tight text-red-200/40 sm:text-[36px]">
                {t(
                  "مسودة\nواكتمال بحاجة إلى\nإجراءات تسديد الرسوم\nمع نجم المرور",
                  "Draft\ncompletion requires\nfee payment procedures\nwith Najm Traffic",
                )}
              </div>
            )}
          </div>

          {/* Logos row */}
          <div className="relative flex items-center justify-between gap-4">
            <div className="text-center">
              <img src={bcareLogo} alt="Bcare" className="h-10 sm:h-12" />
              <div className="mt-1 text-[10px] font-bold text-muted-foreground sm:text-[11px]">
                {t("وسيط تأمين معتمد", "Licensed insurance broker")}
              </div>
            </div>

            <div className="flex items-center gap-3">
              {companyLogo && (
                <img
                  src={companyLogo}
                  alt={trOffer(data.company, isAr)}
                  className="h-12 w-auto max-w-[150px] object-contain sm:h-14"
                />
              )}
              <div className={isAr ? "text-right" : "text-left"}>
                <div className="text-[14px] font-extrabold text-brand-blue sm:text-[15px]">
                  {trOffer(data.company, isAr)}
                </div>
                <div className="mt-0.5 text-[10px] leading-snug text-muted-foreground sm:text-[11px]">
                  {t("شركة تأمين مرخصة من البنك المركزي السعودي", "Insurance company licensed by the Saudi Central Bank")}
                </div>
              </div>
            </div>
          </div>

          {/* Title card */}
          <div className="relative mt-5 rounded-xl border-2 border-brand-blue bg-brand-blue/5 px-4 py-3 text-center sm:py-4">
            <h1 className="text-[18px] font-extrabold text-brand-blue sm:text-[22px]">
              {t(
                `وثيقة تأمين ${data.type === "شامل" ? "شامل" : "ضد الغير"} للمركبات`,
                `${data.type === "شامل" ? "Comprehensive" : "Third-party"} vehicle insurance policy`,
              )}
            </h1>
            <div className="mt-1 text-[11px] text-muted-foreground sm:text-[12px]">
              Insurance Policy Document
            </div>
          </div>

          {/* Policy meta boxes */}
          <div className="relative mt-4 grid grid-cols-2 gap-3">
            <InfoBox label={t("رقم الوثيقة", "Policy number")} value={policyNumber} />
            <InfoBox label={t("تاريخ بدء التأمين", "Insurance start date")} value={data.startDate || t("23 أبريل 2026", "April 23, 2026")} />
            <InfoBox
              label={t("تاريخ انتهاء التأمين", "Insurance end date")}
              value={t("23 أبريل 2027", "April 23, 2027")}
            />
            <InfoBox
              label={t("حالة الوثيقة", "Policy status")}
              value={data.paid ? t("مكتملة وسارية", "Complete and valid") : t("بإنتظار الدفع", "Awaiting payment")}
            />
          </div>

          {/* Section 1: Insured */}
          <div className="relative">
            <SectionHead n={1} title={t("بيانات المؤمن له", "Insured person details")} />
            <InfoRow label={t("الاسم الكامل", "Full name")} value={data.fullName || "—"} />
            <InfoRow label={t("تاريخ الميلاد", "Date of birth")} value={data.birthDate || "—"} />
            <InfoRow label={t("رقم الهوية", "ID number")} value={data.identity || "—"} />
            <InfoRow label={t("رقم الجوال", "Mobile number")} value={data.phone || "—"} />
            <InfoRow label={t("نوع التأمين", "Insurance type")} value={t(`تأمين ${data.type}`, `${data.type === "شامل" ? "Comprehensive" : "Third-party"} insurance`)} accent="orange" />
            <InfoRow label={t("شركة التأمين", "Insurance company")} value={trOffer(data.company, isAr)} />
            <InfoRow
              label={t("حالة الوثيقة", "Policy status")}
              value={
                data.paid
                  ? t("الوثيقة سارية ومكتملة", "The policy is valid and complete")
                  : t("بإنتظار الدفع وإستكمال الإجراءات", "Awaiting payment and completion of procedures")
              }
              accent={data.paid ? undefined : "red"}
            />
          </div>

          {/* Section 2: Vehicle */}
          <div className="relative">
            <SectionHead n={2} title={t("بيانات المركبة", "Vehicle details")} />
            <InfoRow label={t("ماركة ونوع المركبة", "Vehicle make and model")} value={data.brand || "—"} />
            <InfoRow label={t("سنة الصنع", "Manufacturing year")} value={data.year || "—"} />
            <InfoRow
              label={t("القيمة التقديرية", "Estimated value")}
              value={data.estValue ? t(`${data.estValue} ريال`, `SAR ${data.estValue}`) : "—"}
            />
            <InfoRow label={t("الغرض من الاستخدام", "Purpose of use")} value={data.purpose || "—"} />
            <InfoRow label={t("مكان إصلاح المركبة", "Vehicle repair location")} value={data.repairPlace || "—"} />
            <InfoRow label={t("نوع تسجيل المركبة", "Vehicle registration type")} value={data.docType || t("استمارة", "Form")} />
            <InfoRow
              label={t("الرقم التسلسلي", "Serial number")}
              value={String(Math.floor(10000000000 + Math.random() * 89999999999))}
            />
          </div>

          {/* Section 3: Coverage */}
          <div className="relative">
            <SectionHead n={3} title={t("تفاصيل التغطية", "Coverage details")} />
            <div className="rounded-xl border border-border bg-[hsl(210_40%_97%)] p-3.5 sm:p-4">
              <ul className="space-y-2.5">
                {coverageList.map((c, i) => (
                  <li
                    key={i}
                    className={`flex items-start justify-end gap-2.5 ${isAr ? "text-right" : "text-left"} text-[12.5px] leading-relaxed text-brand-blue sm:text-[13px]`}
                  >
                    <span className="flex-1">{c}</span>
                    <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-orange" />
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Section 4: Financial summary */}
          <div className="relative">
            <SectionHead n={4} title={t("الملخص المالي", "Financial summary")} />
            <div className="overflow-hidden rounded-xl border border-border">
              <div className="flex items-center justify-between gap-3 border-b border-border bg-white px-4 py-3 text-[12.5px] sm:text-[13px]">
                <span className="text-brand-blue/80">{t("رسوم التأمين الأساسية:", "Base insurance fee:")}</span>
                <span className="font-extrabold text-brand-blue">{t(`${data.price.toFixed(2)} ر.س`, `SAR ${data.price.toFixed(2)}`)}</span>
              </div>
              <div className="flex items-center justify-between gap-3 border-b border-border bg-white px-4 py-3 text-[12.5px] sm:text-[13px]">
                <span className="text-brand-blue/80">{t("ضريبة القيمة المضافة (15%):", "VAT (15%):")}</span>
                <span className="font-extrabold text-brand-blue">{t(`${vat.toFixed(2)} ر.س`, `SAR ${vat.toFixed(2)}`)}</span>
              </div>
              <div className="flex items-center justify-between gap-3 bg-brand-blue/10 px-4 py-3.5 text-[14px] sm:text-[15px]">
                <span className="font-extrabold text-brand-blue">{t("المبلغ الإجمالي:", "Total amount:")}</span>
                <span className="font-extrabold text-brand-blue">{t(`${total.toFixed(2)} ر.س`, `SAR ${total.toFixed(2)}`)}</span>
              </div>
            </div>
          </div>

          {/* Terms */}
          <div className="relative mt-5 rounded-xl border border-border bg-[hsl(210_40%_97%)] p-4">
            <h4 className={`mb-2 ${isAr ? "text-right" : "text-left"} text-[14px] font-extrabold text-brand-blue sm:text-[15px]`}>
              {t("الشروط والأحكام العامة:", "General terms and conditions:")}
            </h4>
            <ul className={`space-y-1.5 pr-4 ${isAr ? "text-right" : "text-left"} text-[12px] leading-relaxed text-brand-blue/85 sm:text-[12.5px]`}>
              <li className="list-disc">
                {t(
                  "هذه الوثيقة صادرة وفقاً لأحكام نظام مراقبة شركات التأمين التعاوني ولائحته التنفيذية.",
                  "This document is issued in accordance with the provisions of the Cooperative Insurance Companies Control Law and its implementing regulations.",
                )}
              </li>
              <li className="list-disc">{t("مدة التغطية التأمينية سنة هجرية واحدة من تاريخ الإصدار.", "The insurance coverage period is one Hijri year from the issuance date.")}</li>
              <li className="list-disc">
                {t(
                  "يلتزم المؤمن له بالإفصاح عن جميع المعلومات الجوهرية المتعلقة بالخطر المؤمن عليه.",
                  "The insured is obligated to disclose all material information related to the insured risk.",
                )}
              </li>
              <li className="list-disc">
                {t(
                  "في حال وقوع حادث يجب إبلاغ الشركة خلال 15 يوم عمل من تاريخ الحادث.",
                  "In the event of an accident, the company must be notified within 15 business days of the accident date.",
                )}
              </li>
              <li className="list-disc">
                {t(
                  "تخضع هذه الوثيقة لأنظمة المملكة العربية السعودية والاختصاص القضائي لمحاكمها.",
                  "This document is subject to the laws of the Kingdom of Saudi Arabia and the jurisdiction of its courts.",
                )}
              </li>
            </ul>
          </div>

          {/* Footer */}
          <div className="relative mt-5 border-t-2 border-brand-blue pt-4">
            <div className="flex items-center justify-between gap-4">
              <div className="text-center">
                <div className="h-px w-24 bg-muted-foreground/40" />
                <div className="mt-1.5 text-[11px] text-muted-foreground sm:text-[12px]">
                  {t("ختم الشركة", "Company stamp")}
                </div>
              </div>
              <div className="text-center text-[11px] leading-relaxed text-muted-foreground sm:text-[12px]">
                <div>{t("تم الإصدار إلكترونياً عبر منصة بي كير", "Issued electronically via the Bcare platform")}</div>
                <div className="mt-0.5">{t("هذه الوثيقة إلكترونية ولا تحتاج إلى توقيع أو ختم", "This is an electronic document and does not require a signature or stamp")}</div>
              </div>
              <div className="text-center">
                <div className="h-px w-24 bg-muted-foreground/40" />
                <div className="mt-1.5 text-[11px] text-muted-foreground sm:text-[12px]">
                  {t("توقيع المؤمن له", "Insured's signature")}
                </div>
              </div>
            </div>
            <div className="mt-3 h-[5px] w-full rounded-full bg-gradient-to-r from-brand-orange via-brand-blue to-brand-orange" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PolicyPreview;
