import { useEffect, useMemo, useRef, useState } from "react";
import { MessageCircle, Send, Phone, User as UserIcon, Trash2, ArrowRight, Ban, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  type ChatConversation,
  type ChatMessage,
  deleteConversation,
  listConversations,
  listMessages,
  markRead,
  sendMessage,
  listChatBlocked,
  blockChat,
  unblockChat,
} from "@/lib/chat";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const ChatPanel = () => {
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [showList, setShowList] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const activeIdRef = useRef<string | null>(null);
  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);

  const [blocked, setBlocked] = useState<string[]>([]);

  const refresh = async () => setConversations(await listConversations());
  const refreshBlocked = async () => setBlocked(await listChatBlocked());
  useEffect(() => {
    refreshBlocked();
  }, []);

  const toggleBlock = async (visitorId: string) => {
    if (!visitorId) return;
    const isBlocked = blocked.includes(visitorId);
    const ok = isBlocked ? await unblockChat(visitorId) : await blockChat(visitorId);
    if (!ok) return toast.error(isBlocked ? "فشل فك الحظر" : "فشل حظر المحادثة");
    toast.success(isBlocked ? "تم فك حظر المحادثة" : "تم حظر المحادثة");
    await refreshBlocked();
  };


  // Initial load + realtime for conversation list
  useEffect(() => {
    refresh();
    const channel = supabase
      .channel("admin-chat-conversations")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_conversations" },
        () => refresh(),
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages" },
        (payload) => {
          const msg = payload.new as ChatMessage;
          if (msg.sender === "customer" && msg.conversation_id !== activeIdRef.current) {
            toast.success("رسالة جديدة من عميل");
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Load messages + subscribe when active conversation changes
  const broadcastRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    (async () => {
      setMessages(await listMessages(activeId));
      await markRead(activeId, "admin");
    })();
    const handleIncoming = (msg: ChatMessage) => {
      setMessages((prev) =>
        prev.find((m) => m.id === msg.id) ? prev : [...prev, msg],
      );
      if (msg.sender === "customer") markRead(activeId, "admin");
    };
    const channel = supabase
      .channel(`chat-${activeId}`, { config: { broadcast: { self: false } } })
      .on("broadcast", { event: "msg" }, (payload) => {
        handleIncoming(payload.payload as ChatMessage);
      })
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `conversation_id=eq.${activeId}`,
        },
        (payload) => handleIncoming(payload.new as ChatMessage),
      )
      .subscribe();
    broadcastRef.current = channel;
    return () => {
      broadcastRef.current = null;
      supabase.removeChannel(channel);
    };
  }, [activeId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const active = useMemo(
    () => conversations.find((c) => c.id === activeId) || null,
    [conversations, activeId],
  );

  const handleSend = async () => {
    if (!activeId || !draft.trim()) return;
    const text = draft.trim();
    const optimisticMessage: ChatMessage = {
      id: `pending-admin-${Date.now()}`,
      conversation_id: activeId,
      sender: "admin",
      content: text,
      created_at: new Date().toISOString(),
    };
    setSending(true);
    setDraft("");
    setMessages((prev) => [...prev, optimisticMessage]);
    const sentMessage = await sendMessage(activeId, "admin", text);
    setSending(false);
    if (!sentMessage) {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMessage.id));
      setDraft(text);
      toast.error("تعذّر إرسال الرسالة");
      return;
    }
    setMessages((prev) => {
      const withoutPending = prev.filter((m) => m.id !== optimisticMessage.id);
      return withoutPending.find((m) => m.id === sentMessage.id)
        ? withoutPending
        : [...withoutPending, sentMessage];
    });
    broadcastRef.current?.send({ type: "broadcast", event: "msg", payload: sentMessage });
    toast.success("تم إرسال الرسالة إلى العميل");
  };

  const handleDelete = async (id: string) => {
    if (!confirm("حذف هذه المحادثة نهائياً؟")) return;
    await deleteConversation(id);
    if (activeId === id) setActiveId(null);
    await refresh();
    toast.success("تم حذف المحادثة");
  };

  const totalUnread = conversations.reduce((s, c) => s + (c.unread_admin || 0), 0);

  return (
    <div className="overflow-hidden rounded-2xl border border-white/60 bg-white shadow-card">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2 text-brand-blue">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand-blue to-[hsl(205_78%_26%)] text-white">
            <MessageCircle className="h-4 w-4" />
          </div>
          <div className="leading-tight">
            <h2 className="text-[14px] font-extrabold">دردشة العملاء</h2>
            <div className="text-[11px] text-muted-foreground">
              تحديث لحظي · {conversations.length} محادثة
            </div>
          </div>
        </div>
        {totalUnread > 0 && (
          <div className="rounded-full bg-emerald-500 px-2.5 py-0.5 text-[11px] font-extrabold text-white">
            {totalUnread} غير مقروءة
          </div>
        )}
      </div>

      <div className="grid h-[70vh] min-h-[480px] max-h-[640px] grid-cols-1 md:grid-cols-[280px_1fr]">
        {/* List */}
        <aside
          className={cn(
            "min-h-0 border-l border-border bg-muted/20 md:block",
            showList || !activeId ? "block" : "hidden",
          )}
        >
          <div className="h-full overflow-y-auto">
            {conversations.length === 0 && (
              <div className="px-4 py-10 text-center text-[12.5px] text-muted-foreground">
                لا توجد محادثات بعد.
              </div>
            )}
            {conversations.map((c) => {
              const isActive = c.id === activeId;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setActiveId(c.id);
                    setShowList(false);
                  }}
                  className={cn(
                    "group flex w-full items-start gap-2 border-b border-border/50 px-3 py-3 text-right transition-colors",
                    isActive ? "bg-brand-blue/10" : "hover:bg-white",
                  )}
                >
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-blue/15 to-violet-300/40 text-[12px] font-extrabold text-brand-blue">
                    {c.customer_name.slice(0, 1)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-[13px] font-extrabold text-brand-blue">
                        {c.customer_name}
                      </span>
                      {c.unread_admin > 0 && (
                        <span className="rounded-full bg-emerald-500 px-1.5 py-0.5 text-[10px] font-extrabold text-white">
                          {c.unread_admin}
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1 text-[11px] text-muted-foreground" dir="ltr">
                      <Phone className="h-3 w-3" />
                      {c.customer_phone}
                    </div>
                    <div className="mt-0.5 text-[10.5px] text-muted-foreground">
                      {new Date(c.last_message_at).toLocaleString("ar-SA", {
                        hour: "2-digit",
                        minute: "2-digit",
                        day: "2-digit",
                        month: "2-digit",
                      })}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Conversation */}
        <section
          className={cn(
            "flex min-h-0 flex-col",
            showList && !activeId ? "hidden md:flex" : "flex",
          )}
        >
          {!active ? (
            <div className="grid flex-1 place-items-center px-4 text-center text-[12.5px] text-muted-foreground">
              اختر محادثة من القائمة لعرض الرسائل.
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2 border-b border-border bg-white px-3 py-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setActiveId(null);
                    setShowList(true);
                  }}
                  className="grid h-8 w-8 place-items-center rounded-lg text-brand-blue hover:bg-muted/50 md:hidden"
                  aria-label="رجوع"
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-blue/15 to-violet-300/40 text-[12px] font-extrabold text-brand-blue">
                    {active.customer_name.slice(0, 1)}
                  </div>
                  <div className="min-w-0 leading-tight">
                    <div className="flex items-center gap-1.5 truncate text-[13.5px] font-extrabold text-brand-blue">
                      <UserIcon className="h-3.5 w-3.5" />
                      {active.customer_name}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground" dir="ltr">
                      <Phone className="h-3 w-3" />
                      {active.customer_phone}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => toggleBlock(active.visitor_id)}
                  className={cn(
                    "inline-flex h-8 items-center gap-1 rounded-lg px-2 text-[11.5px] font-bold",
                    blocked.includes(active.visitor_id)
                      ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                      : "bg-destructive/10 text-destructive hover:bg-destructive/20",
                  )}
                >
                  {blocked.includes(active.visitor_id) ? (
                    <>
                      <ShieldCheck className="h-3.5 w-3.5" />
                      <span>فك حظر المحادثة</span>
                    </>
                  ) : (
                    <>
                      <Ban className="h-3.5 w-3.5" />
                      <span>حظر المحادثة</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(active.id)}
                  className="grid h-8 w-8 place-items-center rounded-lg text-destructive hover:bg-destructive/10"
                  aria-label="حذف"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              <div ref={scrollRef} className="min-h-0 flex-1 space-y-2.5 overflow-y-auto bg-[hsl(210_40%_97%)] p-3">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    className={cn(
                      "flex",
                      m.sender === "admin" ? "justify-end" : "justify-start",
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[75%] rounded-2xl px-3 py-2 text-[13px] leading-6 shadow-sm",
                        m.sender === "admin"
                          ? "rounded-br-sm bg-gradient-to-l from-brand-blue to-[hsl(205_78%_26%)] text-white"
                          : "rounded-bl-sm bg-white text-brand-blue ring-1 ring-border/60",
                      )}
                    >
                      <div className="whitespace-pre-wrap break-words">{m.content}</div>
                      <div
                        className={cn(
                          "mt-1 text-[10px]",
                          m.sender === "admin" ? "text-white/70" : "text-muted-foreground",
                        )}
                        dir="ltr"
                      >
                        {new Date(m.created_at).toLocaleTimeString("ar-SA", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-end gap-2 border-t border-border bg-white p-2.5">
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value.slice(0, 1000))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  rows={1}
                  placeholder="اكتب الرد..."
                  className="max-h-28 min-h-[42px] flex-1 resize-none rounded-xl border border-[hsl(214_25%_88%)] bg-white px-3 py-2 text-[13.5px] text-brand-blue outline-none focus:border-brand-blue"
                />
                <button
                  type="button"
                  onClick={handleSend}
                  disabled={sending || !draft.trim()}
                  aria-label="إرسال"
                  className="grid h-[42px] w-[42px] shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-blue to-[hsl(205_78%_26%)] text-white shadow-soft hover:brightness-110 disabled:opacity-40"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
};

export default ChatPanel;
