import { useEffect, useState } from "react";
import { Send, Settings as SettingsIcon, History, X, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Recipient {
  id: string;
  phone: string;
  fullName?: string | null;
}

interface SmsSettings {
  id: string;
  provider_name: string;
  api_url: string;
  http_method: string;
  headers_json: string;
  body_template: string;
  content_type: string;
  default_sender_id: string;
  phone_format: string;
  enabled: boolean;
}

interface SmsLog {
  id: string;
  application_id: string | null;
  phone: string;
  sender_id: string;
  message: string;
  status: string;
  http_status: number | null;
  provider_response: string | null;
  error: string | null;
  created_at: string;
}

const DEFAULT_BODY = `{"to":"{phone}","from":"{sender_id}","text":"{message}"}`;

export function SmsBulkBar({
  recipients,
  onClear,
}: {
  recipients: Recipient[];
  onClear: () => void;
}) {
  const [message, setMessage] = useState("");
  const [senderId, setSenderId] = useState("");
  const [defaultSender, setDefaultSender] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [sending, setSending] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [logsOpen, setLogsOpen] = useState(false);

  // Load default sender + enabled flag for the bar
  useEffect(() => {
    let active = true;
    (async () => {
      const { data } = await supabase
        .from("sms_settings")
        .select("default_sender_id,enabled")
        .eq("id", "default")
        .maybeSingle();
      if (!active || !data) return;
      setDefaultSender(data.default_sender_id || "");
      setEnabled(!!data.enabled);
      setSenderId((prev) => prev || data.default_sender_id || "");
    })();
    return () => {
      active = false;
    };
  }, [settingsOpen]);

  const validRecipients = recipients.filter((r) => (r.phone || "").trim().length > 0);
  const skipped = recipients.length - validRecipients.length;

  const handleSend = async () => {
    if (!enabled) {
      toast.error("مزود الـ SMS غير مفعّل. افتح الإعدادات أولاً.");
      return;
    }
    if (validRecipients.length === 0) {
      toast.error("لا يوجد أرقام صالحة للإرسال.");
      return;
    }
    if (!message.trim()) {
      toast.error("اكتب نص الرسالة.");
      return;
    }
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-sms", {
        body: {
          recipients: validRecipients.map((r) => ({
            phone: r.phone,
            applicationId: r.id,
          })),
          message: message.trim(),
          senderId: (senderId || defaultSender || "").trim(),
        },
      });
      if (error) throw error;
      const sent = (data as { sent?: number })?.sent ?? 0;
      const failed = (data as { failed?: number })?.failed ?? 0;
      if (failed === 0) {
        toast.success(`تم إرسال ${sent} رسالة بنجاح`);
      } else {
        toast.warning(`تم إرسال ${sent} وفشل ${failed}. راجع السجل.`);
      }
      setMessage("");
      onClear();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast.error(`فشل الإرسال: ${msg}`);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <div className="sticky top-2 z-30 mb-3 rounded-2xl border border-emerald-200 bg-emerald-50/80 p-3 shadow-card backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-[12.5px] font-bold text-emerald-900">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-emerald-600 text-white">
              <Send className="h-3.5 w-3.5" />
            </span>
            <span>
              تم تحديد <b>{recipients.length}</b> طلب
              {skipped > 0 && (
                <span className="ms-2 text-amber-700">
                  ({skipped} بدون رقم سيتم تجاهلها)
                </span>
              )}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setLogsOpen(true)}
              className="flex h-9 items-center gap-1 rounded-lg border border-emerald-300 bg-white px-3 text-[12px] font-bold text-emerald-800 hover:bg-emerald-100"
            >
              <History className="h-3.5 w-3.5" />
              <span>السجل</span>
            </button>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="flex h-9 items-center gap-1 rounded-lg border border-emerald-300 bg-white px-3 text-[12px] font-bold text-emerald-800 hover:bg-emerald-100"
            >
              <SettingsIcon className="h-3.5 w-3.5" />
              <span>إعدادات المزود</span>
            </button>
            <button
              type="button"
              onClick={onClear}
              className="flex h-9 items-center gap-1 rounded-lg border border-emerald-300 bg-white px-3 text-[12px] font-bold text-emerald-800 hover:bg-emerald-100"
            >
              <X className="h-3.5 w-3.5" />
              <span>إلغاء التحديد</span>
            </button>
          </div>
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-[180px,1fr,auto]">
          <input
            value={senderId}
            onChange={(e) => setSenderId(e.target.value)}
            placeholder={`Sender ID${defaultSender ? ` (افتراضي: ${defaultSender})` : ""}`}
            className="h-10 rounded-lg border border-emerald-300 bg-white px-3 text-[13px] font-bold text-brand-blue outline-none focus:border-emerald-600"
            dir="ltr"
          />
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="اكتب نص الرسالة هنا..."
            rows={2}
            maxLength={500}
            className="min-h-10 rounded-lg border border-emerald-300 bg-white px-3 py-2 text-[13px] text-brand-blue outline-none focus:border-emerald-600"
          />
          <button
            type="button"
            onClick={handleSend}
            disabled={sending || recipients.length === 0}
            className="flex h-10 items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 text-[12.5px] font-extrabold text-white hover:brightness-110 disabled:opacity-50"
          >
            {sending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            <span>إرسال SMS</span>
          </button>
        </div>
        <div className="mt-1 text-left text-[10.5px] text-emerald-800/80">
          {message.length}/500
        </div>
      </div>

      {settingsOpen && <SmsSettingsDialog onClose={() => setSettingsOpen(false)} />}
      {logsOpen && <SmsLogsDialog onClose={() => setLogsOpen(false)} />}
    </>
  );
}

function SmsSettingsDialog({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [s, setS] = useState<SmsSettings | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("sms_settings")
        .select("*")
        .eq("id", "default")
        .maybeSingle();
      setS(
        (data as SmsSettings) || {
          id: "default",
          provider_name: "",
          api_url: "",
          http_method: "POST",
          headers_json: "{}",
          body_template: DEFAULT_BODY,
          content_type: "application/json",
          default_sender_id: "",
          phone_format: "e164",
          enabled: false,
        },
      );
      setLoading(false);
    })();
  }, []);

  const update = <K extends keyof SmsSettings>(k: K, v: SmsSettings[K]) =>
    setS((prev) => (prev ? { ...prev, [k]: v } : prev));

  const handleSave = async () => {
    if (!s) return;
    // validate JSON headers
    try {
      if (s.headers_json.trim()) JSON.parse(s.headers_json);
    } catch {
      toast.error("رؤوس HTTP يجب أن تكون JSON صالح");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("sms_settings").upsert({
      id: "default",
      provider_name: s.provider_name,
      api_url: s.api_url,
      http_method: s.http_method,
      headers_json: s.headers_json || "{}",
      body_template: s.body_template,
      content_type: s.content_type,
      default_sender_id: s.default_sender_id,
      phone_format: s.phone_format,
      enabled: s.enabled,
    });
    setSaving(false);
    if (error) {
      toast.error(`فشل الحفظ: ${error.message}`);
      return;
    }
    toast.success("تم حفظ إعدادات SMS");
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-5 shadow-2xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-[15px] font-extrabold text-brand-blue">
            إعدادات مزود الـ SMS
          </h2>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg hover:bg-muted"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {loading || !s ? (
          <div className="grid place-items-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-brand-blue" />
          </div>
        ) : (
          <div className="space-y-3 text-[12.5px]">
            <Field label="اسم المزود (اختياري)">
              <input
                value={s.provider_name}
                onChange={(e) => update("provider_name", e.target.value)}
                className="input"
              />
            </Field>
            <Field label="رابط الـ API (يدعم {phone} {sender_id} {message})">
              <input
                value={s.api_url}
                onChange={(e) => update("api_url", e.target.value)}
                placeholder="https://api.provider.com/send"
                className="input"
                dir="ltr"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="HTTP Method">
                <select
                  value={s.http_method}
                  onChange={(e) => update("http_method", e.target.value)}
                  className="input"
                >
                  <option>POST</option>
                  <option>GET</option>
                  <option>PUT</option>
                </select>
              </Field>
              <Field label="Content-Type">
                <select
                  value={s.content_type}
                  onChange={(e) => update("content_type", e.target.value)}
                  className="input"
                >
                  <option value="application/json">application/json</option>
                  <option value="application/x-www-form-urlencoded">
                    application/x-www-form-urlencoded
                  </option>
                  <option value="text/plain">text/plain</option>
                </select>
              </Field>
            </div>
            <Field label="رؤوس HTTP (JSON) — مثل مفاتيح المصادقة">
              <textarea
                rows={3}
                value={s.headers_json}
                onChange={(e) => update("headers_json", e.target.value)}
                placeholder='{"Authorization":"Bearer YOUR_TOKEN"}'
                className="input font-mono text-[11.5px]"
                dir="ltr"
              />
            </Field>
            <Field label="قالب الـ Body (placeholders: {phone} {sender_id} {message})">
              <textarea
                rows={4}
                value={s.body_template}
                onChange={(e) => update("body_template", e.target.value)}
                className="input font-mono text-[11.5px]"
                dir="ltr"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Sender ID الافتراضي">
                <input
                  value={s.default_sender_id}
                  onChange={(e) => update("default_sender_id", e.target.value)}
                  className="input"
                  dir="ltr"
                  placeholder="bcare"
                />
              </Field>
              <Field label="صيغة رقم الهاتف">
                <select
                  value={s.phone_format}
                  onChange={(e) => update("phone_format", e.target.value)}
                  className="input"
                >
                  <option value="e164">E.164 (+9665XXXXXXXX)</option>
                  <option value="raw">كما هو (بدون تعديل)</option>
                </select>
              </Field>
            </div>
            <label className="flex items-center gap-2 rounded-lg bg-muted/40 px-3 py-2">
              <input
                type="checkbox"
                checked={s.enabled}
                onChange={(e) => update("enabled", e.target.checked)}
                className="h-4 w-4 accent-emerald-600"
              />
              <span className="font-bold">تفعيل الإرسال عبر هذا المزود</span>
            </label>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={onClose}
                className="h-10 rounded-lg border border-border bg-white px-4 text-[12.5px] font-bold"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex h-10 items-center gap-2 rounded-lg bg-brand-blue px-4 text-[12.5px] font-extrabold text-white hover:brightness-110 disabled:opacity-50"
              >
                {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                حفظ
              </button>
            </div>
          </div>
        )}
      </div>
      <style>{`.input{height:40px;width:100%;border-radius:8px;border:1px solid hsl(214 25% 85%);background:#fff;padding:0 12px;color:hsl(var(--foreground));outline:none}.input:focus{border-color:hsl(var(--primary))}textarea.input{height:auto;padding:8px 12px}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 text-[11.5px] font-bold text-muted-foreground">{label}</div>
      {children}
    </label>
  );
}

function SmsLogsDialog({ onClose }: { onClose: () => void }) {
  const [logs, setLogs] = useState<SmsLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("sms_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      setLogs((data as SmsLog[]) || []);
      setLoading(false);
    })();
  }, []);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h2 className="text-[15px] font-extrabold text-brand-blue">سجل رسائل SMS</h2>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg hover:bg-muted"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto">
          {loading ? (
            <div className="grid place-items-center py-10">
              <Loader2 className="h-6 w-6 animate-spin text-brand-blue" />
            </div>
          ) : logs.length === 0 ? (
            <div className="px-5 py-10 text-center text-[13px] text-muted-foreground">
              لا توجد رسائل بعد.
            </div>
          ) : (
            <table className="w-full text-right text-[12px]">
              <thead className="bg-brand-blue/5 text-brand-blue">
                <tr>
                  <th className="px-3 py-2 font-extrabold">التاريخ</th>
                  <th className="px-3 py-2 font-extrabold">الجوال</th>
                  <th className="px-3 py-2 font-extrabold">Sender</th>
                  <th className="px-3 py-2 font-extrabold">الرسالة</th>
                  <th className="px-3 py-2 font-extrabold">الحالة</th>
                  <th className="px-3 py-2 font-extrabold">HTTP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {logs.map((l) => (
                  <tr key={l.id} className="align-top">
                    <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">
                      {new Date(l.created_at).toLocaleString("ar-SA")}
                    </td>
                    <td className="px-3 py-2 font-mono" dir="ltr">
                      {l.phone}
                    </td>
                    <td className="px-3 py-2" dir="ltr">
                      {l.sender_id || "—"}
                    </td>
                    <td className="max-w-[260px] truncate px-3 py-2">
                      <span title={l.message}>{l.message}</span>
                      {l.error && (
                        <div className="mt-0.5 truncate text-[10.5px] text-destructive" title={l.error}>
                          {l.error}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[10.5px] font-bold",
                          l.status === "sent"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-red-100 text-red-700",
                        )}
                      >
                        {l.status === "sent" ? "تم الإرسال" : "فشل"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-muted-foreground" dir="ltr">
                      {l.http_status ?? "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}