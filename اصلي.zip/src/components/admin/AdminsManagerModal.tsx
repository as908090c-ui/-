import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ADMIN_OWNER_EMAIL, isOwnerAdminEmail } from "@/lib/admin-allowlist";
import { AlertTriangle, LogOut, Shield, X } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export type OnlineAdmin = {
  instanceId: string;
  email: string;
  online_at: string;
};

export const ADMIN_CONTROL_CHANNEL = "admin-controls";

type Props = {
  open: boolean;
  onClose: () => void;
  meInstanceId: string;
  meEmail: string | null;
  admins: OnlineAdmin[];
};

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "الآن";
  if (m < 60) return `منذ ${m} دقيقة`;
  const h = Math.floor(m / 60);
  return `منذ ${h} ساعة`;
}

async function broadcast(event: "warn" | "kick", target: string, message?: string) {
  const ch = supabase.channel(ADMIN_CONTROL_CHANNEL, { config: { private: true } });
  return new Promise<boolean>((resolve) => {
    let done = false;
    const finish = (ok: boolean) => {
      if (done) return;
      done = true;
      supabase.removeChannel(ch);
      resolve(ok);
    };
    ch.subscribe((status) => {
      if (status === "SUBSCRIBED") {
        ch.send({ type: "broadcast", event, payload: { target, message } })
          .then(() => finish(true))
          .catch(() => finish(false));
      }
    });
    setTimeout(() => finish(false), 2500);
  });
}

const AdminsManagerModal = ({ open, onClose, meInstanceId, meEmail, admins }: Props) => {
  const [warnFor, setWarnFor] = useState<string | null>(null);
  const [warnText, setWarnText] = useState("");
  const [busy, setBusy] = useState(false);
  const isOwner = isOwnerAdminEmail(meEmail);

  if (!open) return null;

  const handleWarn = async (instanceId: string) => {
    const text = warnText.trim() || "تنبيه من المسؤول الرئيسي";
    setBusy(true);
    const ok = await broadcast("warn", instanceId, text);
    setBusy(false);
    if (ok) {
      toast.success("تم إرسال التحذير");
      setWarnFor(null);
      setWarnText("");
    } else toast.error("فشل إرسال التحذير");
  };

  const handleKick = async (instanceId: string, email: string) => {
    if (!confirm(`تسجيل خروج المسؤول "${email}" من لوحة التحكم؟`)) return;
    setBusy(true);
    const ok = await broadcast("kick", instanceId);
    setBusy(false);
    if (ok) toast.success("تم إرسال أمر تسجيل الخروج");
    else toast.error("فشل إرسال الأمر");
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-[10000] grid place-items-center bg-black/50 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md overflow-hidden rounded-2xl bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-100 text-emerald-700">
              <Shield className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-[14px] font-extrabold text-primary">إدارة المسؤولين</h2>
              <div className="text-[11px] text-muted-foreground">
                {isOwner
                  ? "يمكنك تحذير أو تسجيل خروج أي مسؤول"
                  : `الإدارة متاحة فقط للمسؤول الرئيسي (${ADMIN_OWNER_EMAIL})`}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-secondary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[60vh] divide-y divide-border overflow-y-auto">
          {admins.length === 0 && (
            <div className="px-4 py-8 text-center text-[13px] text-muted-foreground">
              لا يوجد مسؤولون متصلون.
            </div>
          )}
          {admins.map((a) => {
            const isMe = a.instanceId === meInstanceId;
            return (
              <div key={a.instanceId} className="px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="relative flex h-2.5 w-2.5">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
                      </span>
                      <span className="truncate text-[13px] font-extrabold text-primary" dir="ltr">
                        {a.email || "—"}
                      </span>
                      {isMe && (
                        <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-extrabold text-blue-700">
                          أنت
                        </span>
                      )}
                      {a.email === ADMIN_OWNER_EMAIL && (
                        <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-800">
                          رئيسي
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-[11px] text-muted-foreground">
                      نشط {timeAgo(a.online_at)}
                    </div>
                  </div>
                  {isOwner && !isMe && (
                    <div className="flex shrink-0 gap-1.5">
                      <button
                        onClick={() => setWarnFor((p) => (p === a.instanceId ? null : a.instanceId))}
                        className="flex h-9 items-center gap-1 rounded-lg bg-amber-500 px-2.5 text-[11px] font-extrabold text-white hover:brightness-110"
                      >
                        <AlertTriangle className="h-3.5 w-3.5" />
                        <span>تحذير</span>
                      </button>
                      <button
                        onClick={() => handleKick(a.instanceId, a.email)}
                        disabled={busy}
                        className="flex h-9 items-center gap-1 rounded-lg bg-red-600 px-2.5 text-[11px] font-extrabold text-white hover:bg-red-700 disabled:opacity-50"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        <span>خروج</span>
                      </button>
                    </div>
                  )}
                </div>

                {warnFor === a.instanceId && (
                  <div className="mt-2 flex gap-1.5">
                    <input
                      value={warnText}
                      onChange={(e) => setWarnText(e.target.value)}
                      placeholder="نص التحذير (اختياري)"
                      className="h-9 flex-1 rounded-lg border border-border bg-white px-2.5 text-[12px] outline-none focus:border-brand-blue"
                    />
                    <button
                      onClick={() => handleWarn(a.instanceId)}
                      disabled={busy}
                      className={cn(
                        "h-9 rounded-lg bg-amber-600 px-3 text-[11px] font-extrabold text-white hover:brightness-110",
                        busy && "opacity-50",
                      )}
                    >
                      إرسال
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AdminsManagerModal;
