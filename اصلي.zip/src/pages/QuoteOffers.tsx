import { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Check } from "lucide-react";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import FloatingButtons from "@/components/site/FloatingButtons";
import QuoteSteps from "@/components/site/QuoteSteps";
import { cn } from "@/lib/utils";
import { offers, type InsuranceOffer } from "@/data/insurance-offers";
import { insurerLogos } from "@/data/insurer-logos";
import { toast } from "sonner";
import SaudiRiyal from "@/components/icons/SaudiRiyal";
import { formatRiyal } from "@/lib/format-riyal";
import { useI18n } from "@/lib/i18n";
import { trOffer } from "@/lib/offer-text";

type VehicleSummary = {
  brand?: string;
  year?: string;
  estValue?: string;
  purpose?: string;
  repairPlace?: string;
  // pass-through personal data for policy preview
  fullName?: string;
  identity?: string;
  birthDate?: string;
  phone?: string;
  insuranceType?: string;
  startDate?: string;
  docType?: string;
};

const SummaryItem = ({ label, value, isAr }: { label: string; value: string; isAr: boolean }) => (
  <div className={cn("flex flex-col gap-0.5", isAr ? "text-right" : "text-left")} dir={isAr ? "rtl" : "ltr"}>
    <span className="text-[11px] font-medium text-muted-foreground sm:text-[12px]">
      {label}
    </span>
    <span className="text-[12.5px] font-extrabold text-brand-blue sm:text-[13.5px]">
      {value ? formatRiyal(value) : "—"}
    </span>
  </div>
);

const CheckBox = ({
  checked,
  onClick,
  readOnly,
}: {
  checked: boolean;
  onClick?: () => void;
  readOnly?: boolean;
}) => (
  <button
    type="button"
    onClick={readOnly ? undefined : onClick}
    aria-pressed={checked}
    className={cn(
      "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[5px] border-2 transition-colors",
      checked
        ? "border-brand-blue bg-brand-blue text-white"
        : "border-muted-foreground/40 bg-white",
      readOnly && "cursor-default",
    )}
  >
    {checked && <Check className="h-3 w-3" strokeWidth={3.5} />}
  </button>
);

// Display translation for the offer type (business logic value stays in Arabic).
const typeLabel = (type: string, t: (ar: string, en: string) => string) =>
  type === "ضد الغير" ? t("ضد الغير", "Third Party") : t("شامل", "Comprehensive");

const OfferCard = ({
  offer,
  onChoose,
  isAr,
  t,
}: {
  offer: InsuranceOffer;
  onChoose: () => void;
  isAr: boolean;
  t: (ar: string, en: string) => string;
}) => {
  const [selected, setSelected] = useState<Record<string, boolean>>({});

  const total = useMemo(() => {
    let sum = offer.price;
    offer.addons.forEach((a, i) => {
      const key = `a-${i}`;
      if (selected[key] && a.price) sum += a.price;
    });
    return sum;
  }, [selected, offer]);

  const toggle = (key: string) =>
    setSelected((s) => ({ ...s, [key]: !s[key] }));

  return (
    <article
      dir={isAr ? "rtl" : "ltr"}
      className="overflow-hidden rounded-2xl bg-white shadow-card"
    >
      {/* Top: company name + type, logo on other side */}
      <div className="flex items-start justify-between gap-3 px-3.5 pt-3.5 sm:px-4 sm:pt-4">
        <div className={isAr ? "text-right" : "text-left"}>
          <h3 className="text-[15px] font-extrabold leading-tight text-brand-blue sm:text-[16px]">
            {trOffer(offer.company, isAr)}
          </h3>
          <p className="mt-1 text-[11.5px] font-extrabold text-brand-blue sm:text-[12.5px]">
            {t("التأمين", "Insurance")} {typeLabel(offer.type, t)}
          </p>
        </div>
        <div className="grid h-[68px] w-[92px] shrink-0 place-items-center overflow-hidden rounded-xl border border-border bg-white p-1.5 text-center text-[10px] font-bold text-brand-blue/80 sm:h-[78px] sm:w-[104px]">
          {insurerLogos[offer.id] ? (
            <img
              src={insurerLogos[offer.id]}
              alt={trOffer(offer.company, isAr)}
              loading="lazy"
              className="max-h-full max-w-full object-contain"
            />
          ) : (
            trOffer(offer.company, isAr)
          )}
        </div>
      </div>

      {/* Body: price column on one side, coverage list on the other */}
      <div className="mt-2.5 grid grid-cols-[1fr_92px] items-start gap-3 px-3.5 sm:grid-cols-[1fr_104px] sm:px-4">
        {/* Coverage list */}
        <div className="border-t border-border pt-2.5">
          {/* main coverage row */}
          <div className="flex items-start justify-between gap-2 pb-1.5">
            <span className={cn("flex-1 text-[11.5px] font-bold leading-relaxed text-brand-blue sm:text-[12px]", isAr ? "text-right" : "text-left")}>
              {formatRiyal(trOffer(offer.mainCoverage, isAr))}
            </span>
            <CheckBox checked readOnly />
          </div>

          {offer.addons.map((a, i) => {
            const key = `a-${i}`;
            const isOn = !!selected[key];
            return (
              <div
                key={key}
                className="flex items-start justify-between gap-2 border-t border-border/60 py-1.5"
              >
                <span
                  className={cn("flex-1 cursor-pointer text-[11.5px] font-medium leading-relaxed text-brand-blue/90 sm:text-[12px]", isAr ? "text-right" : "text-left")}
                  onClick={() => toggle(key)}
                >
                  {trOffer(a.label, isAr)}
                  {a.price ? (
                    <span className="font-bold">
                      {" "}
                      (+{a.price} <SaudiRiyal className="mx-0.5 h-[0.9em] w-[0.9em]" />)
                    </span>
                  ) : null}
                </span>
                <CheckBox checked={isOn} onClick={() => toggle(key)} />
              </div>
            );
          })}
        </div>

        {/* Price */}
        <div className="text-center">
          <div className="text-[20px] font-extrabold leading-none text-brand-blue sm:text-[22px]">
            {total.toFixed(2)}
          </div>
          <div className="mt-1 flex items-center justify-center gap-1 text-[10px] text-muted-foreground sm:text-[11px]">
            <SaudiRiyal className="h-[1em] w-[1em]" />
            <span>/ {t("سنة", "year")}</span>
          </div>
          <div className="mt-1 text-[9px] font-bold text-brand-blue sm:text-[10px]">
            {t("غير شامل الضريبة", "VAT not included")}
          </div>
        </div>
      </div>

      {/* Fees */}
      {offer.fees.length > 0 && (
        <div className="mx-3.5 mt-2.5 border-t border-border pt-2.5 sm:mx-4">
          <div className={cn("mb-1.5 text-[11.5px] font-extrabold text-brand-blue", isAr ? "text-right" : "text-left")}>
            {t("رسوم إضافية:", "Additional fees:")}
          </div>
          <ul className="space-y-1">
            {offer.fees.map((f, i) => (
              <li
                key={i}
                className="flex items-center justify-between text-[10.5px] text-brand-blue/80 sm:text-[11px]"
              >
                <span>{trOffer(f.label, isAr)}</span>
                <span className="flex items-center gap-1 font-bold">
                  {f.amount}
                  <SaudiRiyal className="h-[0.95em] w-[0.95em]" />
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Choose button */}
      <div className="p-3.5 sm:p-4">
        <button
          type="button"
          onClick={onChoose}
          className="h-[42px] w-full rounded-[10px] btn-pay text-[12.5px] font-extrabold text-white shadow-soft transition-transform hover:brightness-110 active:scale-[0.99] sm:text-[13.5px]"
        >
          {t("اختر هذا العرض", "Choose this offer")}
        </button>
      </div>
    </article>
  );
};

const QuoteOffers = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, isAr, dir } = useI18n();
  const summary: VehicleSummary = (location.state as VehicleSummary) || {};

  const [tab, setTab] = useState<"ضد الغير" | "شامل">("ضد الغير");
  const [loading, setLoading] = useState(true);

  // Unique companies with their real logos (first offer id per company)
  const companyChecks = useMemo(() => {
    const seen = new Set<string>();
    const list: { name: string; logo?: string }[] = [];
    offers.forEach((o) => {
      if (!seen.has(o.company)) {
        seen.add(o.company);
        list.push({ name: o.company, logo: insurerLogos[o.id] });
      }
    });
    return list;
  }, []);
  const [checkIndex, setCheckIndex] = useState(0);
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 15000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const startedAt = Date.now();
    const t = setInterval(() => {
      const p = Math.min(100, Math.round(((Date.now() - startedAt) / 15000) * 100));
      setPercent(p);
    }, 150);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!loading) return;
    if (checkIndex >= companyChecks.length - 1) return;
    const t = setTimeout(() => setCheckIndex((i) => i + 1), 950);
    return () => clearTimeout(t);
  }, [loading, checkIndex, companyChecks.length]);

  const filtered = useMemo(() => offers.filter((o) => o.type === tab), [tab]);

  if (loading) {
    // Window of companies to show: up to 2 completed, the current one, and the next one
    const completed = companyChecks.slice(Math.max(0, checkIndex - 2), checkIndex);
    const current = companyChecks[checkIndex];
    const next = companyChecks[checkIndex + 1];

    const CompanyLogo = ({ logo, name, dim }: { logo?: string; name: string; dim?: boolean }) => (
      <div className={cn(
        "grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full border border-slate-100 bg-white p-1",
        dim && "bg-slate-100 border-dashed border-slate-200",
      )}>
        {logo && !dim ? (
          <img src={logo} alt={name} className="max-h-full max-w-full object-contain" />
        ) : (
          <span className="text-[9px] font-bold text-slate-400">{trOffer(name, isAr).slice(0, 2)}</span>
        )}
      </div>
    );

    return (
      <main dir={dir} className="min-h-screen bg-white">
        <Header />
        <div className="mx-auto flex min-h-[calc(100vh-96px)] w-full max-w-[430px] flex-col items-center px-6 pb-10 text-center">
          {/* Premium abstract ring loader with car icon */}
          <div className="relative mt-6 mb-8 h-40 w-40 sm:h-44 sm:w-44">
            <div className="absolute inset-0 rounded-full border-4 border-[#146394]/10" />
            <div className="absolute inset-0 animate-spin rounded-full border-4 border-[#146394] border-t-transparent [animation-duration:1.4s]" />
            <div className="absolute inset-4 grid place-items-center rounded-full bg-gradient-to-tr from-[#146394]/5 to-transparent">
              <svg viewBox="0 0 24 24" fill="currentColor" className="h-11 w-11 text-[#146394] opacity-80">
                <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H6.5C5.84 5 5.28 5.42 5.08 6.01L3 12V20C3 20.55 3.45 21 4 21H5C5.55 21 6 20.55 6 20V19H18V20C18 20.55 18.45 21 19 21H20C20.55 21 21 20.55 21 20V12L18.92 6.01ZM6.5 7H17.5L18.53 10H5.47L6.5 7ZM19 17H5V12H19V17ZM7.5 14C8.33 14 9 14.67 9 15.5C9 16.33 8.33 17 7.5 17C6.67 17 6 16.33 6 15.5C6 14.67 6.67 14 7.5 14ZM16.5 17C15.67 17 15 16.33 15 15.5C15 14.67 15.67 14 16.5 14C17.33 14 18 14.67 18 15.5C18 16.33 17.33 17 16.5 17Z" />
              </svg>
            </div>
          </div>

          <h2 className="text-[19px] font-extrabold text-slate-800 sm:text-[21px]">
            {t("نبحث عن أفضل العروض لك", "Finding the best offers for you")}
          </h2>
          <p className="mt-2 mb-8 max-w-[320px] text-[12.5px] leading-relaxed text-slate-500 sm:text-[13.5px]">
            {t(
              "نقوم حالياً بمقارنة أسعار أكثر من 20 شركة تأمين معتمدة لتوفير أفضل سعر لك.",
              "We're comparing prices from 20+ licensed insurers to get you the best price.",
            )}
          </p>

          {/* Live fetching list — real company names + logos */}
          <div className="w-full space-y-3 text-start">
            {completed.map((c) => (
              <div
                key={c.name}
                className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 p-3"
              >
                <div className="flex items-center gap-3">
                  <CompanyLogo logo={c.logo} name={c.name} />
                  <span className="text-[13px] font-bold text-slate-700">{trOffer(c.name, isAr)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600">
                    {t("مكتمل", "Done")}
                  </span>
                  <div className="grid h-4 w-4 place-items-center rounded-full bg-emerald-500">
                    <Check className="h-2.5 w-2.5 text-white" strokeWidth={3.5} />
                  </div>
                </div>
              </div>
            ))}

            {current && (
              <div
                key={current.name}
                className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-3 shadow-card"
              >
                <div className="flex items-center gap-3">
                  <CompanyLogo logo={current.logo} name={current.name} />
                  <span className="text-[13px] font-bold text-slate-700">{trOffer(current.name, isAr)}</span>
                </div>
                <span className="animate-pulse text-[10.5px] font-bold text-[#146394]">
                  {t("جاري الفحص...", "Checking...")}
                </span>
              </div>
            )}

            {next && (
              <div className="flex items-center justify-between rounded-xl border border-dashed border-slate-200 bg-white/50 p-3 opacity-60">
                <div className="flex items-center gap-3">
                  <CompanyLogo name={next.name} dim />
                  <span className="text-[13px] font-bold text-slate-400">{trOffer(next.name, isAr)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Bottom progress */}
          <div className="mt-auto w-full pt-10">
            <div className="mb-2 flex items-end justify-between">
              <span className="text-[12px] font-extrabold text-[#146394]">{percent}%</span>
              <span className="text-[10px] text-slate-400">
                {t("يستغرق عادةً أقل من 15 ثانية", "Usually takes less than 15 seconds")}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className="relative h-full rounded-full bg-gradient-to-l from-[#146394] to-[#146394]/70 transition-all duration-150"
                style={{ width: `${percent}%` }}
              >
                <div className="absolute top-0 right-0 h-full w-8 skew-x-[-20deg] animate-[offershimmer_2s_infinite] bg-white/20" />
              </div>
            </div>
          </div>
        </div>
        <style>{`
          @keyframes offershimmer {
            0% { transform: translateX(100%) skewX(-20deg); }
            100% { transform: translateX(-250%) skewX(-20deg); }
          }
        `}</style>
      </main>
    );
  }

  const handleChoose = (o: InsuranceOffer) => {
    toast.success(`${t("تم اختيار عرض", "You selected the offer from")} ${o.company}`);
    navigate("/quote/checkout", {
      state: {
        ...summary,
        company: o.company,
        companyId: o.id,
        type: o.type,
        price: o.price,
        vat: o.vat,
        mainCoverage: o.mainCoverage,
        addons: o.addons,
      },
    });
  };

  return (
    <main dir={dir} className="min-h-screen bg-[hsl(210_40%_97%)]">
      <Header />
      <QuoteSteps current={3} />

      <section
        dir={dir}
        className="mx-auto w-full max-w-[1100px] px-3 pb-10 pt-2 sm:px-4"
      >
        {/* Vehicle summary card */}
        <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
          <h1 className="text-center text-[15px] font-extrabold text-brand-blue sm:text-[17px]">
            {t("العروض المتاحة حسب تفاصيل مركبتك", "Available offers based on your vehicle details")}
          </h1>
          <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3.5 sm:grid-cols-3 md:grid-cols-5">
            <SummaryItem label={t("ماركة ونوع المركبة", "Vehicle Make & Model")} value={summary.brand || "—"} isAr={isAr} />
            <SummaryItem label={t("سنة صنع المركبة", "Manufacture Year")} value={summary.year || "—"} isAr={isAr} />
            <SummaryItem
              label={t("القيمة التقديرية", "Estimated Value")}
              value={summary.estValue ? `${summary.estValue} ${t("ريال", "SAR")}` : "—"}
              isAr={isAr}
            />
            <SummaryItem label={t("الغرض من الاستخدام", "Usage Purpose")} value={summary.purpose || "—"} isAr={isAr} />
            <SummaryItem label={t("مكان إصلاح المركبة", "Repair Location")} value={summary.repairPlace || "—"} isAr={isAr} />
          </div>
        </div>

        {/* Notice */}
        <div className="mt-3 rounded-xl border border-brand-blue/15 bg-brand-blue/5 p-3 text-center text-[11px] leading-relaxed text-brand-blue sm:text-[12px]">
          {t(
            "بموجب تعليمات البنك المركزي السعودي، يحق لحامل الوثيقة إلغاء الوثيقة واسترداد كامل المبلغ المدفوع خلال 15 يوماً من تاريخ الشراء، بشرط عدم حدوث أي مطالبات خلال هذه الفترة.",
            "In accordance with the Saudi Central Bank instructions, the policyholder has the right to cancel the policy and receive a full refund within 15 days of purchase, provided no claims have been made during this period.",
          )}
        </div>

        {/* Tabs */}
        <div className="mt-3 grid grid-cols-2 overflow-hidden rounded-xl bg-white shadow-card">
          {(["ضد الغير", "شامل"] as const).map((tabValue) => {
            const active = tab === tabValue;
            return (
              <button
                key={tabValue}
                type="button"
                onClick={() => setTab(tabValue)}
                className={cn(
                  "h-[44px] text-[12.5px] font-extrabold transition-colors sm:text-[13.5px]",
                  active
                    ? "btn-pay"
                    : "bg-white text-brand-blue/80 hover:bg-muted/40",
                )}
              >
                {t("تأمين", "Insurance")} {typeLabel(tabValue, t)}
              </button>
            );
          })}
        </div>

        {/* Offers list */}
        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.length === 0 ? (
            <div className="col-span-full rounded-2xl bg-white p-8 text-center text-brand-blue/70 shadow-card">
              {t("لا توجد عروض متاحة لهذا النوع حالياً", "No offers are currently available for this type")}
            </div>
          ) : (
            filtered.map((o) => (
              <OfferCard key={o.id} offer={o} onChoose={() => handleChoose(o)} isAr={isAr} t={t} />
            ))
          )}
        </div>

        <div className="mt-6 flex justify-start">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="h-[44px] rounded-[10px] border border-[hsl(214_25%_85%)] bg-white px-6 text-[13px] font-bold text-brand-blue hover:bg-muted/40"
          >
            {t("رجوع", "Back")}
          </button>
        </div>
      </section>

      <SiteFooter />
      <FloatingButtons />
    </main>
  );
};

export default QuoteOffers;
