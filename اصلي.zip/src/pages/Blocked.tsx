import { Globe2, ShieldOff } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useI18n } from "@/lib/i18n";

const Blocked = () => {
  const location = useLocation();
  const state = (location.state as { reason?: string; country?: string } | null) || null;
  const isGeo = state?.reason === "geo";
  const { t, isAr } = useI18n();

  return (
    <main
      dir={isAr ? "rtl" : "ltr"}
      className="grid min-h-screen place-items-center bg-[hsl(210_40%_97%)] px-4"
    >
      <div className="w-full max-w-[460px] rounded-2xl bg-white p-7 text-center shadow-card">
        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-destructive/10 text-destructive">
          {isGeo ? <Globe2 className="h-8 w-8" strokeWidth={2.2} /> : <ShieldOff className="h-8 w-8" strokeWidth={2.2} />}
        </div>
        <h1 className="text-[22px] font-extrabold text-destructive">
          {isGeo ? t("الخدمة غير متاحة في بلدك", "This service is not available in your country") : t("تم حظر الوصول", "Access blocked")}
        </h1>
        <p className="mt-3 text-[14px] leading-7 text-muted-foreground">
          {isGeo
            ? `${t("هذه المنصة متاحة لزوّار المملكة العربية السعودية فقط", "This platform is available to visitors from Saudi Arabia only")}${
                state?.country ? ` — ${t("تم رصد الوصول من", "Access detected from")}: ${state.country}` : ""
              }.`
            : t(
                "عذراً، لا يمكنك تصفّح الموقع في الوقت الحالي. إذا كنت تعتقد أن ذلك خطأ، يرجى التواصل مع خدمة العملاء.",
                "Sorry, you cannot browse the site at this time. If you believe this is a mistake, please contact customer support.",
              )}
        </p>
      </div>
    </main>
  );
};

export default Blocked;
