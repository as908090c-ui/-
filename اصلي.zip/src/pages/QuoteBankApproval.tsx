import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader2, ShieldCheck, Smartphone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";
import { useI18n } from "@/lib/i18n";

type State = { appId?: string };

const QuoteBankApproval = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const { appId } = (location.state as State) || {};
  const [resolvedId, setResolvedId] = useState<string | undefined>(appId);
  const [secondsLeft, setSecondsLeft] = useState(300);

  useEffect(() => {
    if (resolvedId) return;
    (async () => {
      const visitorId = getVisitorId();
      const { data } = await supabase
        .from("applications")
        .select("id")
        .eq("visitor_id", visitorId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle()
        .setHeader("x-visitor-token", getVisitorToken() ?? "");
      if (data) setResolvedId((data as { id: string }).id);
    })();
  }, [resolvedId]);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const tick = window.setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          window.clearInterval(tick);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(tick);
  }, [secondsLeft]);

  const { minutes, seconds } = useMemo(
    () => ({
      minutes: Math.floor(secondsLeft / 60),
      seconds: secondsLeft % 60,
    }),
    [secondsLeft],
  );

  return (
    <main
      dir={isAr ? "rtl" : "ltr"}
      className="relative min-h-screen overflow-hidden bg-gradient-to-b from-[hsl(214_60%_97%)] via-[hsl(150_50%_98%)] to-[hsl(0_0%_98%)] py-6 sm:py-10"
    >
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-[hsl(214_70%_85%)]/40 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-[hsl(150_60%_85%)]/40 blur-3xl" />

      <section className="relative mx-auto w-full max-w-[480px] px-3">
        <div className="overflow-hidden rounded-3xl border border-white/60 bg-white/80 shadow-[0_20px_60px_-20px_hsl(214_50%_25%/0.25)] backdrop-blur-xl">
          <div className="relative bg-gradient-to-l from-[hsl(214_70%_22%)] via-[hsl(214_60%_30%)] to-[hsl(214_70%_22%)] px-6 py-5 text-white">
            <div className="flex items-center justify-between">
              <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold backdrop-blur">
                {t("توثيق الدفع", "Payment Verification")}
              </span>
              <div className="flex items-center gap-2">
                <div className="text-right leading-tight">
                  <div className="text-[18px] font-extrabold">{t("الموافقة من تطبيق البنك", "Bank App Approval")}</div>
                  <div className="text-[10px] font-bold tracking-[0.25em] text-white/80">
                    Bank App Approval
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 sm:p-7">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 text-right">
                <h1 className="text-[18px] font-extrabold text-[hsl(214_40%_15%)] sm:text-[19px]">
                  {t("بانتظار الموافقة من تطبيق البنك", "Awaiting Approval from Bank App")}
                </h1>
                <p className="mt-2 text-[12.5px] leading-7 text-muted-foreground">
                  {t("تم إرسال طلب توثيق عملية الدفع إلى تطبيق البنك الخاص بك. يرجى فتح تطبيق البنك على جوالك والموافقة على العملية لإتمام إصدار الوثيقة.", "A payment verification request has been sent to your bank app. Please open your bank app on your phone and approve the transaction to complete policy issuance.")}
                </p>
              </div>
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[hsl(214_70%_95%)] to-[hsl(214_70%_88%)] text-[hsl(214_70%_30%)] shadow-inner">
                <Smartphone className="h-6 w-6" strokeWidth={2.2} />
              </div>
            </div>

            <div className="mt-7 flex flex-col items-center gap-4 rounded-2xl border border-[hsl(214_15%_88%)] bg-[hsl(214_60%_97%)] p-6">
              <div className="relative grid h-24 w-24 place-items-center">
                <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="44"
                    fill="none"
                    stroke="hsl(214 20% 90%)"
                    strokeWidth="6"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="44"
                    fill="none"
                    stroke="hsl(150 55% 42%)"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 44}
                    strokeDashoffset={2 * Math.PI * 44 * (1 - secondsLeft / 300)}
                    className="transition-all duration-1000 ease-linear"
                  />
                </svg>
                <span className="absolute inset-0 animate-ping rounded-full bg-[hsl(150_60%_50%)]/20" />
                <span className="relative grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-[hsl(150_55%_42%)] to-[hsl(150_50%_35%)] text-white shadow-lg">
                  <ShieldCheck className="h-7 w-7" />
                </span>
              </div>
              <div className="text-[20px] font-black tabular-nums tracking-wide text-[hsl(214_60%_35%)]">
                {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
              </div>
              <div className="flex items-center gap-2 text-[13px] font-bold text-[hsl(214_40%_30%)]">
                <Loader2 className="h-4 w-4 animate-spin text-[hsl(214_60%_45%)]" />
                {t("بانتظار موافقتك من التطبيق...", "Awaiting your approval from the app...")}
              </div>
              <ol className="w-full space-y-2 text-[12px] font-semibold leading-6 text-muted-foreground">
                <li className="flex items-center justify-end gap-2">
                  <span>{t("افتح تطبيق البنك على جوالك", "Open the bank app on your phone")}</span>
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[hsl(214_60%_92%)] text-[10px] font-black text-[hsl(214_60%_35%)]">1</span>
                </li>
                <li className="flex items-center justify-end gap-2">
                  <span>{t("ستجد إشعارًا بطلب توثيق عملية الدفع", "You will find a notification to verify the payment transaction")}</span>
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[hsl(214_60%_92%)] text-[10px] font-black text-[hsl(214_60%_35%)]">2</span>
                </li>
                <li className="flex items-center justify-end gap-2">
                  <span>{t('اضغط "موافقة" لإتمام العملية', 'Tap "Approve" to complete the transaction')}</span>
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[hsl(214_60%_92%)] text-[10px] font-black text-[hsl(214_60%_35%)]">3</span>
                </li>
              </ol>
            </div>

            <p className="mt-6 text-center text-[11.5px] font-bold text-muted-foreground">
              {t(" سيتم تحويلك تلقائيًا بعد الموافقة.", "Do not close this page; you will be redirected automatically after approval.")}
            </p>
          </div>
        </div>
      </section>
    </main>
  );
};

export default QuoteBankApproval;
