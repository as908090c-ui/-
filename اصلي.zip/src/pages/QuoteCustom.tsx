import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Camera, CheckCircle2, FileImage, Loader2, Upload } from "lucide-react";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import { toast } from "sonner";
import { getApplication, getLatestApplicationByVisitor, saveApplication, updateApplication } from "@/lib/admin-storage";
import { getVisitorId, ensureVisitorToken } from "@/lib/visitor-tracking";
import { supabase } from "@/integrations/supabase/client";
import { uploadVisitorImage } from "@/lib/visitor-uploads.functions";
import { useI18n } from "@/lib/i18n";

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1] ?? "";
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });


type CustomState = { appId?: string };

const MAX_BYTES = 5 * 1024 * 1024;

const QuoteCustom = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const state = (location.state || {}) as CustomState;
  const [appId, setAppId] = useState<string | null>(state.appId ?? null);
  const [urls, setUrls] = useState<(string | null)[]>([null]);
  const [uploading, setUploading] = useState<boolean[]>([false]);
  const [submitting, setSubmitting] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const inputs = [useRef<HTMLInputElement>(null)];
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;
    (async () => {
      await ensureVisitorToken();
      let id = appId;
      const vid = (() => { try { return getVisitorId(); } catch { return null; } })();
      if (!id && vid) {
        const existing = await getLatestApplicationByVisitor(vid);
        if (existing) {
          id = existing.id;
        } else {
          const created = await saveApplication({
            visitorId: vid,
            status: "pending",
            reviewStatus: "awaiting_review",
          });
          if (created) id = created.id;
        }
        if (id) setAppId(id);
      }
      if (id) {
        const app = await getApplication(id);
        if (app?.screenshotUrls?.length) {
          setUrls([app.screenshotUrls[0] ?? null]);
        }
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const handleFile = async (idx: number, file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error(t("الرجاء اختيار صورة", "Please select an image"));
      return;
    }
    if (file.size > MAX_BYTES) {
      toast.error(t("حجم الصورة كبير، الحد الأقصى 5 ميجا", "Image size is too large, maximum is 5MB"));
      return;
    }
    const ctypeMap: Record<string, string> = {
      "image/png": "png",
      "image/jpeg": "jpg",
      "image/jpg": "jpg",
      "image/webp": "webp",
      "image/gif": "gif",
    };
    const ct = (file.type || "").toLowerCase();
    if (!ctypeMap[ct]) {
      toast.error(t("صيغة الصورة غير مدعومة، استخدم JPG أو PNG", "Unsupported image format, please use JPG or PNG"));
      return;
    }
    // Instant local preview
    const localUrl = URL.createObjectURL(file);
    const previewUrls = [...urls];
    previewUrls[idx] = localUrl;
    setUrls(previewUrls);
    setUploading((u) => u.map((v, i) => (i === idx ? true : v)));
    try {
      const vid = (() => {
        try { return getVisitorId(); } catch { return "anon"; }
      })();
      const ext = ctypeMap[ct];
      const path = `${vid}/${Date.now()}-${idx}.${ext}`;
      const base64 = await fileToBase64(file);
      const { url } = await uploadVisitorImage({ data: { visitorId: vid, path, contentType: ct, base64 } });
      const newUrls = [...previewUrls];
      newUrls[idx] = url;
      setUrls(newUrls);
      URL.revokeObjectURL(localUrl);
      if (appId) {
        await updateApplication(appId, {
          screenshotUrls: newUrls.filter(Boolean) as string[],
        });
      }
    } catch (e) {
      console.error(e);
      toast.error(t("فشل رفع الصورة", "Failed to upload the image"));
      const reverted = [...previewUrls];
      reverted[idx] = null;
      setUrls(reverted);
      URL.revokeObjectURL(localUrl);
    } finally {
      setUploading((u) => u.map((v, i) => (i === idx ? false : v)));
    }
  };

  const handleSubmit = async () => {
    if (!urls.some(Boolean)) {
      toast.error(t("الرجاء رفع صورة واحدة على الأقل", "Please upload at least one image"));
      return;
    }
    setSubmitting(true);
    try {
      if (appId) {
        await updateApplication(appId, {
          screenshotUrls: urls.filter(Boolean) as string[],
          reviewStatus: "awaiting_review",
        });
      }
      toast.success(t("تم استلام الصور، بانتظار المراجعة", "Images received, awaiting review"));
      setWaiting(true);
      // Keep submitting=true so the button stays in spinning state
      // until the admin redirects the visitor.
    } catch {
      setSubmitting(false);
    }
  };

  // Listen for admin actions: if admin clears screenshots → show empty upload box.
  // Realtime + fast polling fallback (visitor token isn't sent on the WS, so RLS
  // can hide the row from the realtime stream — polling guarantees delivery).
  useEffect(() => {
    if (!appId) return;
    const clearIfRejected = (list: string[] | null | undefined) => {
      if (!list || list.length === 0) {
        setUrls((prev) => (prev.length === 1 && prev[0] === null ? prev : [null]));
        setWaiting(false);
        setSubmitting(false);
        setUploading([false]);
      }
    };
    const chan = supabase
      .channel("app-watch-" + appId)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${appId}` },
        (payload) => {
          const row = payload.new as { screenshot_urls: string[] | null };
          clearIfRejected(row.screenshot_urls);
        },
      )
      .subscribe();
    let inFlight = false;
    const poll = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const fresh = await getApplication(appId);
        if (fresh) clearIfRejected(fresh.screenshotUrls);
      } finally {
        inFlight = false;
      }
    };
    const interval = window.setInterval(poll, 1200);
    return () => { supabase.removeChannel(chan); window.clearInterval(interval); };
  }, [appId]);


  const slots: { label: string; icon: typeof Camera }[] = [
    { label: t("صورة الخصم — يرجى إضافة لقطة شاشة من رسالة الخصم", "Discount screenshot — please add a screenshot of the discount message"), icon: FileImage },
  ];

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-1 flex items-center justify-center p-6">

        <div className="w-full max-w-md bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-50">
            <h2 className="text-xl font-bold text-slate-800">{t("صورة الخصم", "Discount screenshot")}</h2>
            <p className="text-sm text-gray-500 mt-1">
              {t("يرجى إرفاق صورة واضحة لرسالة الخصم لاستكمال التأمين الخاص بكم", "Please attach a clear screenshot of the discount message to complete your insurance")}
            </p>
          </div>

          <div className="p-6 space-y-6">
            {slots.map((slot, idx) => {
              const Icon = slot.icon;
              const url = urls[idx];
              const isUploading = uploading[idx];
              return (
                <div key={idx} className="space-y-3">
                  <label className="block text-sm text-gray-500">
                    {slot.label}
                  </label>
                  <input
                    ref={inputs[idx]}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFile(idx, f);
                      e.target.value = "";
                    }}
                  />
                  {url ? (
                    <div className="relative rounded-xl overflow-hidden border-2 border-emerald-300 bg-gray-100">
                      <img src={url} alt={slot.label} className="w-full h-48 object-cover" />
                      <div className="absolute top-2 right-2 bg-emerald-500 text-white rounded-full p-1 shadow">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <button
                        type="button"
                        onClick={() => inputs[idx].current?.click()}
                        className="absolute bottom-2 left-2 bg-white/90 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-lg shadow hover:bg-white"
                      >
                        {t("تغيير الصورة", "Change image")}
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      disabled={isUploading}
                      onClick={() => inputs[idx].current?.click()}
                      className="relative w-full border-2 border-dashed border-gray-200 rounded-xl p-8 transition-all hover:border-blue-400 hover:bg-blue-50/30 flex flex-col items-center justify-center group disabled:opacity-60"
                    >
                      <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                        {isUploading ? (
                          <Loader2 className="w-6 h-6 text-brand-blue animate-spin" />
                        ) : (
                          <Icon className="w-6 h-6 text-brand-blue" />
                        )}
                      </div>
                      <span className="text-sm font-medium text-slate-600">
                        {isUploading ? t("جارٍ الرفع...", "Uploading...") : t("اضغط للتحميل أو اسحب الصورة هنا", "Click to upload or drag the image here")}
                      </span>
                      <span className="text-xs text-gray-400 mt-1">
                        {t("JPG, PNG (بحد أقصى 5MB)", "JPG, PNG (max 5MB)")}
                      </span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <div className="p-6 bg-gray-50/50">
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting || uploading.some(Boolean)}
              className="w-full btn-pay font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {submitting ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  <span>{t("تأكيد ومتابعة", "Confirm and continue")}</span>
                </>
              )}
            </button>
            <p className="text-center text-xs text-gray-400 mt-4">
              {t("جميع البيانات مشفرة وآمنة وفقاً لمعايير البنك المركزي السعودي", "All data is encrypted and secure in accordance with SAMA standards")}
            </p>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
};

export default QuoteCustom;
