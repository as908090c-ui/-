import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar as CalendarIcon, ChevronDown } from "lucide-react";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import FloatingButtons from "@/components/site/FloatingButtons";
import QuoteSteps from "@/components/site/QuoteSteps";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useI18n } from "@/lib/i18n";

const Field = ({
  label,
  children,
  isAr,
}: {
  label: string;
  children: React.ReactNode;
  isAr: boolean;
}) => (
  <div className="space-y-2">
    <label className={cn("block text-[15px] font-extrabold text-brand-blue", isAr ? "text-right" : "text-left")}>
      {label}
    </label>
    {children}
  </div>
);

// Match bcare: tall input, soft 1px border, rounded ~8px, light bg
const inputClsBase =
  "w-full h-[54px] rounded-[10px] border border-[hsl(214_25%_85%)] bg-white px-4 text-[15px] text-brand-blue placeholder:text-muted-foreground/55 focus:border-brand-blue focus:outline-none";

const SelectBox = ({
  value,
  onChange,
  placeholder,
  options,
  isAr,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  options: string[];
  isAr: boolean;
}) => (
  <div className="relative">
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      dir={isAr ? "rtl" : "ltr"}
      className={cn(
        inputClsBase,
        isAr ? "text-right pl-10" : "text-left pr-10",
        "appearance-none",
        !value && "text-muted-foreground/55",
      )}
    >
      <option value="" disabled>
        {placeholder}
      </option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
    <ChevronDown
      className={cn(
        "pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground",
        isAr ? "left-3" : "right-3",
      )}
    />
  </div>
);

const monthsAr = [
  "محرم",
  "صفر",
  "ربيع الأول",
  "ربيع الآخر",
  "جمادى الأولى",
  "جمادى الآخرة",
  "رجب",
  "شعبان",
  "رمضان",
  "شوال",
  "ذو القعدة",
  "ذو الحجة",
];
const monthsEn = [
  "Muharram",
  "Safar",
  "Rabi' al-Awwal",
  "Rabi' al-Thani",
  "Jumada al-Awwal",
  "Jumada al-Thani",
  "Rajab",
  "Sha'ban",
  "Ramadan",
  "Shawwal",
  "Dhu al-Qi'dah",
  "Dhu al-Hijjah",
];
const gregorianMonthsAr = [
  "يناير",
  "فبراير",
  "مارس",
  "أبريل",
  "مايو",
  "يونيو",
  "يوليو",
  "أغسطس",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];
const gregorianMonthsEn = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
// Hijri months alternate 30/29 days; Dhu al-Hijjah is 29 or 30 in a leap year.
const hijriMonthDays = [30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, 30];
const gregorianMonthDays = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
// Hijri year range: roughly 1340 – 1450 (covers ages up to ~110).
const hijriYears = Array.from({ length: 111 }, (_, i) => String(1450 - i));
const gregorianYears = Array.from({ length: 111 }, (_, i) => String(new Date().getFullYear() + 1 - i));



const formatDateDMY = (iso: string) => {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
};

const parseDateToISO = (value: string) => {
  const normalized = value.trim().replace(/-/g, "/");
  const match = normalized.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return null;

  const [, day, month, year] = match;
  const iso = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  const parsed = new Date(`${iso}T00:00:00`);

  if (Number.isNaN(parsed.getTime())) return null;
  if (
    parsed.getFullYear() !== Number(year) ||
    parsed.getMonth() + 1 !== Number(month) ||
    parsed.getDate() !== Number(day)
  ) {
    return null;
  }

  return iso;
};

const QuoteDetails = () => {
  const navigate = useNavigate();
  const { t, isAr, dir } = useI18n();
  const months = isAr ? monthsAr : monthsEn;
  const inputCls = cn(inputClsBase, isAr ? "text-right" : "text-left");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [calendarType, setCalendarType] = useState<"hijri" | "gregorian">("hijri");
  const [identity, setIdentity] = useState(() => {
    try {
      return sessionStorage.getItem("bcare_home_identity") || "";
    } catch {
      return "";
    }
  });
  const [fullName, setFullName] = useState("");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [phone, setPhone] = useState("");
  const [insuranceType, setInsuranceType] = useState("ضد الغير");
  const [startDate, setStartDate] = useState("");
  const [startDateInput, setStartDateInput] = useState("");
  const [purpose, setPurpose] = useState("شخصي");
  const [estValue, setEstValue] = useState("");
  const [carYear, setCarYear] = useState("");
  const [carModel, setCarModel] = useState("");
  const [repairPlace, setRepairPlace] = useState<"agency" | "workshop">("agency");
  const [plateNumber, setPlateNumber] = useState("");


  const insuranceTypeOptions = [
    { value: "ضد الغير", label: t("ضد الغير", "Third Party") },
    { value: "شامل", label: t("شامل", "Comprehensive") },
  ];
  const purposeOptions = [
    { value: "شخصي", label: t("شخصي", "Personal") },
    { value: "نقل خاص", label: t("نقل خاص", "Private Transport") },
    { value: "تأجير", label: t("تأجير", "Rental") },
    { value: "أخرى", label: t("أخرى", "Other") },
  ];

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone) {
      toast.error(t("الرجاء تعبئة جميع الحقول المطلوبة", "Please fill in all required fields"));
      return;
    }

    const normalizedStartDate = parseDateToISO(startDateInput) ?? startDate;
    const birthMonthList =
      calendarType === "hijri"
        ? isAr ? monthsAr : monthsEn
        : isAr ? gregorianMonthsAr : gregorianMonthsEn;
    const birthMonthNum = month ? birthMonthList.indexOf(month) + 1 : 0;

    navigate("/quote/offers", {
      state: {
        brand: carModel,
        year: carYear,
        estValue,
        purpose,
        repairPlace: repairPlace === "agency" ? "الوكالة" : "الورشة",
        // pass-through for policy preview
        fullName,
        identity,
        birthDate: day && month && year ? `${day}/${birthMonthNum}/${year}` : "",

        phone,
        insuranceType,
        startDate: normalizedStartDate ? formatDateDMY(normalizedStartDate) : "",
        docType: "استمارة",
      },
    });
  };

  return (
    <main dir={dir} className="min-h-screen bg-[hsl(210_40%_97%)]">
      <Header />
      <QuoteSteps current={2} />

      <section className="mx-auto w-full max-w-[760px] px-3 pb-10 pt-2 sm:px-4">
        <div className="rounded-2xl bg-white p-5 shadow-card sm:p-7">
          <h1 className={cn("text-[22px] font-extrabold text-brand-blue sm:text-[24px]", isAr ? "text-right" : "text-left")}>
            {t("تفاصيل وثيقة التأمين", "Insurance Policy Details")}
          </h1>
          <div className="mb-6 mt-3 h-px w-full bg-border" />

          <form onSubmit={handleNext} className="space-y-5">
            <Field label={t("رقم الهوية / الإقامة", "ID / Iqama Number")} isAr={isAr}>
              <input
                type="text"
                inputMode="numeric"
                value={identity}
                onChange={(e) => setIdentity(e.target.value)}
                className={cn(inputCls, "bg-[hsl(210_40%_97%)] font-bold")}
              />
            </Field>

            <Field label={t("الاسم الكامل", "Full Name")} isAr={isAr}>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder={t("أدخل الاسم الكامل", "Enter your full name")}
                className={inputCls}
              />
            </Field>

            <Field label={t("تاريخ الميلاد", "Date of Birth")} isAr={isAr}>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  {[
                    { id: "hijri" as const, label: t("هجري", "Hijri") },
                    { id: "gregorian" as const, label: t("ميلادي", "Gregorian") },
                  ].map((opt) => {
                    const selected = calendarType === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          setCalendarType(opt.id);
                          setDay("");
                          setMonth("");
                          setYear("");
                        }}
                        className={cn(
                          "flex h-[54px] w-full items-center justify-center rounded-[10px] border bg-white px-4 text-[15px] font-bold transition-colors",
                          selected
                            ? "border-brand-blue text-brand-blue"
                            : "border-[hsl(214_25%_85%)] text-brand-blue/80 hover:border-brand-blue/40",
                        )}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
                <div className="grid grid-cols-3 gap-2 sm:gap-3">
                  {(() => {
                    const isHijri = calendarType === "hijri";
                    const monthNames = isHijri
                      ? isAr ? monthsAr : monthsEn
                      : isAr ? gregorianMonthsAr : gregorianMonthsEn;
                    const monthDays = isHijri ? hijriMonthDays : gregorianMonthDays;
                    const yearOptions = isHijri ? hijriYears : gregorianYears;
                    const monthIdx = month ? monthNames.indexOf(month) : -1;
                    const maxDay = monthIdx >= 0 ? monthDays[monthIdx] : Math.max(...monthDays);
                    const days = Array.from({ length: maxDay }, (_, i) => String(i + 1));
                    return (
                      <>
                        <SelectBox value={day} onChange={setDay} placeholder={t("اليوم", "Day")} options={days} isAr={isAr} />
                        <SelectBox
                          value={month}
                          onChange={(v) => {
                            setMonth(v);
                            const idx = monthNames.indexOf(v);
                            const cap = idx >= 0 ? monthDays[idx] : 30;
                            if (day && Number(day) > cap) setDay(String(cap));
                          }}
                          placeholder={t("الشهر", "Month")}
                          options={monthNames}
                          isAr={isAr}
                        />
                        <SelectBox value={year} onChange={setYear} placeholder={t("السنة", "Year")} options={yearOptions} isAr={isAr} />
                      </>
                    );
                  })()}
                </div>
              </div>
            </Field>



            <Field label={t("رقم الجوال", "Mobile Number")} isAr={isAr}>
              <input
                type="tel"
                inputMode="numeric"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05xxxxxxxx"
                className={inputCls}
              />
            </Field>

            <div className="my-2 h-px w-full bg-border" />

            <Field label={t("نوع التأمين", "Insurance Type")} isAr={isAr}>
              <div className="relative">
                <select
                  value={insuranceType}
                  onChange={(e) => setInsuranceType(e.target.value)}
                  dir={isAr ? "rtl" : "ltr"}
                  className={cn(inputCls, "appearance-none", isAr ? "pl-10" : "pr-10")}
                >
                  <option value="" disabled>
                    {t("إختر", "Select")}
                  </option>
                  {insuranceTypeOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  className={cn(
                    "pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground",
                    isAr ? "left-3" : "right-3",
                  )}
                />
              </div>
            </Field>

            <Field label={t("تاريخ بدء التأمين", "Insurance Start Date")} isAr={isAr}>
              <div className="relative">
                <input
                  type="text"
                  value={startDateInput}
                  onChange={(e) => {
                    const digits = e.target.value.replace(/\D/g, "").slice(0, 8);
                    let formatted = digits;
                    if (digits.length > 4) {
                      formatted = `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
                    } else if (digits.length > 2) {
                      formatted = `${digits.slice(0, 2)}/${digits.slice(2)}`;
                    }
                    setStartDateInput(formatted);
                    const parsed = parseDateToISO(formatted);
                    if (parsed) setStartDate(parsed);
                  }}
                  maxLength={10}
                  onBlur={() => {
                    const parsed = parseDateToISO(startDateInput);
                    if (parsed) {
                      setStartDate(parsed);
                      setStartDateInput(formatDateDMY(parsed));
                    }
                  }}
                  inputMode="numeric"
                  placeholder={t("يوم/شهر/سنة - مثال: 23/04/2026", "DD/MM/YYYY - e.g. 23/04/2026")}
                  className={cn(inputCls, isAr ? "pl-14" : "pr-14", "tracking-wider")}
                />
                <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className={cn(
                        "absolute top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-md bg-brand-orange/15 text-brand-orange hover:bg-brand-orange/25",
                        isAr ? "left-3" : "right-3",
                      )}
                      aria-label={t("فتح منتقي التاريخ", "Open date picker")}
                    >
                      <CalendarIcon className="h-5 w-5" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={startDate ? new Date(`${startDate}T00:00:00`) : undefined}
                      onSelect={(d) => {
                        if (!d) return;
                        const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
                        setStartDate(iso);
                        setStartDateInput(formatDateDMY(iso));
                        setPickerOpen(false);
                      }}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </Field>

            <Field label={t("الغرض من استخدام المركبة", "Vehicle Usage Purpose")} isAr={isAr}>
              <div className="relative">
                <select
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  dir={isAr ? "rtl" : "ltr"}
                  className={cn(inputCls, "appearance-none", isAr ? "pl-10" : "pr-10")}
                >
                  <option value="" disabled>
                    {t("إختر", "Select")}
                  </option>
                  {purposeOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  className={cn(
                    "pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground",
                    isAr ? "left-3" : "right-3",
                  )}
                />
              </div>
            </Field>

            <Field label={t("القيمة التقديرية للمركبة", "Estimated Vehicle Value")} isAr={isAr}>
              <input
                type="text"
                inputMode="numeric"
                value={estValue}
                onChange={(e) => setEstValue(e.target.value)}
                placeholder={t("أدخل القيمة بين 10,000 - 1,000,000 ريال", "Enter a value between 10,000 - 1,000,000 SAR")}
                className={inputCls}
              />
            </Field>

            <Field label={t("سنة صنع المركبة", "Vehicle Manufacture Year")} isAr={isAr}>
              <SelectBox
                value={carYear}
                onChange={setCarYear}
                placeholder={t("إختر", "Select")}
                options={Array.from({ length: 31 }, (_, i) => String(2027 - i))}
                isAr={isAr}
              />
            </Field>

            <Field label={t("ماركة ونوع المركبة", "Vehicle Make & Model")} isAr={isAr}>
              <input
                type="text"
                value={carModel}
                onChange={(e) => setCarModel(e.target.value)}
                placeholder={t("مثال: تويوتا كامري", "e.g. Toyota Camry")}
                className={inputCls}
              />
            </Field>

            <Field label={t("رقم لوحة السيارة", "Vehicle Plate Number")} isAr={isAr}>
              <input
                type="text"
                value={plateNumber}
                onChange={(e) => setPlateNumber(e.target.value)}
                placeholder={t("مثال: أ ب ج 1234", "e.g. A B C 1234")}
                className={inputCls}
              />
            </Field>

            <Field label={t("مكان اصلاح المركبة", "Vehicle Repair Location")} isAr={isAr}>
              <div className="space-y-3">
                {[
                  { id: "agency", label: t("الوكالة", "Agency") },
                  { id: "workshop", label: t("الورشة", "Workshop") },
                ].map((opt) => {
                  const selected = repairPlace === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setRepairPlace(opt.id as "agency" | "workshop")}
                      className={cn(
                        "flex h-[54px] w-full items-center justify-between rounded-[10px] border bg-white px-4 text-[15px] font-bold transition-colors",
                        selected
                          ? "border-brand-blue text-brand-blue"
                          : "border-[hsl(214_25%_85%)] text-brand-blue/80",
                      )}
                    >
                      <span
                        className={cn(
                          "grid h-5 w-5 place-items-center rounded-full border-2",
                          selected ? "border-brand-blue" : "border-muted-foreground/45",
                        )}
                      >
                        {selected && (
                          <span className="h-2.5 w-2.5 rounded-full bg-brand-blue" />
                        )}
                      </span>
                      <span>{opt.label}</span>
                    </button>
                  );
                })}
              </div>
            </Field>

            <div className="flex flex-col-reverse gap-3 pt-3 sm:flex-row-reverse">
              <button
                type="submit"
                className="h-[54px] w-full rounded-[10px] btn-pay text-[16px] font-extrabold text-white shadow-soft transition-transform hover:brightness-105 active:scale-[0.99]"
              >
                {t("إظهار العروض", "Show Offers")}
              </button>
              <button
                type="button"
                onClick={() => navigate("/")}
                className="h-[54px] w-full rounded-[10px] border border-[hsl(214_25%_85%)] bg-white text-[15px] font-bold text-brand-blue hover:bg-muted/40"
              >
                {t("رجوع", "Back")}
              </button>
            </div>
          </form>
        </div>
      </section>

      <SiteFooter />
      <FloatingButtons />
    </main>
  );
};

export default QuoteDetails;
