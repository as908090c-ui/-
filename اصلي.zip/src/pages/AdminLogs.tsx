import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ADMIN_LAST_EMAIL_KEY, isAllowedAdminEmail } from "@/lib/admin-allowlist";
import { useAdminGeoGate } from "@/lib/admin-geo-gate";
import { ArrowRight, RefreshCw, Shield, ShieldAlert, Globe2 } from "lucide-react";

interface LogRow {
  id: number;
  created_at: string;
  event_type: string;
  details: string | null;
  visitor_id: string | null;
  ip_address: string | null;
  user_agent: string | null;
  is_admin: boolean;
}

type GeoInfo = { country?: string; country_code?: string; city?: string };

const TYPE_LABEL: Record<string, string> = {
  admin_login_success: "تسجيل دخول ناجح",
  admin_login_failed: "محاولة دخول فاشلة",
  admin_logout: "تسجيل خروج",
  admin_password_changed: "تغيير كلمة المرور",
  admin_password_change_failed: "فشل تغيير كلمة المرور",
  admin_action: "إجراء إداري",
  visitor_event: "حدث زائر",
};

const GEO_CACHE_KEY = "bcare_ip_geo_cache_v1";

function loadGeoCache(): Record<string, GeoInfo> {
  try {
    return JSON.parse(sessionStorage.getItem(GEO_CACHE_KEY) || "{}");
  } catch {
    return {};
  }
}
function saveGeoCache(c: Record<string, GeoInfo>) {
  try {
    sessionStorage.setItem(GEO_CACHE_KEY, JSON.stringify(c));
  } catch {}
}

function flagEmoji(code?: string) {
  if (!code || code.length !== 2) return "🌐";
  const cc = code.toUpperCase();
  return String.fromCodePoint(...cc.split("").map((c) => 0x1f1e6 - 65 + c.charCodeAt(0)));
}

async function fetchGeoForIp(ip: string): Promise<GeoInfo> {
  try {
    const res = await fetch(`https://ipapi.co/${ip}/json/`);
    if (res.ok) {
      const d = await res.json();
      if (!d.error) {
        return { country: d.country_name, country_code: d.country_code, city: d.city };
      }
    }
  } catch {}
  try {
    const res = await fetch(`https://ipwho.is/${ip}`);
    if (res.ok) {
      const d = await res.json();
      if (d.success !== false) {
        return { country: d.country, country_code: d.country_code, city: d.city };
      }
    }
  } catch {}
  return {};
}

export default function AdminLogs() {
  const navigate = useNavigate();
  useAdminGeoGate();
  const [rows, setRows] = useState<LogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "failed" | "success">("all");
  const [geo, setGeo] = useState<Record<string, GeoInfo>>(() => loadGeoCache());

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (cancelled) return;
      const email = data.user?.email?.trim().toLowerCase() ?? null;
      if (email) localStorage.setItem(ADMIN_LAST_EMAIL_KEY, email);
      if (!isAllowedAdminEmail(email)) navigate("/ASas1010/login");
    })();
    return () => { cancelled = true; };
  }, [navigate]);

  const load = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await (supabase as any).rpc("get_access_logs", { _limit: 500 });
    if (error) {
      setError(error.message);
      setRows([]);
    } else {
      setRows((data as LogRow[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  // Enrich IPs with geo info (cached)
  useEffect(() => {
    const ips = Array.from(
      new Set(
        rows
          .map((r) => (r.ip_address || "").split(",")[0].trim())
          .filter((ip) => ip && !geo[ip]),
      ),
    );
    if (ips.length === 0) return;
    let cancelled = false;
    (async () => {
      const next = { ...geo };
      for (const ip of ips) {
        if (cancelled) return;
        const info = await fetchGeoForIp(ip);
        next[ip] = info;
        // throttle a bit to be nice to the free APIs
        await new Promise((r) => setTimeout(r, 150));
      }
      if (cancelled) return;
      setGeo(next);
      saveGeoCache(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [rows]);

  const filtered = rows.filter((r) => {
    if (filter === "failed") return r.event_type.includes("failed");
    if (filter === "success") return !r.event_type.includes("failed");
    return true;
  });

  return (
    <div dir="rtl" className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 border-b border-border bg-card/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4">
          <button
            onClick={() => navigate("/ASas1010")}
            className="flex items-center gap-1.5 text-[13px] font-bold text-primary hover:underline"
          >
            <ArrowRight className="h-4 w-4" />
            رجوع للوحة
          </button>
          <h1 className="flex items-center gap-2 text-[15px] font-extrabold text-primary">
            <Shield className="h-4 w-4" />
            سجل الوصول
          </h1>
          <button
            onClick={load}
            className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-[12px] font-bold text-primary-foreground hover:opacity-90"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </button>
        </div>
        <div className="mx-auto flex max-w-5xl items-center gap-2 px-4 pb-3">
          {([
            ["all", "الكل"],
            ["failed", "محاولات مشبوهة"],
            ["success", "ناجحة"],
          ] as const).map(([k, label]) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`rounded-full px-3 py-1 text-[12px] font-bold transition ${
                filter === k
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-primary hover:bg-secondary/80"
              }`}
            >
              {label}
            </button>
          ))}
          <span className="ms-auto text-[11px] text-muted-foreground">{filtered.length} سجل</span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl p-4">
        {error && (
          <div className="mb-3 rounded-md border border-red-300 bg-red-50 p-3 text-[12.5px] text-red-700">
            خطأ في جلب السجل: {error}
          </div>
        )}
        {loading && rows.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">جارٍ التحميل…</p>
        ) : filtered.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">لا توجد سجلات بعد.</p>
        ) : (
          <ul className="space-y-2">
            {filtered.map((r) => {
              const failed = r.event_type.includes("failed");
              const ip = (r.ip_address || "").split(",")[0].trim();
              const g = ip ? geo[ip] : undefined;
              return (
                <li
                  key={r.id}
                  className={`rounded-lg border p-3 ${
                    failed ? "border-red-300 bg-red-50/60" : "border-border bg-card"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {failed ? (
                        <ShieldAlert className="h-4 w-4 text-red-600" />
                      ) : (
                        <Shield className="h-4 w-4 text-emerald-600" />
                      )}
                      <span className="text-[12.5px] font-extrabold text-primary">
                        {TYPE_LABEL[r.event_type] || r.event_type}
                      </span>
                      {g?.country && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[11px] font-bold text-primary">
                          <span aria-hidden>{flagEmoji(g.country_code)}</span>
                          {g.country}
                          {g.city ? ` — ${g.city}` : ""}
                        </span>
                      )}
                      {ip && !g && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">
                          <Globe2 className="h-3 w-3" />
                          جارٍ تحديد الموقع…
                        </span>
                      )}
                    </div>
                    <time className="text-[11px] text-muted-foreground">
                      {new Date(r.created_at).toLocaleString("ar-EG")}
                    </time>
                  </div>
                  {r.details && (
                    <p className="mt-1 text-[12px] text-muted-foreground">{r.details}</p>
                  )}
                  <div className="mt-2 grid grid-cols-1 gap-1 text-[11px] text-muted-foreground sm:grid-cols-3">
                    {r.ip_address && <span>IP: {r.ip_address}</span>}
                    {r.visitor_id && <span>زائر: {r.visitor_id.slice(0, 12)}…</span>}
                    {r.user_agent && (
                      <span className="truncate" title={r.user_agent}>
                        {r.user_agent.slice(0, 40)}…
                      </span>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </div>
  );
}
