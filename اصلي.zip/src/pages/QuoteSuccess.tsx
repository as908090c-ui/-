import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CheckCircle2, Eye, Home } from "lucide-react";
import Header from "@/components/site/Header";
import SiteFooter from "@/components/site/SiteFooter";
import PolicyPreview from "@/components/site/PolicyPreview";
import { getMyLatestApplication, type StoredApplication } from "@/lib/admin-storage";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { trOffer } from "@/lib/offer-text";

type SuccessState = { appId?: string };

const QuoteSuccess = () => {
  const navigate = useNavigate();
  const { t, isAr } = useI18n();
  const location = useLocation();
  const { appId } = (location.state as SuccessState) || {};
  const [app, setApp] = useState<StoredApplication | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const loadApp = async () => {
    try {
      const a = await getMyLatestApplication();
      if (a) {
        setApp(a);
        try { localStorage.setItem("bcare_last_app_v1", JSON.stringify(a)); } catch { /* ignore */ }
        return a;
      }
    } catch { /* ignore */ }
    return null;
  };

  useEffect(() => {
    try {
      const cached = localStorage.getItem("bcare_last_app_v1");
      if (cached) setApp(JSON.parse(cached));
    } catch { /* ignore */ }
    loadApp();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appId]);

  const openPreview = () => {
    setPreviewOpen(true);
    if (!app) loadApp();
  };

  return (
    <main dir={isAr ? "rtl" : "ltr"} className="min-h-screen bg-[hsl(210_40%_97%)]">
      <Header />

      <section className="mx-auto w-full max-w-[520px] px-4 py-8">
        <div className="overflow-hidden rounded-2xl bg-white p-7 text-center shadow-card sm:p-9">
          <div className="relative mx-auto grid h-24 w-24 place-items-center">
            <div className="absolute inset-0 animate-ping rounded-full bg-emerald-500/15" />
            <div className="grid h-20 w-20 place-items-center rounded-full bg-emerald-500/15 text-emerald-600">
              <CheckCircle2 className="h-12 w-12" strokeWidth={2.2} />
            </div>
          </div>

          <h1 className="mt-6 text-[22px] font-extrabold text-emerald-600 sm:text-[24px]">
            {t("تم إنشاء الوثيقة بنجاح", "Your policy has been issued successfully")}
          </h1>
          <p className="mt-1.5 text-[12.5px] font-light leading-6 text-emerald-700/80">
            {t(
              "وثيقتك أصبحت سارية من اليوم وجاري العمل على إعداد وثيقتك الكاملة.",
              "Your policy is effective as of today and we are preparing your full policy document.",
            )}
          </p>
          <p className="mt-2 text-[13.5px] leading-7 text-muted-foreground">
            {t(
              "تم تأكيد عملية الدفع وإصدار وثيقة التأمين الخاصة بك بنجاح. ستصلك نسخة من الوثيقة عبر البريد الإلكتروني والرسائل النصية (الرسايل النصية).",
              "Your payment has been confirmed and your insurance policy has been issued. A copy will be sent to you by email and SMS.",
            )}
          </p>

          {app && (
            <div className="mt-6 space-y-2.5 rounded-xl border border-border bg-muted/30 p-4 text-start">
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-muted-foreground">{t("رقم الوثيقة", "Policy number")}</span>
                <span className="font-mono font-extrabold text-brand-blue" dir="ltr">
                  {app.id}
                </span>
              </div>
              <div className="h-px bg-border/70" />
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-muted-foreground">{t("شركة التأمين", "Insurance company")}</span>
                <span className="font-extrabold text-[hsl(214_30%_15%)]">
                  {trOffer(app.company, isAr) || "—"}
                </span>
              </div>
              <div className="h-px bg-border/70" />
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-muted-foreground">{t("المبلغ المدفوع", "Amount paid")}</span>
                <span className="font-extrabold text-emerald-700">
                  {app.total != null ? `${Number(app.total).toFixed(2)} ${t("ر.س", "SAR")}` : "—"}
                </span>
              </div>
            </div>
          )}

          <div className="mt-7 grid gap-2.5">
            <button
              type="button"
              onClick={openPreview}
              className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-brand-blue text-[14px] font-extrabold text-white shadow-soft transition-all hover:brightness-110"
            >
              <Eye className="h-4 w-4" />
              {t("معاينة الوثيقة", "Preview policy")}
            </button>
            <button
              onClick={() => navigate("/", { replace: true })}
              className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-border bg-white text-[14px] font-extrabold text-[hsl(214_30%_15%)] hover:bg-muted/50"
            >
              <Home className="h-4 w-4" />
              {t("العودة للرئيسية", "Back to home")}
            </button>
          </div>
        </div>
      </section>

      <SiteFooter />

      <PolicyPreview
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        data={{
          company: app?.company || "",
          type: app?.type || app?.insuranceType || "شامل",
          price: app?.price ?? 0,
          fullName: app?.fullName,
          identity: app?.identity,
          birthDate: app?.birthDate,
          phone: app?.phone,
          brand: app?.carModel,
          year: app?.carYear,
          estValue: app?.estValue,
          purpose: app?.purpose,
          repairPlace: app?.repairPlace,
          startDate: app?.startDate,
          paid: true,
          total: app?.total ?? undefined,
          method: app?.method,
          cardBrand: app?.cardBrand,
          cardLast4: app?.cardLast4,
        }}
      />
    </main>
  );
};

export default QuoteSuccess;