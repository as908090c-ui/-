import { useEffect, useState } from "react";
import { ShieldCheck, Loader2 } from "lucide-react";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import { ADMIN_LAST_EMAIL_KEY, isAllowedAdminEmail } from "@/lib/admin-allowlist";

const readOAuthValue = (name: string): string | null => {
  if (typeof window === "undefined") return null;
  const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  const queryParams = new URLSearchParams(window.location.search);
  return hashParams.get(name) ?? queryParams.get(name);
};

const AdminLogin = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentEmail, setCurrentEmail] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(ADMIN_LAST_EMAIL_KEY);
  });

  const rememberEmail = (email: string | null) => {
    const normalized = email?.trim().toLowerCase() || null;
    setCurrentEmail(normalized);
    if (typeof window === "undefined") return;
    if (normalized) localStorage.setItem(ADMIN_LAST_EMAIL_KEY, normalized);
    else localStorage.removeItem(ADMIN_LAST_EMAIL_KEY);
  };

  // If already authenticated via Google, validate the email against the
  // admin allowlist before granting access. Unauthorized accounts are
  // signed out immediately.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (typeof window !== "undefined" && window.location.hash.includes("missing+OAuth+secret")) {
          window.history.replaceState(null, "", "/ASas1010/login");
          setError("تم إصلاح مسار Google. اضغط تسجيل الدخول مرة أخرى.");
          return;
        }

        const oauthError = readOAuthValue("error_description") ?? readOAuthValue("error");
        if (oauthError) {
          window.history.replaceState(null, "", "/ASas1010/login");
          setError(decodeURIComponent(oauthError.replace(/\+/g, " ")));
          return;
        }

        const accessToken = readOAuthValue("access_token");
        const refreshToken = readOAuthValue("refresh_token");
        if (accessToken && refreshToken) {
          setLoading(true);
          const { error: sessionError } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          });
          window.history.replaceState(null, "", "/ASas1010/login");
          if (sessionError) {
            setError(sessionError.message || "تعذر تثبيت جلسة Google.");
            setLoading(false);
            return;
          }
        }

        const { data } = await supabase.auth.getUser();
        if (cancelled) return;
        const email = data?.user?.email ?? null;
        if (email) rememberEmail(email);
        if (!data?.user) {
          setLoading(false);
          return;
        }
        if (!isAllowedAdminEmail(email)) {
          try { await supabase.auth.signOut(); } catch { /* ignore */ }
          if (!cancelled) {
            setError(`تم تسجيل الدخول بهذا الإيميل لكنه غير مصرّح له: ${email ?? "غير معروف"}`);
            setLoading(false);
          }
          return;
        }
        window.location.href = "/ASas1010";
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Redirect as soon as a Google session lands, using the session from the
  // event itself so nothing waits on extra auth calls.
  useEffect(() => {
    const goIfAllowed = (email: string | null | undefined) => {
      if (!email) return;
      rememberEmail(email);
      if (isAllowedAdminEmail(email)) {
        window.location.replace("/ASas1010");
      } else {
        setError(`تم تسجيل الدخول بهذا الإيميل لكنه غير مصرّح له: ${email}`);
        setLoading(false);
        setTimeout(() => { supabase.auth.signOut().catch(() => {}); }, 0);
      }
    };
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "INITIAL_SESSION") {
        goIfAllowed(session?.user?.email);
      }
    });
    return () => sub.subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Never leave the button spinning forever.
  useEffect(() => {
    if (!loading) return;
    const t = window.setTimeout(async () => {
      const { data } = await supabase.auth.getSession();
      const email = data.session?.user?.email;
      if (email && isAllowedAdminEmail(email)) {
        window.location.replace("/ASas1010");
        return;
      }
      setLoading(false);
      if (!email) setError("لم يكتمل تسجيل الدخول. حاول مرة أخرى.");
    }, 12000);
    return () => window.clearTimeout(t);
  }, [loading]);

  const handleGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      const redirectUri =
        typeof window !== "undefined"
          ? `${window.location.origin}/ASas1010/login`
          : undefined;
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: redirectUri,
      });
      if (result?.error) {
        setError(result.error.message || "تعذر تسجيل الدخول عبر Google");
        setLoading(false);
        return;
      }
      if (result?.redirected) return;
      const { data } = await supabase.auth.getSession();
      const email = data.session?.user?.email ?? null;
      if (!email) {
        setError("تم الرجوع من Google بدون جلسة دخول. حاول مرة أخرى.");
        setLoading(false);
        return;
      }
      rememberEmail(email);
      if (!isAllowedAdminEmail(email)) {
        try { await supabase.auth.signOut(); } catch { /* ignore */ }
        setError(`تم تسجيل الدخول بهذا الإيميل لكنه غير مصرّح له: ${email}`);
        setLoading(false);
        return;
      }
      window.location.replace("/ASas1010");
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ غير متوقع");
      setLoading(false);
    }
  };

  return (
    <main
      dir="rtl"
      className="grid min-h-screen place-items-center bg-[hsl(210_40%_97%)] px-4"
    >
      <div className="w-full max-w-[400px] rounded-2xl bg-white p-8 text-center shadow-card">
        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-brand-blue/10 text-brand-blue">
          <ShieldCheck className="h-8 w-8" strokeWidth={2.2} />
        </div>
        <h1 className="text-[20px] font-extrabold text-brand-blue">
          الدخول إلى لوحة التحكم
        </h1>
        <p className="mt-1 text-[13px] text-muted-foreground">
          الوصول مقصور على الحسابات المعتمدة فقط عبر Google
        </p>

        {currentEmail && (
          <div className="mt-4 rounded-xl border border-border bg-secondary/50 px-3 py-2 text-right">
            <p className="text-[11px] font-bold text-muted-foreground">الإيميل الذي تم تسجيل الدخول به</p>
            <p dir="ltr" className="mt-1 break-all text-[13px] font-extrabold text-foreground">
              {currentEmail}
            </p>
            <p className={isAllowedAdminEmail(currentEmail) ? "mt-1 text-[11px] font-bold text-emerald-700" : "mt-1 text-[11px] font-bold text-destructive"}>
              {isAllowedAdminEmail(currentEmail) ? "هذا الإيميل موجود في قائمة الموافقة" : "هذا الإيميل غير موجود في قائمة الموافقة"}
            </p>
          </div>
        )}

        <button
          type="button"
          onClick={handleGoogle}
          disabled={loading}
          className="mt-6 inline-flex w-full items-center justify-center gap-3 rounded-xl border border-input bg-white px-4 py-3 text-[14px] font-semibold text-foreground shadow-sm transition hover:bg-accent disabled:opacity-60"
        >
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <svg className="h-5 w-5" viewBox="0 0 48 48" aria-hidden="true">
              <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/>
              <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6 29.3 4 24 4 16.3 4 9.6 8.3 6.3 14.7z"/>
              <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.3 0-9.7-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
              <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4-4.1 5.3l6.2 5.2C40.9 35.6 44 30.3 44 24c0-1.2-.1-2.3-.4-3.5z"/>
            </svg>
          )}
          <span>{loading ? "جاري التحويل..." : "تسجيل الدخول عبر Google"}</span>
        </button>

        {error && (
          <p className="mt-4 text-[12.5px] text-destructive">{error}</p>
        )}
      </div>
    </main>
  );
};

export default AdminLogin;
