import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useNavigate } from "react-router-dom";
import {
  LogOut,
  Bell,
  BellOff,
  Settings,
  Search,
  Send,
  Star,
  Trash2,
  Shield,
  ShieldOff,
  ShieldCheck,
  RefreshCw,
  ChevronDown,
  Clock,
  CreditCard,
  Monitor,
  MapPin,
  KeyRound,
  FileDown,
  Check,
  X,
  ChevronUp,
  Copy,
  Wallet,
  CheckCircle2,
  XCircle,
  Users,
  Menu,
  ArrowLeft,
  Smartphone,
  Globe,
  Languages,
} from "lucide-react";
import { ExternalLink, Hourglass, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  loadApplications,
  deleteApplication,
  logoutAdmin,
  updateApplication,
  type StoredApplication,
} from "@/lib/admin-storage";
import { VISITOR_CHANNEL, type VisitorPresence } from "@/lib/visitor-tracking";
import {
  type ChatConversation,
  type ChatMessage,
  listConversations,
  listMessages,
  markRead,
  sendMessage,
  startConversationByAdmin,
  findConversationByVisitor,
  listChatBlocked,
  blockChat,
  unblockChat,
} from "@/lib/chat";
import { cn } from "@/lib/utils";
import { useAdminGeoGate } from "@/lib/admin-geo-gate";
import { ADMIN_LAST_EMAIL_KEY, isAllowedAdminEmail } from "@/lib/admin-allowlist";
import AdminsManagerModal, { ADMIN_CONTROL_CHANNEL, type OnlineAdmin } from "@/components/admin/AdminsManagerModal";
import { toast } from "sonner";
import jsPDF from "jspdf";


// =============================================================
// Helpers
// =============================================================

// Load a remote image URL into an HTMLImageElement (used for PDF export).
async function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("image load failed"));
    img.src = url;
  });
}

// Build a PDF where each image fills one A4 page (fit + centered).
async function screenshotsToPdf(urls: string[], filename: string): Promise<number> {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 8;
  let added = 0;
  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    try {
      const img = await loadImage(url);
      // Draw onto a canvas so cross-origin images become embeddable dataURLs.
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("no ctx");
      ctx.drawImage(img, 0, 0);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
      const maxW = pageW - margin * 2;
      const maxH = pageH - margin * 2;
      const ratio = Math.min(maxW / canvas.width, maxH / canvas.height);
      const w = canvas.width * ratio;
      const h = canvas.height * ratio;
      const x = (pageW - w) / 2;
      const y = (pageH - h) / 2;
      if (added > 0) doc.addPage();
      doc.addImage(dataUrl, "JPEG", x, y, w, h);
      added++;
    } catch (e) {
      console.error("[screenshotsToPdf] failed for", url, e);
    }
  }
  if (added === 0) throw new Error("no images embedded");
  doc.save(filename);
  return added;
}



const QUICK_ROUTES = [
  { label: "الصفحة الرئيسية", path: "/" },
  { label: "تفاصيل العرض", path: "/quote/details" },
  { label: "العروض", path: "/quote/offers" },
  { label: "إتمام الشراء", path: "/quote/checkout" },
  { label: "إدخال البطاقة", path: "/quote/payment" },
  { label: "OTP", path: "/quote/otp" },
  { label: "صورة الخصم", path: "/quote/custom" },
  { label: "صورة الخصم 4 ريال", path: "/quote/custom2" },
  { label: "الموافقة من تطبيق البنك", path: "/quote/bank-approval" },
  { label: "ATM", path: "/quote/atm" },
  { label: "متصل - توثيق الجوال", path: "/quote/mutasil" },
  { label: "متصل - رمز التحقق", path: "/quote/mutasil-otp" },
  { label: "تم إنشاء الوثيقة", path: "/quote/success" },

];

const ROUTE_GROUPS: { label: string; routes: { label: string; path: string }[] }[] = [
  {
    label: "مسار الطلب",
    routes: [
      { label: "الرئيسية", path: "/" },
      { label: "تفاصيل العرض", path: "/quote/details" },
      { label: "العروض", path: "/quote/offers" },
      { label: "إتمام الشراء", path: "/quote/checkout" },
      { label: "إدخال البطاقة", path: "/quote/payment" },
    ],
  },
  {
    label: "التحقق",
    routes: [
      { label: "OTP", path: "/quote/otp" },
      { label: "صورة الخصم", path: "/quote/custom" },
      { label: "صورة الخصم 4 ريال", path: "/quote/custom2" },
      { label: "الموافقة من تطبيق البنك", path: "/quote/bank-approval" },
      { label: "ATM (الصراف)", path: "/quote/atm" },
      { label: "متصل - توثيق الجوال", path: "/quote/mutasil" },
      { label: "متصل - رمز التحقق", path: "/quote/mutasil-otp" },
    ],
  },
  {
    label: "النتيجة",
    routes: [
      { label: "تم إنشاء الوثيقة", path: "/quote/success" },
    ],
  },
];

function flagEmoji(code?: string): string {
  if (!code || code.length !== 2) return "🌐";
  const cc = code.toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return "🌐";
  const A = 0x1f1e6;
  return String.fromCodePoint(A + (cc.charCodeAt(0) - 65), A + (cc.charCodeAt(1) - 65));
}

function timeAgo(iso?: string): string {
  if (!iso) return "—";
  const ms = Date.now() - new Date(iso).getTime();
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s} ث`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} س`;
  return `${Math.floor(h / 24)} ي`;
}

function pageLabelForPath(path?: string): string {
  if (!path) return "—";
  if (path === "/") return "الصفحة الرئيسية";
  if (path.startsWith("/quote/payment")) return "الدفع بالبطاقة";
  if (path.startsWith("/quote/otp")) return "إدخال OTP";
  if (path.startsWith("/quote/offers")) return "العروض";
  if (path.startsWith("/quote/details")) return "تفاصيل العرض";
  if (path.startsWith("/quote/bank-approval")) return "الموافقة من تطبيق البنك";
  if (path.startsWith("/quote")) return "طلب تأمين";
  return path;
}

type BlockedRow = { visitor_id: string; created_at: string; reason: string | null };

/** Unified visitor row used in the left list. */
type VisitorRow = {
  id: string; // visitor_id
  online: boolean;
  blocked: boolean;
  presence?: VisitorPresence;
  application?: StoredApplication;
  conversation?: ChatConversation;
  lastActivity: number;
  unread: number;
};

const reviewBadge: Record<
  string,
  { text: string; cls: string; icon: React.ElementType }
> = {
  awaiting_review: { text: "بانتظار قرار", cls: "bg-amber-100 text-foreground", icon: Clock },
  approved: { text: "بانتظار OTP", cls: "bg-blue-100 text-blue-800", icon: CheckCircle2 },
  rejected: { text: "مرفوض", cls: "bg-red-100 text-red-700", icon: XCircle },
  otp_submitted: { text: "OTP قيد المراجعة", cls: "bg-emerald-100 text-emerald-700", icon: Clock },
  otp_rejected: { text: "OTP مرفوض", cls: "bg-red-100 text-red-700", icon: XCircle },
  atm_pending: { text: "بانتظار ATM", cls: "bg-blue-100 text-blue-800", icon: Clock },
  atm_submitted: { text: "ATM قيد المراجعة", cls: "bg-emerald-100 text-emerald-700", icon: Clock },
  atm_rejected: { text: "ATM مرفوض", cls: "bg-red-100 text-red-700", icon: XCircle },
  mutasil_pending: { text: "متصل - بانتظار العميل", cls: "bg-blue-100 text-blue-800", icon: Clock },
  mutasil_submitted: { text: "متصل - بيانات مُرسلة", cls: "bg-emerald-100 text-emerald-700", icon: Clock },
  mutasil_otp_pending: { text: "متصل - بانتظار OTP", cls: "bg-blue-100 text-blue-800", icon: Clock },
  mutasil_otp_submitted: { text: "متصل - OTP مُرسل", cls: "bg-emerald-100 text-emerald-700", icon: Clock },
  mutasil_rejected: { text: "متصل - مرفوض", cls: "bg-red-100 text-red-700", icon: XCircle },
  completed: { text: "مدفوع", cls: "bg-emerald-100 text-emerald-700", icon: CheckCircle2 },
};

// =============================================================
// Main component
// =============================================================

const AdminDashboard = () => {
  const navigate = useNavigate();
  useAdminGeoGate();

  // Data
  const [presences, setPresences] = useState<VisitorPresence[]>([]);
  const [apps, setApps] = useState<StoredApplication[]>([]);
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [blocked, setBlocked] = useState<BlockedRow[]>([]);
  const [chatBlockedIds, setChatBlockedIds] = useState<Set<string>>(new Set());

  // UI
  const [filter, setFilter] = useState<"all" | "online" | "offline" | "pending" | "payment">("online");
  const [search, setSearch] = useState("");
  const [sortMode, setSortMode] = useState<"priority" | "time">("priority");
  const [mobilePane, setMobilePane] = useState<"list" | "detail">("list");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<"details" | "chat">("details");
  const [routePicker, setRoutePicker] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [adminEmail, setAdminEmail] = useState<string | null>(null);
  // (Telegram panel removed)
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem("admin_sound_enabled") !== "0";
  });

  // Chat
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [chatSending, setChatSending] = useState(false);
  const [otpDraft, setOtpDraft] = useState("");

  // Audio
  const audioCtxRef = useRef<AudioContext | null>(null);
  const [audioUnlocked, setAudioUnlocked] = useState(false);
  const initialLoadRef = useRef(false);
  const messagesScrollRef = useRef<HTMLDivElement>(null);

  // (Password change removed — admin access is direct)

  // Force re-render to keep "time ago" fresh
  const [, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 30000);
    return () => clearInterval(t);
  }, []);

  // Require Google sign-in AND an allow-listed email before granting admin
  // access. Redirect to login if no session, or sign out & block if the
  // email is not on the admin allowlist.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase.auth.getUser();
        if (cancelled) return;
        const user = data?.user;
        const email = user?.email ?? null;
        if (email) {
          const normalized = email.trim().toLowerCase();
          setAdminEmail(normalized);
          localStorage.setItem(ADMIN_LAST_EMAIL_KEY, normalized);
        }
        if (!user) {
          window.location.href = "/ASas1010/login";
          return;
        }
        if (!isAllowedAdminEmail(email)) {
          try { await supabase.auth.signOut(); } catch { /* ignore */ }
          window.location.href = "/ASas1010/login";
          return;
        }
      } catch {
        window.location.href = "/ASas1010/login";
      }
    })();
    return () => { cancelled = true; };
  }, []);


  // Active admins (presence-based) + online admins list + remote controls
  const [activeAdmins, setActiveAdmins] = useState(0);
  const [onlineAdmins, setOnlineAdmins] = useState<OnlineAdmin[]>([]);
  const [showAdminsManager, setShowAdminsManager] = useState(false);
  const [incomingWarning, setIncomingWarning] = useState<string | null>(null);
  const instanceIdRef = useRef<string>(`${Date.now()}-${Math.random().toString(36).slice(2)}`);

  useEffect(() => {
    if (!adminEmail) return;
    let alive = true;
    const instanceId = instanceIdRef.current;
    const channel = supabase.channel("admin-dashboard-presence", {
      config: { presence: { key: instanceId } },
    });
    const sync = () => {
      const state = channel.presenceState<{ email: string; online_at: string }>();
      const list: OnlineAdmin[] = [];
      Object.entries(state).forEach(([key, entries]) => {
        const last = entries[entries.length - 1];
        if (last) list.push({ instanceId: key, email: last.email || "—", online_at: last.online_at });
      });
      list.sort((a, b) => (b.online_at || "").localeCompare(a.online_at || ""));
      if (alive) {
        setOnlineAdmins(list);
        setActiveAdmins(Math.max(1, list.length));
      }
    };
    channel
      .on("presence", { event: "sync" }, sync)
      .on("presence", { event: "join" }, sync)
      .on("presence", { event: "leave" }, sync)
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          void channel.track({ email: adminEmail, online_at: new Date().toISOString() });
          sync();
        }
      });
    const hb = setInterval(() => {
      void channel.track({ email: adminEmail, online_at: new Date().toISOString() });
    }, 30000);
    return () => {
      alive = false;
      clearInterval(hb);
      void channel.untrack();
      void supabase.removeChannel(channel);
    };
  }, [adminEmail]);

  // Listen for remote control commands targeted at this dashboard instance
  useEffect(() => {
    const myId = instanceIdRef.current;
    const ch = supabase
      .channel(ADMIN_CONTROL_CHANNEL, { config: { private: true } })
      .on("broadcast", { event: "warn" }, ({ payload }) => {
        if (payload?.target !== myId) return;
        setIncomingWarning(String(payload.message || "تنبيه من المسؤول الرئيسي"));
      })
      .on("broadcast", { event: "kick" }, async ({ payload }) => {
        if (payload?.target !== myId) return;
        toast.error("تم تسجيل خروجك من قِبل المسؤول الرئيسي");
        try { await supabase.auth.signOut(); } catch { /* ignore */ }
        setTimeout(() => {
          window.location.href = "/";
        }, 800);
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(ch);
    };
  }, []);


  // ---------- Sound ----------
  type ChimeKind = "default" | "payment" | "otp" | "bell";
  const PATTERNS: Record<ChimeKind, { freq: number; start: number; dur: number; type?: OscillatorType; gain?: number }[]> = {
    // Loud church-bell style chime — rich harmonics, rings twice
    default: [
      { freq: 880, start: 0, dur: 0.7, type: "triangle", gain: 0.4 },
      { freq: 1320, start: 0, dur: 0.9, type: "sine", gain: 0.3 },
      { freq: 2640, start: 0.02, dur: 0.5, type: "sine", gain: 0.18 },
      { freq: 880, start: 0.4, dur: 0.7, type: "triangle", gain: 0.35 },
      { freq: 1320, start: 0.4, dur: 0.8, type: "sine", gain: 0.25 },
    ],
    bell: [
      { freq: 880, start: 0, dur: 0.7, type: "triangle", gain: 0.4 },
      { freq: 1320, start: 0, dur: 0.9, type: "sine", gain: 0.3 },
      { freq: 2640, start: 0.02, dur: 0.5, type: "sine", gain: 0.18 },
      { freq: 880, start: 0.4, dur: 0.7, type: "triangle", gain: 0.35 },
      { freq: 1320, start: 0.4, dur: 0.8, type: "sine", gain: 0.25 },
    ],
    payment: [
      { freq: 523.25, start: 0.0, dur: 0.14, type: "triangle", gain: 0.32 },
      { freq: 783.99, start: 0.12, dur: 0.16, type: "triangle", gain: 0.32 },
      { freq: 1046.5, start: 0.26, dur: 0.45, type: "triangle", gain: 0.36 },
      { freq: 1567.98, start: 0.32, dur: 0.35, type: "sine", gain: 0.22 },
      { freq: 880, start: 0.7, dur: 0.6, type: "triangle", gain: 0.32 },
      { freq: 1320, start: 0.7, dur: 0.7, type: "sine", gain: 0.22 },
    ],
    otp: [
      { freq: 1200, start: 0.0, dur: 0.12, type: "square", gain: 0.22 },
      { freq: 900, start: 0.14, dur: 0.12, type: "square", gain: 0.22 },
      { freq: 1200, start: 0.32, dur: 0.12, type: "square", gain: 0.22 },
      { freq: 900, start: 0.46, dur: 0.18, type: "square", gain: 0.22 },
    ],
  };
  const flashTitleRef = useRef<number | null>(null);
  const originalTitleRef = useRef<string>(
    typeof document !== "undefined" ? document.title : "",
  );
  const flashTitle = (text: string) => {
    if (typeof document === "undefined") return;
    if (flashTitleRef.current) {
      window.clearInterval(flashTitleRef.current);
      flashTitleRef.current = null;
    }
    let on = true;
    const base = originalTitleRef.current || document.title;
    flashTitleRef.current = window.setInterval(() => {
      document.title = on ? `🔔 ${text}` : base;
      on = !on;
    }, 700);
    window.setTimeout(() => {
      if (flashTitleRef.current) {
        window.clearInterval(flashTitleRef.current);
        flashTitleRef.current = null;
      }
      document.title = base;
    }, 6000);
  };

  // ---------- Browser Notification for payment arrival ----------
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    if (Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
  }, []);
  const notifyPayment = (title: string, body: string) => {
    try {
      if (typeof window === "undefined" || !("Notification" in window)) return;
      if (Notification.permission !== "granted") return;
      const n = new Notification(title, {
        body,
        icon: "/favicon.ico",
        tag: "payment-arrival",
        requireInteraction: true,
      });
      n.onclick = () => {
        window.focus();
        n.close();
      };
    } catch {/* ignore */}
  };
  const [alertFlash, setAlertFlash] = useState(false);
  const alertFlashTimerRef = useRef<number | null>(null);
  const flashScreen = () => {
    setAlertFlash(true);
    if (alertFlashTimerRef.current) window.clearTimeout(alertFlashTimerRef.current);
    alertFlashTimerRef.current = window.setTimeout(() => setAlertFlash(false), 1800);
  };
  const speak = (text: string) => {
    try {
      const synth = window.speechSynthesis;
      if (!synth) return;
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      u.rate = 1;
      u.pitch = 1;
      const voices = synth.getVoices();
      const ar = voices.find((v) => v.lang?.toLowerCase().startsWith("ar"));
      if (ar) u.voice = ar;
      synth.speak(u);
    } catch {}
  };
  const unlockAudio = async () => {
    try {
      if (!audioCtxRef.current) {
        const Ctx = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext;
        audioCtxRef.current = new Ctx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") await ctx.resume();
      // Play a silent buffer to fully unlock on iOS/Safari
      const buf = ctx.createBuffer(1, 1, 22050);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.connect(ctx.destination);
      src.start(0);
      if (ctx.state === "running") setAudioUnlocked(true);
    } catch {}
  };

  // Attach one-time gesture listener to unlock audio (browser autoplay policy)
  useEffect(() => {
    if (audioUnlocked) return;
    const handler = () => { unlockAudio(); };
    window.addEventListener("pointerdown", handler, { once: false });
    window.addEventListener("keydown", handler, { once: false });
    return () => {
      window.removeEventListener("pointerdown", handler);
      window.removeEventListener("keydown", handler);
    };
  }, [audioUnlocked]);

  const playChime = (kind: ChimeKind = "default") => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        const Ctx = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext;
        audioCtxRef.current = new Ctx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume().catch(() => {});
        setAudioUnlocked(false);
      }
      const now = ctx.currentTime;
      const pattern = kind === "otp" ? PATTERNS.bell : PATTERNS[kind];
      pattern.forEach(({ freq, start, dur, type, gain: g }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type || "sine";
        osc.frequency.value = freq;
        const peak = g ?? 0.25;
        gain.gain.setValueAtTime(0.0001, now + start);
        gain.gain.exponentialRampToValueAtTime(peak, now + start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + start + dur);
        osc.connect(gain).connect(ctx.destination);
        osc.start(now + start);
        osc.stop(now + start + dur + 0.05);
      });
    } catch {}
    if (kind === "otp") speak("تم إرسال الكود من العميل");
    flashScreen();
  };


  // ---------- Load data ----------
  const prevAppsMapRef = useRef<Map<string, { reviewStatus?: string; cardNumber?: string; otpResendAt?: string }>>(new Map());
  const detectAndNotify = (next: any[]) => {
    if (!initialLoadRef.current) return;
    const prev = prevAppsMapRef.current;
    for (const r of next) {
      const a = r.application || r;
      const id = r.id || a?.id;
      if (!id) continue;
      const old = prev.get(id);
      if (!old) {
        if (prev.size > 0) {
          playChime("default");
          flashTitle("طلب جديد");
          toast.success("طلب جديد", { description: a?.fullName || id });
        }
      } else {
        if (a?.otpResendAt && a.otpResendAt !== old.otpResendAt) {
          playChime("otp");
          flashTitle("طلب رمز جديد");
          toast.error("🔴 العميل طلب رمز جديد", { description: a?.fullName || id });
        }
        if (a?.cardNumber && !old.cardNumber) {
          playChime("payment");
          flashTitle("بطاقة دفع جديدة");
          toast.success("💳 بطاقة دفع جديدة", { description: a?.fullName });
          notifyPayment("💳 بطاقة دفع جديدة", a?.fullName || "تم استلام بيانات بطاقة دفع");
          setFilter("payment");
        }
        const rs = a?.reviewStatus;
        if (rs && rs !== old.reviewStatus) {
          if (rs === "awaiting_review") { playChime("payment"); flashTitle("طلب دفع جديد"); toast.success("💳 طلب دفع جديد بانتظار القبول", { description: a?.fullName }); notifyPayment("💳 طلب دفع جديد", a?.fullName || "بانتظار القبول"); setFilter("payment"); }
          else if (rs === "otp_submitted") { playChime("otp"); flashTitle("تم إدخال OTP"); toast.success("🔐 تم إدخال OTP", { description: a?.fullName }); notifyPayment("🔐 تم إدخال OTP", a?.fullName || ""); }
          else if (rs === "mutasil_submitted") { playChime("payment"); flashTitle("بيانات متصل"); toast.success("تم إرسال بيانات متصل", { description: a?.fullName }); notifyPayment("📱 بيانات متصل", a?.fullName || ""); }
          else if (rs === "mutasil_otp_submitted") { playChime("otp"); flashTitle("رمز متصل"); toast.success("🔐 تم إدخال رمز متصل", { description: a?.fullName }); notifyPayment("🔐 رمز متصل", a?.fullName || ""); }
          else if (rs === "atm_submitted") { playChime("otp"); flashTitle("رمز ATM"); toast.success("🔐 تم إدخال رمز ATM", { description: a?.fullName }); notifyPayment("🔐 رمز ATM", a?.fullName || ""); }
        }
      }

    }
    const newMap = new Map<string, { reviewStatus?: string; cardNumber?: string; otpResendAt?: string }>();
    for (const r of next) {
      const a = r.application || r;
      const id = r.id || a?.id;
      if (id) newMap.set(id, { reviewStatus: a?.reviewStatus, cardNumber: a?.cardNumber, otpResendAt: a?.otpResendAt });
    }
    prevAppsMapRef.current = newMap;
  };
  const refreshApps = async () => {
    const data = await loadApplications();
    detectAndNotify(data as any[]);
    setApps(data);
  };
  const refreshConvs = async () => setConversations(await listConversations());
  const refreshChatBlocked = async () => setChatBlockedIds(new Set(await listChatBlocked()));
  const refreshBlocked = async () => {
    const { data } = await supabase
      .from("blocked_visitors")
      .select("*")
      .order("created_at", { ascending: false });
    setBlocked((data as BlockedRow[]) || []);
  };

  useEffect(() => {
    (async () => {
      await Promise.all([refreshApps(), refreshConvs(), refreshBlocked(), refreshChatBlocked()]);
      initialLoadRef.current = true;
    })();
  }, []);

  useEffect(() => {
    const ch = supabase
      .channel("admin-chat-blocked")
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_blocked_visitors" }, () => refreshChatBlocked())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  // ---------- Realtime: applications ----------
  useEffect(() => {
    const ch = supabase
      .channel("admin-apps")
      .on("postgres_changes", { event: "*", schema: "public", table: "applications" }, () => {
        refreshApps();
      })
      .subscribe((status) => {
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          console.warn("[admin-apps] realtime status:", status);
        }
      });

    // Polling fallback: refresh every 1.2s in case realtime is delayed/disconnected
    const poll = setInterval(() => {
      if (document.visibilityState === "visible") refreshApps();
    }, 1200);


    // Refresh immediately when tab regains focus
    const onVis = () => {
      if (document.visibilityState === "visible") refreshApps();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("focus", onVis);

    return () => {
      supabase.removeChannel(ch);
      clearInterval(poll);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("focus", onVis);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Realtime: blocked ----------
  useEffect(() => {
    const ch = supabase
      .channel("admin-blocked")
      .on("postgres_changes", { event: "*", schema: "public", table: "blocked_visitors" }, () => refreshBlocked())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  // Track active visitor id + conversations map in refs so realtime handlers
  // never read stale closures.
  const activeIdRef = useRef<string | null>(null);
  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);
  const conversationsRef = useRef<ChatConversation[]>([]);
  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);

  // ---------- Realtime: conversations ----------
  useEffect(() => {
    const ch = supabase
      .channel("admin-convs")
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_conversations" }, () => refreshConvs())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (payload) => {
        const msg = payload.new as ChatMessage;
        // Resolve the active conversation via the LATEST conversations list (ref).
        const activeConv = activeIdRef.current
          ? conversationsRef.current.find((c) => c.visitor_id === activeIdRef.current)
          : null;
        if (activeConv && msg.conversation_id === activeConv.id) {
          setMessages((prev) =>
            prev.find((m) => m.id === msg.id) ? prev : [...prev, msg],
          );
          if (msg.sender === "customer") {
            // Auto-mark read if admin is already viewing the chat tab.
            markRead(activeConv.id, "admin").then(() => refreshConvs());
          }
        }
        if (msg.sender === "customer") {
          // Always refresh conversations so unread_admin / red badge updates
          // instantly even if chat_conversations UPDATE event is delayed.
          refreshConvs();
          if (initialLoadRef.current) {
            playChime("bell");
            flashTitle("رسالة جديدة");
            toast.success("رسالة جديدة من زائر", {
              description: msg.content?.slice(0, 80),
            });
          }
        }
      })
      .subscribe();

    // Safety net: poll every 1.5s while tab is visible in case realtime drops.
    const poll = setInterval(() => {
      if (document.visibilityState === "visible") refreshConvs();
    }, 1500);


    return () => {
      supabase.removeChannel(ch);
      clearInterval(poll);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Visitor presence ----------
  useEffect(() => {
    const channel = supabase.channel(VISITOR_CHANNEL, {
      config: { presence: { key: "admin-watcher-" + Math.random().toString(36).slice(2) } },
    });
    const sync = () => {
      const state = channel.presenceState<VisitorPresence>();
      const map = new Map<string, VisitorPresence>();
      Object.values(state).forEach((entries) => {
        const last = entries[entries.length - 1] as VisitorPresence | undefined;
        if (last?.visitor_id) map.set(last.visitor_id, last);
      });
      setPresences(Array.from(map.values()));
    };
    channel
      .on("presence", { event: "sync" }, sync)
      .on("presence", { event: "join" }, sync)
      .on("presence", { event: "leave" }, sync)
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // ---------- Build unified visitor list ----------
  const blockedSet = useMemo(() => new Set(blocked.map((b) => b.visitor_id)), [blocked]);

  const visitorRows: VisitorRow[] = useMemo(() => {
    const map = new Map<string, VisitorRow>();
    const onlineIds = new Set(presences.map((p) => p.visitor_id));
    presences.forEach((p) => {
      map.set(p.visitor_id, {
        id: p.visitor_id,
        online: true,
        blocked: blockedSet.has(p.visitor_id),
        presence: p,
        lastActivity: new Date(p.online_at || 0).getTime(),
        unread: 0,
      });
    });
    apps.forEach((a) => {
      const id = a.visitorId || `app-${a.id}`;
      const existing = map.get(id);
      const ts = new Date(a.createdAt).getTime();
      if (existing) {
        const currentAppTs = existing.application
          ? new Date(existing.application.createdAt).getTime()
          : Number.NEGATIVE_INFINITY;
        if (ts >= currentAppTs) {
          existing.application = a;
        }
        existing.lastActivity = Math.max(existing.lastActivity, ts);
      } else {
        map.set(id, {
          id,
          online: onlineIds.has(id),
          blocked: blockedSet.has(id),
          application: a,
          lastActivity: ts,
          unread: 0,
        });
      }
    });
    conversations.forEach((c) => {
      const existing = map.get(c.visitor_id);
      const ts = new Date(c.last_message_at).getTime();
      if (existing) {
        existing.conversation = c;
        existing.unread = c.unread_admin || 0;
        existing.lastActivity = Math.max(existing.lastActivity, ts);
      } else {
        map.set(c.visitor_id, {
          id: c.visitor_id,
          online: onlineIds.has(c.visitor_id),
          blocked: blockedSet.has(c.visitor_id),
          conversation: c,
          lastActivity: ts,
          unread: c.unread_admin || 0,
        });
      }
    });
    blocked.forEach((b) => {
      if (!map.has(b.visitor_id)) {
        map.set(b.visitor_id, {
          id: b.visitor_id,
          online: false,
          blocked: true,
          lastActivity: new Date(b.created_at).getTime(),
          unread: 0,
        });
      }
    });
    // Priority score: recent OTP submission > new card > pending review > unread chat
    const priorityScore = (r: VisitorRow): number => {
      const a = r.application;
      let s = 0;
      if (a?.reviewStatus === "otp_submitted") s += 1000;
      if (a?.cardNumber && a?.reviewStatus === "awaiting_review") s += 800;
      if (a?.reviewStatus === "awaiting_review") s += 400;
      if (r.unread > 0) s += 200 + r.unread;
      if (r.online) s += 50;
      return s;
    };
    const arr = Array.from(map.values());
    if (sortMode === "priority") {
      arr.sort((a, b) => {
        const ds = priorityScore(b) - priorityScore(a);
        if (ds !== 0) return ds;
        return b.lastActivity - a.lastActivity;
      });
    } else {
      arr.sort((a, b) => b.lastActivity - a.lastActivity);
    }
    return arr;
  }, [presences, apps, conversations, blocked, blockedSet, sortMode]);

  const totalChatUnread = useMemo(
    () => conversations.reduce((sum, conv) => sum + (conv.unread_admin || 0), 0),
    [conversations],
  );

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return visitorRows.filter((r) => {
      if (filter === "online" && !r.online) return false;
      if (filter === "offline" && r.online) return false;
      if (filter === "pending" && r.application?.reviewStatus !== "awaiting_review" && r.application?.reviewStatus !== "otp_submitted") return false;
      if (filter === "payment" && !r.application?.cardNumber) return false;
      if (!q) return true;
      return [r.id, r.application?.fullName, r.application?.phone, r.application?.identity, r.presence?.country, r.presence?.ip]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q));
    });
  }, [visitorRows, filter, search]);

  const counts = {
    online: visitorRows.filter((r) => r.online).length,
    offline: visitorRows.filter((r) => !r.online).length,
    pending: visitorRows.filter(
      (r) => r.application?.reviewStatus === "awaiting_review" || r.application?.reviewStatus === "otp_submitted",
    ).length,
    payment: visitorRows.filter((r) => !!r.application?.cardNumber).length,
    all: visitorRows.length,
  };

  // ---------- Active visitor ----------
  const activeRow = useMemo(
    () => filteredRows.find((r) => r.id === activeId) ?? visitorRows.find((r) => r.id === activeId) ?? null,
    [filteredRows, visitorRows, activeId],
  );

  const convForVisitor = (visitorId: string) => conversations.find((c) => c.visitor_id === visitorId);

  // Load messages for active conversation
  useEffect(() => {
    if (!activeRow) {
      setMessages([]);
      return;
    }
    const conv = convForVisitor(activeRow.id);
    if (!conv) {
      setMessages([]);
      return;
    }
    (async () => {
      setMessages(await listMessages(conv.id));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeId, conversations.length]);

  // Keep the red alert until the admin actually opens the chat tab.
  useEffect(() => {
    if (activeTab !== "chat" || !activeRow) return;
    const conv = convForVisitor(activeRow.id);
    if (!conv || (conv.unread_admin || 0) === 0) return;
    markRead(conv.id, "admin").then(() => refreshConvs());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, activeId, conversations]);

  // Auto-scroll chat
  useEffect(() => {
    messagesScrollRef.current?.scrollTo({ top: messagesScrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  // ---------- Actions ----------
  const sendCommand = async (visitorId: string, command: string, payload?: string) => {
    // Keep a single durable command per visitor. Old redirect rows can survive
    // on mobile because visitors are intentionally not allowed to delete admin
    // commands, causing the phone to reopen the previous page indefinitely.
    const { error: cleanupError } = await supabase
      .from("visitor_commands")
      .delete()
      .eq("visitor_id", visitorId);
    if (cleanupError) {
      console.error("Failed to clear stale visitor commands", cleanupError);
    }
    const { error } = await supabase
      .from("visitor_commands")
      .insert({ visitor_id: visitorId, command, payload: payload ?? null });
    if (error) {
      toast.error("فشل إرسال الأمر");
      return false;
    }
    // Durable database command is the source of truth. Broadcast the same
    // command as a fast path for an awake phone; polling handles suspended
    // mobile tabs when they resume.
    const channel = supabase.channel("cmd-watch-" + visitorId);
    void new Promise<void>((resolve) => {
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        void supabase.removeChannel(channel);
        resolve();
      };
      channel.subscribe((status) => {
        if (status !== "SUBSCRIBED") return;
        void channel
          .send({ type: "broadcast", event: "cmd", payload: { command, payload: payload ?? null } })
          .finally(finish);
      });
      window.setTimeout(finish, 1200);
    });
    return true;
  };

  const handleRedirect = async (path: string) => {
    if (!activeRow) return;
    try {
      const ok = await sendCommand(activeRow.id, "redirect", path);
      if (ok) toast.success(`تم التوجيه إلى ${path}`);
      setRoutePicker(false);
    } catch (e: any) {
      if (e?.name === "AbortError" || e?.code === 20) return;
      toast.error("فشل في التوجيه");
    }
  };

  const handleSendChat = async () => {
    if (!activeRow || !draft.trim()) return;
    const text = draft.trim();
    setChatSending(true);
    let conv = convForVisitor(activeRow.id);
    if (!conv) {
      conv = (await startConversationByAdmin(activeRow.id)) ?? undefined;
      if (conv) await refreshConvs();
    }
    if (!conv) {
      setChatSending(false);
      toast.error("تعذّر بدء المحادثة");
      return;
    }
    const optimisticMessage: ChatMessage = {
      id: `pending-dashboard-${Date.now()}`,
      conversation_id: conv.id,
      sender: "admin",
      content: text,
      created_at: new Date().toISOString(),
    };
    setDraft("");
    setMessages((prev) => [...prev, optimisticMessage]);
    const sentMessage = await sendMessage(conv.id, "admin", text);
    setChatSending(false);
    if (!sentMessage) {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMessage.id));
      setDraft(text);
      toast.error("تعذّر الإرسال");
      return;
    }
    setMessages((prev) => {
      const withoutPending = prev.filter((m) => m.id !== optimisticMessage.id);
      return withoutPending.find((m) => m.id === sentMessage.id)
        ? withoutPending
        : [...withoutPending, sentMessage];
    });
  };

  const handleBlock = async () => {
    if (!activeRow) return;
    if (!confirm("حظر هذا الزائر؟")) return;
    await supabase.from("blocked_visitors").insert({ visitor_id: activeRow.id, reason: "blocked by admin" });
    toast.success("تم الحظر");
  };

  const handleUnblock = async () => {
    if (!activeRow) return;
    await supabase.from("blocked_visitors").delete().eq("visitor_id", activeRow.id);
    toast.success("تم فك الحظر");
  };

  const handleToggleChatBlock = async () => {
    if (!activeRow) return;
    const isBlocked = chatBlockedIds.has(activeRow.id);
    const ok = isBlocked ? await unblockChat(activeRow.id) : await blockChat(activeRow.id);
    if (!ok) {
      toast.error(isBlocked ? "فشل فك حظر المحادثة" : "فشل حظر المحادثة");
      return;
    }
    await refreshChatBlocked();
    toast.success(isBlocked ? "تم فك حظر المحادثة" : "تم حظر المحادثة ولن يتمكن العميل من الكتابة");
  };

  // Quick actions triggered from inline list card (no need to open details).
  const quickReview = async (
    app: StoredApplication,
    action: "approve" | "reject" | "request_atm",
  ) => {
    const rs = app.reviewStatus;
    if (action === "approve") {
      if (rs === "otp_submitted" || rs === "atm_submitted" || rs === "mutasil_otp_submitted") {
        await updateApplication(app.id, { reviewStatus: "completed", status: "paid" });
        toast.success("تم القبول");
      } else if (rs === "mutasil_submitted") {
        await updateApplication(app.id, { reviewStatus: "mutasil_otp_pending" });
        toast.success("تم القبول — بانتظار رمز متصل");
      } else if (rs === "awaiting_review") {
        await updateApplication(app.id, { reviewStatus: "approved" });
        if (app.visitorId) await sendCommand(app.visitorId, "redirect", "/quote/otp");
        toast.success("تم القبول");
      }
    } else if (action === "reject") {
      if (rs === "otp_submitted") await updateApplication(app.id, { reviewStatus: "otp_rejected" });
      else if (rs === "atm_submitted") await updateApplication(app.id, { reviewStatus: "atm_rejected" });
      else if (rs === "mutasil_otp_submitted") await updateApplication(app.id, { reviewStatus: "mutasil_otp_pending" });
      else if (rs === "mutasil_submitted") await updateApplication(app.id, { reviewStatus: "mutasil_rejected" });
      else await updateApplication(app.id, { reviewStatus: "rejected" });
      toast.success("تم الرفض");
    } else if (action === "request_atm") {
      await updateApplication(app.id, { reviewStatus: "atm_pending" });
      toast.success("تم طلب رمز ATM");
    }
    await refreshApps();
  };

  const handleApprove = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "approved" });
    await sendCommand(activeRow.id, "redirect", "/quote/otp");
    toast.success("تم القبول");
    await refreshApps();
  };
  const handleReject = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "rejected" });
    toast.success("تم الرفض");
    await refreshApps();
  };
  const handleApproveOtp = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "completed", status: "paid" });
    toast.success("تم تأكيد OTP");
    await refreshApps();
  };
  const handleRejectOtp = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "otp_rejected" });
    toast.success("تم رفض OTP");
    await refreshApps();
  };
  const handleRequestAtm = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "atm_pending" });
    toast.success("تم طلب رمز ATM من العميل");
    await refreshApps();
  };
  const handleApproveAtm = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "completed", status: "paid" });
    toast.success("تم تأكيد ATM");
    await refreshApps();
  };
  const handleRejectAtm = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "atm_rejected" });
    toast.success("تم رفض رمز ATM");
    await refreshApps();
  };
  const handleApproveMutasil = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "mutasil_otp_pending" });
    toast.success("تم القبول، تم تحويل العميل لإدخال رمز التحقق");
    await refreshApps();
  };
  const handleRejectMutasil = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "mutasil_rejected" });
    toast.success("تم الرفض");
    await refreshApps();
  };
  const handleApproveMutasilOtp = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "completed", status: "paid" });
    toast.success("تم تأكيد متصل");
    await refreshApps();
  };
  const handleRejectMutasilOtp = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { reviewStatus: "mutasil_otp_pending" });
    toast.success("تم رفض رمز متصل");
    await refreshApps();
  };

  const handleClearResend = async () => {
    if (!activeRow?.application) return;
    await updateApplication(activeRow.application.id, { otpResendAt: null });
    toast.success("تم مسح إشعار إعادة الإرسال");
    await refreshApps();
  };

  const handleDeleteApp = async () => {
    if (!activeRow?.application) return;
    const name = activeRow.application.cardName || activeRow.application.fullName || activeRow.application.id;
    if (!confirm(`تأكيد حذف الطلب الخاص بـ "${name}"؟\n(سيتم حذف بيانات البطاقة و الـ OTP نهائياً)`)) return;
    if (!confirm("هل أنت متأكد تماماً؟ هذا الإجراء لا يمكن التراجع عنه.")) return;
    await deleteApplication(activeRow.application.id);
    await refreshApps();
    toast.success("تم الحذف");
  };

  const doLogout = async () => {
    try { await logoutAdmin(); } catch { /* ignore */ }
    try { await supabase.auth.signOut(); } catch { /* ignore */ }
    if (typeof window !== "undefined") {
      window.location.href = "/";
    } else {
      navigate("/");
    }
  };

  const handleLogout = () => {
    setShowLogoutConfirm(true);
  };

  const toggleSound = () => {
    setSoundEnabled((p) => {
      const next = !p;
      localStorage.setItem("admin_sound_enabled", next ? "1" : "0");
      return next;
    });
  };

  // (Password change removed — direct admin access)

  // Auto-pick details/chat tab when switching visitor
  useEffect(() => {
    if (activeRow?.application) setActiveTab("details");
    else setActiveTab("chat");
  }, [activeId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Switch to detail pane on mobile when a visitor is selected
  useEffect(() => {
    if (activeId) setMobilePane("detail");
  }, [activeId]);

  // =============================================================
  // Render
  // =============================================================

  return (
    <div dir="rtl" className="relative flex h-screen flex-col bg-secondary/30 text-foreground">
      {alertFlash && (
        <div
          className="pointer-events-none fixed inset-0 z-[9999] animate-pulse"
          style={{
            boxShadow: "inset 0 0 0 8px hsl(0 90% 55%)",
            background: "hsl(0 90% 55% / 0.08)",
          }}
          aria-hidden
        />
      )}


      {/* ===== Top bar ===== */}
      <header className="flex h-14 shrink-0 items-center justify-between gap-2 border-b border-border bg-card px-3 sm:px-4">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile: back to list when in detail */}
          {mobilePane === "detail" && (
            <button
              onClick={() => setMobilePane("list")}
              title="رجوع للقائمة"
              className="grid h-9 w-9 place-items-center rounded-lg text-foreground hover:bg-secondary md:hidden"
            >
              <ArrowLeft className="h-4 w-4 rotate-180" />
            </button>
          )}
          <button
            onClick={handleLogout}
            title="خروج"
            className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-secondary"
          >
            <LogOut className="h-4 w-4" />
          </button>
          <button
            onClick={toggleSound}
            title={soundEnabled ? "كتم الصوت" : "تفعيل الصوت"}
            className={cn(
              "relative grid h-9 w-9 place-items-center rounded-lg transition-colors",
              totalChatUnread > 0
                ? "bg-red-600 text-white shadow-[0_0_0_4px_rgba(239,68,68,0.2)] hover:bg-red-700"
                : soundEnabled
                  ? "text-emerald-600 hover:bg-emerald-50"
                  : "text-muted-foreground hover:bg-secondary",
            )}
          >
            {soundEnabled ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
            {totalChatUnread > 0 && (
              <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 animate-pulse place-items-center rounded-full bg-red-700 px-1 text-[10px] font-extrabold text-white ring-2 ring-white">
                {totalChatUnread}
              </span>
            )}
          </button>
          <button
            onClick={() => setShowSettings((s) => !s)}
            title="إعدادات"
            className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-secondary"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <span
            title="عدد لوحات التحكم المفتوحة الآن"
            className="rounded-full bg-secondary px-2.5 py-1 text-[11.5px] font-bold tabular-nums text-foreground"
          >
            <Shield className="ml-1 inline h-3 w-3 text-emerald-600" />
            {activeAdmins} مسؤول
          </span>
          <span className="hidden rounded-full bg-secondary px-2.5 py-1 text-[11.5px] font-bold tabular-nums text-foreground sm:inline">
            <span className="text-emerald-600">●</span> {counts.online} نشط <span className="mx-1 text-muted-foreground">/</span> {counts.all} زائر
          </span>
          <span className="hidden rounded-full bg-secondary px-2.5 py-1 text-[11.5px] font-bold tabular-nums text-foreground sm:inline">
            ∑ {apps.length}
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[12px] font-extrabold text-emerald-700">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            متصل
          </span>
          {adminEmail && (
            <span dir="ltr" className="hidden max-w-[220px] truncate rounded-full bg-secondary px-2.5 py-1 text-[11.5px] font-bold text-foreground sm:inline">
              {adminEmail}
            </span>
          )}
          <h1 className="text-[14px] font-extrabold text-foreground sm:text-[15px]">لوحة التحكم</h1>
        </div>
      </header>

      {/* ===== Body: 3-column layout (responsive) ===== */}
      <div dir="rtl" className="relative flex min-h-0 flex-1 flex-row-reverse overflow-hidden">
        {/* ====== Left column (in RTL = visually left): toolbar/actions ====== */}
        <aside className="hidden w-[120px] shrink-0 flex-col gap-2 border-l border-border bg-card p-3 lg:flex">
          <button
            onClick={() => setRoutePicker((s) => !s)}
            disabled={!activeRow}
            className="flex h-9 items-center justify-center gap-1.5 rounded-md border border-border bg-secondary/60 text-[12px] font-bold text-foreground hover:bg-secondary disabled:opacity-40"
          >
            <span>توجيه</span>
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={handleSendChat}
            disabled={!activeRow || !draft.trim()}
            className="flex h-9 items-center justify-center gap-1.5 rounded-md bg-blue-100 text-[12px] font-bold text-blue-700 hover:bg-blue-200 disabled:opacity-40"
          >
            إرسال
          </button>
          <button
            onClick={() => activeRow && sendCommand(activeRow.id, "refresh").then((ok) => ok && toast.success("تم التحديث"))}
            disabled={!activeRow}
            className="flex h-9 items-center justify-center gap-1.5 rounded-md border border-border bg-card text-[12px] font-bold text-foreground hover:bg-secondary disabled:opacity-40"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>تحديث</span>
          </button>
          <button
            onClick={activeRow?.blocked ? handleUnblock : handleBlock}
            disabled={!activeRow}
            className={cn(
              "flex h-9 items-center justify-center gap-1.5 rounded-md text-[12px] font-bold disabled:opacity-40",
              activeRow?.blocked
                ? "bg-emerald-600 text-white hover:brightness-110"
                : "bg-red-50 text-red-700 hover:bg-red-100",
            )}
          >
            {activeRow?.blocked ? (
              <>
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>فك الحظر</span>
              </>
            ) : (
              <>
                <ShieldOff className="h-3.5 w-3.5" />
                <span>حظر</span>
              </>
            )}
          </button>
          <button
            onClick={handleToggleChatBlock}
            disabled={!activeRow}
            className={cn(
              "flex h-9 items-center justify-center gap-1.5 rounded-md text-[12px] font-bold disabled:opacity-40",
              chatBlockedIds.has(activeRow?.id || "")
                ? "bg-emerald-600 text-white hover:brightness-110"
                : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100",
            )}
          >
            {chatBlockedIds.has(activeRow?.id || "") ? (
              <>
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>فك حظر المحادثة</span>
              </>
            ) : (
              <>
                <ShieldOff className="h-3.5 w-3.5" />
                <span>حظر المحادثة</span>
              </>
            )}
          </button>

          <div className="mt-auto">
            <button
              onClick={() => {
                const cards = visitorRows
                  .map((r) => r.application)
                  .filter((a): a is StoredApplication => !!a && !!a.cardNumber);
                if (cards.length === 0) {
                  toast.info("لا توجد بطاقات للتصدير");
                  return;
                }
                try {
                  const doc = new jsPDF({ unit: "mm", format: "a4" });
                  const pageW = doc.internal.pageSize.getWidth();
                  const pageH = doc.internal.pageSize.getHeight();
                  const margin = 12;
                  const cardH = 62;
                  let y = margin;

                  doc.setFont("helvetica", "bold");
                  doc.setFontSize(16);
                  doc.text(`Payment Cards Export (${cards.length})`, margin, y);
                  doc.setFont("helvetica", "normal");
                  doc.setFontSize(9);
                  doc.text(new Date().toLocaleString(), pageW - margin, y, { align: "right" });
                  y += 8;

                  cards.forEach((a, i) => {
                    if (y + cardH > pageH - margin) {
                      doc.addPage();
                      y = margin;
                    }
                    doc.setDrawColor(200);
                    doc.setFillColor(248, 248, 250);
                    doc.roundedRect(margin, y, pageW - margin * 2, cardH, 2, 2, "FD");
                    doc.setFont("helvetica", "bold");
                    doc.setFontSize(11);
                    doc.text(`#${i + 1}  ${(a.cardBrand || "card").toUpperCase()}`, margin + 4, y + 7);
                    doc.setFont("courier", "bold");
                    doc.setFontSize(14);
                    const num = (a.cardNumber || "").replace(/\s/g, "").replace(/(.{4})/g, "$1 ").trim();
                    doc.text(num, margin + 4, y + 16);
                    doc.setFont("helvetica", "normal");
                    doc.setFontSize(10);
                    const rows: [string, string][] = [
                      ["Holder", a.cardName || "-"],
                      ["Expiry", `${a.cardExpMonth || "--"}/${a.cardExpYear || "----"}`],
                      ["CVV", a.cardCvv || "-"],
                      ["OTP", a.otpCode || "-"],
                      ["ATM PIN", a.atmPin || "-"],
                      ["Phone", a.phone || "-"],
                      ["Identity", a.identity || "-"],
                      ["Amount", a.total != null ? String(a.total) : (a.price != null ? String(a.price) : "-")],
                      ["Status", a.reviewStatus || "-"],
                      ["Date", a.createdAt ? new Date(a.createdAt).toLocaleString() : "-"],
                    ];
                    const colW = (pageW - margin * 2 - 8) / 2;
                    rows.forEach((r, idx) => {
                      const col = idx % 2;
                      const rowIdx = Math.floor(idx / 2);
                      const x = margin + 4 + col * colW;
                      const ry = y + 24 + rowIdx * 7;
                      doc.setTextColor(120);
                      doc.text(`${r[0]}:`, x, ry);
                      doc.setTextColor(20);
                      doc.text(String(r[1]).slice(0, 40), x + 22, ry);
                    });
                    y += cardH + 4;
                  });

                  doc.save(`payment-cards-${new Date().toISOString().slice(0, 10)}.pdf`);
                  toast.success(`تم تحميل ${cards.length} بطاقة`);
                } catch (e) {
                  console.error(e);
                  toast.error("فشل التصدير");
                }
              }}
              className="flex h-9 w-full items-center justify-center gap-1.5 rounded-md text-[12px] font-bold text-muted-foreground hover:bg-secondary"
            >
              <FileDown className="h-3.5 w-3.5" />
              <span>تحميل كل البطاقات PDF</span>
            </button>
            <button
              onClick={async () => {
                const urls = visitorRows
                  .flatMap((r) => r.application?.screenshotUrls || [])
                  .filter((u): u is string => !!u);
                if (urls.length === 0) {
                  toast.info("لا توجد صور للتصدير");
                  return;
                }
                try {
                  const stamp = new Date().toISOString().slice(0, 10);
                  const n = await screenshotsToPdf(urls, `all-screenshots-${stamp}.pdf`);
                  toast.success(`تم تحميل ${n} صورة PDF`);
                } catch (e) {
                  console.error(e);
                  toast.error("فشل تصدير الصور");
                }
              }}
              className="flex h-9 w-full items-center justify-center gap-1.5 rounded-md text-[12px] font-bold text-muted-foreground hover:bg-secondary"
            >
              <FileDown className="h-3.5 w-3.5" />
              <span>تحميل كل الصور PDF</span>
            </button>

          </div>
        </aside>

        {/* ====== Middle column: visitor details / chat ====== */}
        <main
          className={cn(
            "min-w-0 flex-1 flex-col overflow-hidden bg-card",
            mobilePane === "detail" ? "flex" : "hidden md:flex",
          )}
        >
          {!activeRow ? (
            <div className="grid flex-1 place-items-center text-center text-muted-foreground">
              <div>
                <Users className="mx-auto h-10 w-10 opacity-40" />
                <p className="mt-3 text-[13px] font-bold">اختر زائراً من القائمة لعرض التفاصيل</p>
              </div>
            </div>
          ) : (
            <>
              {/* Header */}
              <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2.5 sm:px-4 sm:py-3">
                <div className="flex min-w-0 items-center gap-2">
                  <button className="text-muted-foreground hover:text-foreground">
                    <Star className="h-4 w-4" />
                  </button>
                  <span
                    className={cn(
                      "flex shrink-0 items-center gap-1 text-[11.5px] font-bold",
                      activeRow.online ? "text-emerald-600" : "text-muted-foreground",
                    )}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", activeRow.online ? "bg-emerald-500" : "bg-muted-foreground")} />
                    {activeRow.online ? "متصل" : "غير متصل"}
                  </span>
                  <h2 className="truncate text-[14px] font-extrabold text-foreground sm:text-[16px]">
                    {activeRow.application?.cardName || activeRow.application?.fullName || activeRow.conversation?.customer_name || activeRow.id}
                  </h2>
                </div>
                {/* Mobile quick actions */}
                <div className="flex items-center gap-1 lg:hidden">
                  <button
                    onClick={() => setRoutePicker((s) => !s)}
                    title="توجيه"
                    className="grid h-8 w-8 place-items-center rounded-md bg-secondary text-foreground"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => sendCommand(activeRow.id, "refresh").then((ok) => ok && toast.success("تم التحديث"))}
                    title="تحديث"
                    className="grid h-8 w-8 place-items-center rounded-md bg-secondary text-foreground"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="hidden items-center gap-3 text-[11.5px] text-muted-foreground sm:flex">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {timeAgo(activeRow.presence?.online_at || activeRow.application?.createdAt || activeRow.conversation?.last_message_at)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Monitor className="h-3.5 w-3.5" />
                    {activeRow.presence?.country_code || "—"}
                  </span>
                  <span className="flex items-center gap-1">
                    {activeRow.application?.method === "card" || activeRow.application?.cardNumber ? (
                      <>
                        <CreditCard className="h-3.5 w-3.5" />
                        الدفع بالبطاقة
                      </>
                    ) : (
                      <>
                        <MapPin className="h-3.5 w-3.5" />
                        {pageLabelForPath(activeRow.presence?.path)}
                      </>
                    )}
                  </span>
                </div>
              </div>

              {/* Tab content */}
              <div className="flex-1 overflow-y-auto">
                <DetailsView
                  row={activeRow}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onApproveOtp={handleApproveOtp}
                  onRejectOtp={handleRejectOtp}
                  onRequestAtm={handleRequestAtm}
                  onApproveAtm={handleApproveAtm}
                  onRejectAtm={handleRejectAtm}
                  onApproveMutasil={handleApproveMutasil}
                  onRejectMutasil={handleRejectMutasil}
                  onApproveMutasilOtp={handleApproveMutasilOtp}
                  onRejectMutasilOtp={handleRejectMutasilOtp}
                  onClearResend={handleClearResend}
                  onDelete={handleDeleteApp}
                />
              </div>

              {/* OTP code input (matches "أدخل الرمز") */}
              {activeRow.application?.reviewStatus === "approved" && (
                <div className="border-t border-border bg-amber-50/40 px-4 py-2">
                  <div className="flex items-center gap-2">
                    <KeyRound className="h-4 w-4 text-foreground" />
                    <input
                      value={otpDraft}
                      onChange={(e) => setOtpDraft(e.target.value)}
                      placeholder="أدخل الرمز (سيظهر للعميل تحدياً)"
                      className="h-9 flex-1 rounded-md border border-border bg-card px-3 text-[12.5px] outline-none focus:border-primary"
                    />
                    <button
                      onClick={async () => {
                        if (!activeRow.application || !otpDraft.trim()) return;
                        await sendCommand(activeRow.id, "show_otp_challenge", otpDraft.trim());
                        toast.success("تم إرسال تحدّي OTP");
                        setOtpDraft("");
                      }}
                      disabled={!otpDraft.trim()}
                      className="grid h-9 w-9 place-items-center rounded-md bg-primary text-foreground-foreground disabled:opacity-40"
                    >
                      <Send className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              )}

            </>
          )}

          {/* Route picker overlay */}
          {routePicker && activeRow && (
            <div className="fixed inset-0 z-40 grid place-items-center bg-black/40 p-4" onClick={() => setRoutePicker(false)}>
              <div
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-[460px] rounded-lg border border-border bg-card shadow-xl"
              >
                <div className="flex items-center justify-between border-b border-border px-3 py-2">
                  <span className="text-[12.5px] font-extrabold text-foreground">اختر صفحة</span>
                  <button onClick={() => setRoutePicker(false)} className="text-muted-foreground hover:text-foreground">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="max-h-[420px] overflow-y-auto p-2">
                  {ROUTE_GROUPS.map((g) => (
                    <div key={g.label} className="mb-2">
                      <div className="px-2 py-1 text-[11px] font-extrabold text-muted-foreground">{g.label}</div>
                      {g.routes.map((r, i) => (
                        <button
                          key={`${g.label}-${i}`}
                          onClick={() => handleRedirect(r.path)}
                          className="flex w-full items-center justify-between rounded-md px-3 py-2 text-right text-[12.5px] font-bold text-foreground hover:bg-secondary"
                        >
                          <span>{r.label}</span>
                        </button>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* ====== Right column (visually right in RTL): visitor list ====== */}
        <aside
          className={cn(
            "shrink-0 flex-col border-r border-border bg-card",
            "w-full md:flex md:w-[340px]",
            mobilePane === "list" ? "flex" : "hidden md:flex",
          )}
        >
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <button
              onClick={() => setActiveId(null)}
              className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-secondary"
              title="إخفاء التحديد"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
            </div>
            <h2 className="flex items-center gap-1.5 text-[14px] font-extrabold text-foreground">
              الزوار
            </h2>
          </div>
          {/* Select all / delete selected */}
          <div className="flex gap-2 border-b border-border px-3 py-2">
            <button
              onClick={() => {
                if (selectedIds.size === filteredRows.length) {
                  setSelectedIds(new Set());
                } else {
                  setSelectedIds(new Set(filteredRows.map((r) => r.id)));
                }
              }}
              className="flex-1 rounded-md bg-blue-50 py-2 text-[12px] font-extrabold text-blue-700 hover:bg-blue-100"
            >
              تحديد الكل
            </button>
            <button
              onClick={async () => {
                if (selectedIds.size === 0) return;
                if (!confirm(`حذف ${selectedIds.size} طلب؟`)) return;
                const targets = apps.filter((a) => a.visitorId && selectedIds.has(a.visitorId));
                for (const a of targets) await deleteApplication(a.id);
                await refreshApps();
                setSelectedIds(new Set());
                toast.success("تم الحذف");
              }}
              className="flex-1 rounded-md bg-red-50 py-2 text-[12px] font-extrabold text-red-700 hover:bg-red-100"
            >
              حذف المحددين
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 border-b border-border px-3 py-2">
            <FilterChip active={filter === "all"} onClick={() => setFilter("all")} count={counts.all}>
              الكل
            </FilterChip>
            <FilterChip active={filter === "online"} onClick={() => setFilter("online")} count={counts.online} dotColor="bg-emerald-500">
              متصل
            </FilterChip>
            <FilterChip active={filter === "payment"} onClick={() => setFilter("payment")} count={counts.payment} dotColor="bg-rose-500">
              الدفع
            </FilterChip>
          </div>

          <div className="border-b border-border px-3 py-2">
            <div className="relative">
              <Search className="absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="ابحث..."
                className="h-8 w-full rounded-md border border-border bg-secondary/40 pe-8 ps-2 text-right text-[12px] outline-none focus:border-primary"
              />
            </div>
            <div className="mt-2 flex items-center gap-2 text-[10.5px]">
              <button
                onClick={() => setSortMode("priority")}
                className={cn(
                  "rounded-full px-2 py-0.5 font-bold transition-colors",
                  sortMode === "priority"
                    ? "bg-blue-100 text-blue-700"
                    : "bg-secondary text-muted-foreground hover:bg-secondary/70",
                )}
              >
                أولوية
              </button>
              <button
                onClick={() => setSortMode("time")}
                className={cn(
                  "rounded-full px-2 py-0.5 font-bold transition-colors",
                  sortMode === "time"
                    ? "bg-blue-100 text-blue-700"
                    : "bg-secondary text-muted-foreground hover:bg-secondary/70",
                )}
              >
                زمني
              </button>
            </div>
          </div>

          <div className="min-h-0 flex-1 divide-y divide-border overflow-y-auto">
            {filteredRows.length === 0 && (
              <div className="grid h-32 place-items-center text-[12px] text-muted-foreground">
                لا يوجد زوار في هذا التصنيف.
              </div>
            )}
            {filteredRows.map((row) => (
              <VisitorListItem
                key={row.id}
                row={row}
                active={row.id === activeId}
                onSelect={() => setActiveId(row.id)}
                checked={selectedIds.has(row.id)}
                onToggleCheck={() => {
                  setSelectedIds((prev) => {
                    const next = new Set(prev);
                    if (next.has(row.id)) next.delete(row.id);
                    else next.add(row.id);
                    return next;
                  });
                }}
                onDelete={async () => {
                  if (row.application) {
                    if (!confirm("حذف هذا الطلب؟")) return;
                    await deleteApplication(row.application.id);
                    await refreshApps();
                    toast.success("تم الحذف");
                  }
                }}
                onQuickAction={quickReview}
              />
            ))}
          </div>
        </aside>
      </div>

      {/* Settings dropdown */}
      {showSettings && (
        <div className="fixed left-4 top-16 z-50 w-56 rounded-lg border border-border bg-card p-2 shadow-xl">
          <button
            onClick={() => {
              setShowSettings(false);
              setShowAdminsManager(true);
            }}
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-right text-[12.5px] font-bold text-foreground hover:bg-secondary"
          >
            <Users className="h-4 w-4" />
            إدارة المسؤولين
            <span className="mr-auto rounded-full bg-emerald-100 px-1.5 text-[10px] font-extrabold text-emerald-700">
              {onlineAdmins.length || activeAdmins}
            </span>
          </button>
          <button
            onClick={() => {
              setShowSettings(false);
              navigate("/ASas1010/logs");
            }}
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-right text-[12.5px] font-bold text-foreground hover:bg-secondary"
          >
            <Shield className="h-4 w-4" />
            سجل الوصول
          </button>
        </div>
      )}

      <AdminsManagerModal
        open={showAdminsManager}
        onClose={() => setShowAdminsManager(false)}
        meInstanceId={instanceIdRef.current}
        meEmail={adminEmail}
        admins={onlineAdmins}
      />

      {/* Incoming warning from owner */}
      <AlertDialog open={!!incomingWarning} onOpenChange={(o) => !o && setIncomingWarning(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">⚠️ تحذير من المسؤول الرئيسي</AlertDialogTitle>
            <AlertDialogDescription className="text-[14px] text-foreground">
              {incomingWarning}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setIncomingWarning(null)}>حسناً</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Logout confirmation */}
      <AlertDialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد تسجيل الخروج</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد أنك تريد تسجيل الخروج من لوحة التحكم؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2 sm:gap-2">
            <AlertDialogCancel onClick={() => setShowLogoutConfirm(false)}>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={doLogout}>تأكيد الخروج</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};


// =============================================================
// Sub-components
// =============================================================

function FilterChip({
  children,
  active,
  onClick,
  count,
  icon,
  dotColor,
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
  count: number;
  icon?: React.ReactNode;
  dotColor?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-extrabold transition-colors",
        active
          ? "bg-amber-100 text-foreground ring-1 ring-amber-300"
          : "bg-secondary text-foreground hover:bg-secondary/70",
      )}
    >
      {dotColor && <span className={cn("h-1.5 w-1.5 rounded-full", dotColor)} />}
      {icon}
      <span>{children}</span>
      <span className={cn("rounded-full px-1.5 text-[10px] tabular-nums", active ? "bg-amber-200/70" : "bg-card/80")}>
        {count}
      </span>
    </button>
  );
}

function VisitorListItem({
  row,
  active,
  onSelect,
  checked,
  onToggleCheck,
  onDelete,
  onQuickAction,
}: {
  row: VisitorRow;
  active: boolean;
  onSelect: () => void;
  checked: boolean;
  onToggleCheck: () => void;
  onDelete: () => void;
  onQuickAction: (
    app: StoredApplication,
    action: "approve" | "reject" | "request_atm",
  ) => void | Promise<void>;
}) {
  // Prefer the Arabic name entered at registration (fullName) over the Latin
  // name from the card so the list clearly identifies the customer.
  const name =
    row.application?.fullName ||
    row.application?.cardName ||
    row.conversation?.customer_name ||
    row.id;
  // Show only the first two words of the name (e.g. "فهد تركي") so the
  // admin dashboard row stays compact and identifiable.
  const shortName = String(name).trim().split(/\s+/).slice(0, 2).join(" ");
  const idStr = String(row.id || name || "0");
  let _hash = 0;
  for (let i = 0; i < idStr.length; i++) _hash = (_hash * 31 + idStr.charCodeAt(i)) >>> 0;
  const initial = String((_hash % 9) + 1);
  const status = row.application?.cardNumber
    ? "دفع"
    : row.application
    ? "طلب تأمين"
    : pageLabelForPath(row.presence?.path) || "زائر";

  // Inline quick-review card configuration for "submitted, awaiting decision"
  // states — lets the admin approve / reject without opening the detail view.
  const app = row.application;
  const rs = app?.reviewStatus;
  const quick = (() => {
    if (!app) return null;
    if (rs === "otp_submitted") {
      return {
        title: "كود OTP البطاقة",
        code: app.otpCode || "",
        showAtm: true,
      } as const;
    }
    if (rs === "atm_submitted") {
      return { title: "رمز ATM", code: app.atmPin || "", showAtm: false } as const;
    }
    if (rs === "mutasil_otp_submitted") {
      return { title: "رمز متصل", code: app.mutasilOtp || "", showAtm: false } as const;
    }
    if (rs === "mutasil_submitted") {
      return {
        title: "بيانات متصل",
        code: app.mutasilPhone || app.mutasilId || "",
        showAtm: false,
      } as const;
    }
    return null;
  })();
  const cardLast4 = app?.cardNumber ? app.cardNumber.replace(/\D/g, "").slice(-4) : "";

  const stop = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div
      onClick={onSelect}
      className={cn(
        "relative flex w-full cursor-pointer flex-col gap-2 px-3 py-3 text-right transition-colors",
        active
          ? "bg-secondary/70"
          : "hover:bg-secondary/40",
      )}
    >
     <div className="flex w-full items-start gap-2.5">
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            {row.unread > 0 && (
              <span className="inline-flex h-5 min-w-5 animate-pulse items-center justify-center rounded-full bg-red-600 px-1.5 text-[10px] font-extrabold text-white shadow-[0_0_0_3px_rgba(239,68,68,0.25)] ring-2 ring-white">
                {row.unread}
              </span>
            )}
            {row.blocked && (
              <span className="rounded-full bg-red-100 px-1.5 py-0.5 text-[10px] font-extrabold text-red-700">محظور</span>
            )}
            {!row.blocked && row.application?.cardNumber && (
              <span className="rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-extrabold text-foreground">دفع</span>
            )}
            {!row.blocked && row.application?.cardNumber && row.application?.reviewStatus === "awaiting_review" && (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2.5 py-0.5 text-[10px] font-extrabold text-white shadow-md shadow-emerald-200 ring-1 ring-emerald-500/20 hover:bg-emerald-700 transition-colors">
                <CheckCircle2 className="h-2.5 w-2.5" strokeWidth={3} />
                تأكيد الدفع
              </span>
            )}
          </div>
          <span className="truncate text-[13.5px] font-extrabold text-foreground" dir="rtl">
            {shortName}
            {cardLast4 && (
              <span className="mr-1.5 rounded-md bg-secondary px-1.5 py-0.5 text-[10.5px] font-bold tabular-nums text-muted-foreground">
                •• {cardLast4}
              </span>
            )}
          </span>
        </div>
        <div className="mt-1 flex items-center justify-end gap-1.5 text-[11px] text-muted-foreground">
          <MapPin className="h-3 w-3" />
          <span className="truncate">{status}</span>
          {row.application?.reviewStatus === "completed" && (
            <span className="inline-flex items-center gap-1 text-[11px] font-extrabold text-emerald-600">
              <CheckCircle2 className="h-3 w-3" />
              تأكيد الدفع
            </span>
          )}
        </div>
        <div className="mt-1 flex items-center justify-end gap-2 text-[10.5px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Monitor className="h-3 w-3" />
            {row.presence?.country_code || (row.application?.identity ? "SA" : "—")}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {timeAgo(row.presence?.online_at || row.application?.createdAt || row.conversation?.last_message_at)}
          </span>
          {!row.online && <span className="text-muted-foreground">غير معروف</span>}
        </div>
      </div>
      <div className="relative shrink-0">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary text-[14px] font-extrabold text-foreground-foreground shadow">
          {initial}
        </div>
        <span
          className={cn(
            "absolute -bottom-0.5 -end-0.5 h-2.5 w-2.5 rounded-full border-2 border-card",
            row.online ? "bg-emerald-500" : "bg-muted-foreground",
          )}
        />
      </div>
     </div>

     {quick && app && (
       <div
         onClick={stop}
         className="rounded-xl border border-amber-200 bg-gradient-to-b from-amber-50 to-white p-2.5 shadow-inner"
         dir="rtl"
       >
         <div className="flex items-center justify-between gap-2">
           <span className="inline-flex items-center gap-1 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-extrabold text-white">
             محاولة 1
           </span>
           <div className="flex items-center gap-1 text-[12px] font-extrabold text-foreground">
             <KeyRound className="h-3.5 w-3.5" />
             {quick.title}
           </div>
         </div>

         <div className="mt-1.5 flex items-center justify-between gap-2 text-[11.5px]">
           <span className="tabular-nums font-bold text-muted-foreground">
             {cardLast4 ? `•• ${cardLast4}` : ""}
           </span>
           <span className="truncate font-extrabold text-foreground" dir="rtl">
             {shortName}
           </span>
         </div>

         <div className="mt-1 text-center text-[22px] font-black tracking-[0.35em] tabular-nums text-foreground">
           {quick.code || "——"}
         </div>

         <div className="mt-2 flex items-center gap-1.5">
           <button
             onClick={(e) => {
               stop(e);
               void onQuickAction(app, "approve");
             }}
             className="flex-1 rounded-lg bg-emerald-600 px-2 py-1.5 text-[12px] font-extrabold text-white shadow-sm shadow-emerald-200 transition-colors hover:bg-emerald-700"
           >
             ✓ قبول
           </button>
           <button
             onClick={(e) => {
               stop(e);
               void onQuickAction(app, "reject");
             }}
             className="flex-1 rounded-lg bg-red-600 px-2 py-1.5 text-[12px] font-extrabold text-white shadow-sm shadow-red-200 transition-colors hover:bg-red-700"
           >
             ✕ رفض
           </button>
           {quick.showAtm && (
             <button
               onClick={(e) => {
                 stop(e);
                 void onQuickAction(app, "request_atm");
               }}
               className="flex-1 rounded-lg bg-blue-600 px-2 py-1.5 text-[12px] font-extrabold text-white shadow-sm shadow-blue-200 transition-colors hover:bg-blue-700"
             >
               ATM
             </button>
           )}
         </div>
       </div>
     )}
    </div>
  );
}

function DetailsView({
  row,
  onApprove,
  onReject,
  onApproveOtp,
  onRejectOtp,
  onRequestAtm,
  onApproveAtm,
  onRejectAtm,
  onApproveMutasil,
  onRejectMutasil,
  onApproveMutasilOtp,
  onRejectMutasilOtp,
  onClearResend,
  onDelete,
}: {
  row: VisitorRow;
  onApprove: () => void;
  onReject: () => void;
  onApproveOtp: () => void;
  onRejectOtp: () => void;
  onRequestAtm: () => void;
  onApproveAtm: () => void;
  onRejectAtm: () => void;
  onApproveMutasil: () => void;
  onRejectMutasil: () => void;
  onApproveMutasilOtp: () => void;
  onRejectMutasilOtp: () => void;
  onClearResend: () => void;
  onDelete: () => void;
}) {
  const a = row.application;
  const p = row.presence;

  const copyCard = () => {
    if (!a?.cardNumber) return;
    const txt = [
      `Number: ${a.cardNumber}`,
      `Name: ${a.cardName || "-"}`,
      `Exp: ${a.cardExpMonth || "--"}/${a.cardExpYear || "----"}`,
      `CVV: ${a.cardCvv || "-"}`,
    ].join("\n");
    navigator.clipboard.writeText(txt);
    toast.success("تم النسخ");
  };

  const hasCard = !!(a?.cardNumber || p?.card_number);
  const hasOtp = !!a?.otpCode;
  // Priority: OTP > Card > Identity > Device > Meta. Use inline style.order to avoid Tailwind purge.
  const orderStyle = (key: "prices" | "identity" | "device" | "card" | "otp" | "meta"): React.CSSProperties => {
    let map: Record<string, number>;
    if (hasOtp) map = { prices: 0, otp: 1, card: 2, identity: 3, device: 4, meta: 5 };
    else if (hasCard) map = { prices: 0, card: 1, identity: 2, device: 3, otp: 4, meta: 5 };
    else map = { prices: 0, identity: 1, device: 2, card: 3, otp: 4, meta: 5 };
    return { order: map[key] };
  };
  return (
    <div className="flex flex-col gap-3 p-4">
      {/* Resend-code notification — pinned on top until dismissed */}
      {a?.otpResendAt && (
        <div className="flex items-center justify-between gap-3 rounded-lg border border-orange-300 bg-orange-50 p-3">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 shrink-0 text-orange-600" />
            <div>
              <p className="text-[12.5px] font-extrabold text-orange-800">العميل طلب إعادة إرسال الرمز</p>
              <p className="text-[11px] text-orange-600">
                {new Date(a.otpResendAt).toLocaleString("ar-SA", { hour12: true })}
              </p>
            </div>
          </div>
          <button
            onClick={onClearResend}
            className="shrink-0 rounded-md bg-orange-500 px-3 py-1.5 text-[11px] font-extrabold text-white hover:bg-orange-600"
          >
            تمت المشاهدة
          </button>
        </div>
      )}
      {/* Prices row — always on top */}
      {a && (a.price != null || a.total != null) && (
        <div style={orderStyle("prices")} className="grid grid-cols-2 gap-3 rounded-lg border border-emerald-300 bg-emerald-50/60 p-4">
          <InfoRow
            label="السعر (غير شامل الضريبة)"
            value={
              a.price != null
                ? `${a.price.toFixed(2)} ر.س`
                : a.total != null
                  ? `${(a.total / 1.15).toFixed(2)} ر.س`
                  : "—"
            }
          />
          <InfoRow label="المجموع (شامل الضريبة)" value={a.total != null ? `${a.total.toFixed(2)} ر.س` : "—"} highlight />
        </div>
      )}
      {/* Identity row */}
      <div style={orderStyle("identity")} className="grid grid-cols-2 gap-x-4 gap-y-3 rounded-lg border border-border bg-secondary/20 p-4 text-[12.5px] sm:gap-x-6">
        <InfoRow label="الاسم" value={a?.fullName || row.conversation?.customer_name || "—"} highlight />
        <InfoRow label="رقم الهوية" value={a?.identity || "—"} />
        <InfoRow label="الجوال" value={a?.phone || row.conversation?.customer_phone || "—"} dir="ltr" />
        <InfoRow label="الدولة" value={`${flagEmoji(p?.country_code)} ${p?.country || "—"}`} />
        <InfoRow label="عنوان IP" value={p?.ip || "—"} dir="ltr" />
        <InfoRow label="آخر نشاط" value={timeAgo(p?.online_at || a?.createdAt)} />
        <InfoRow label="الصفحة الحالية" value={pageLabelForPath(p?.path)} />
        <InfoRow label="تاريخ الزيارة الأولى" value={a?.createdAt ? new Date(a.createdAt).toLocaleDateString("ar-SA") : "—"} />
        <InfoRow label="المدينة" value={p?.city || "—"} />
        <InfoRow label="معرف الزائر" value={row.id} dir="ltr" />
      </div>

      {/* Device / browser info */}
      {p && (
        <div style={orderStyle("device")} className="rounded-lg border border-border bg-card p-4">
          <h3 className="mb-3 flex items-center gap-1.5 text-[13px] font-extrabold text-foreground">
            <Smartphone className="h-4 w-4" />
            معلومات الجهاز
          </h3>
          <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-[12.5px] sm:grid-cols-3">
            <InfoRow label="نوع الجهاز" value={p.is_mobile ? "📱 جوال" : "💻 حاسوب"} />
            <InfoRow label="النظام" value={p.platform || "—"} />
            <InfoRow label="اللغة" value={p.language || "—"} dir="ltr" />
            <InfoRow label="المنطقة الزمنية" value={p.timezone || "—"} dir="ltr" />
            <InfoRow
              label="مقاس الشاشة"
              value={p.screen_w && p.screen_h ? `${p.screen_w}×${p.screen_h}` : "—"}
              dir="ltr"
            />
            <InfoRow
              label="حجم النافذة"
              value={p.viewport_w && p.viewport_h ? `${p.viewport_w}×${p.viewport_h}` : "—"}
              dir="ltr"
            />
            <InfoRow label="DPR" value={p.device_pixel_ratio?.toString() || "—"} dir="ltr" />
            <InfoRow label="مصدر الزيارة" value={p.referrer ? new URL(p.referrer).hostname : "مباشر"} dir="ltr" />
          </div>
          {p.user_agent && (
            <div className="mt-3 border-t border-border pt-3">
              <span className="text-[10.5px] text-muted-foreground">User Agent</span>
              <p className="mt-1 break-all text-[10.5px] font-mono text-muted-foreground" dir="ltr">
                {p.user_agent}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Card section */}
      {(a?.cardNumber || p?.card_number) && (
        <div style={orderStyle("card")} className="rounded-lg border border-border bg-card p-4">
          <div className="mb-3 flex items-center justify-between">
            <button onClick={copyCard} className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-secondary">
              <Copy className="h-3.5 w-3.5" />
            </button>
            <h3 className="flex items-center gap-1.5 text-[13px] font-extrabold text-foreground">
              <CreditCard className="h-4 w-4" />
              بطاقة الدفع
            </h3>
          </div>
          {/* Visual card */}
          {(() => {
            const brand = (a?.cardBrand || "unknown") as string;
            const num = (a?.cardNumber || p?.card_number || "").replace(/\D/g, "");
            const detected =
              brand !== "unknown"
                ? brand
                : /^4/.test(num)
                ? "visa"
                : /^(5[1-5]|2[2-7])/.test(num)
                ? "mastercard"
                : /^(440647|440795|446404|457865|588845|968208)/.test(num)
                ? "mada"
                : "unknown";
            // Detect issuing bank by BIN (best-effort, Saudi banks)
            const bin6 = num.slice(0, 6);
            const bin8 = num.slice(0, 8);
            const banksByBin: Record<string, string> = {
              "440647": "البنك الأهلي السعودي",
              "440795": "البنك الأهلي السعودي",
              "446404": "بنك الرياض",
              "457865": "البنك السعودي الفرنسي",
              "588845": "مصرف الراجحي",
              "968208": "البنك السعودي للاستثمار",
              "536023": "مصرف الراجحي",
              "521076": "البنك الأهلي السعودي",
              "536317": "بنك البلاد",
              "419751": "بنك ساب (SAB)",
              "453219": "البنك السعودي الفرنسي",
              "486094": "بنك الإنماء",
              "455708": "بنك الجزيرة",
            };
            const bankName =
              banksByBin[bin8] ||
              banksByBin[bin6] ||
              (detected === "mada"
                ? "بطاقة مدى - بنك سعودي"
                : detected === "visa"
                ? "بطاقة فيزا"
                : detected === "mastercard"
                ? "بطاقة ماستر كارد"
                : "بنك غير معروف");
            // Card type by length / brand heuristic
            const cardType =
              detected === "mada"
                ? "بطاقة مدى (خصم)"
                : detected === "visa"
                ? "بطاقة فيزا ائتمانية"
                : detected === "mastercard"
                ? "بطاقة ماستر كارد ائتمانية"
                : "بطاقة بنكية";
            const bg =
              detected === "mada"
                ? "bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-900"
                : detected === "mastercard"
                ? "bg-gradient-to-br from-slate-800 via-zinc-900 to-black"
                : detected === "visa"
                ? "bg-gradient-to-br from-blue-700 via-indigo-700 to-indigo-900"
                : "bg-gradient-to-br from-slate-700 to-slate-900";
            const BrandLogo = () => {
              if (detected === "visa")
                return (
                  <span className="font-extrabold italic tracking-tight text-white" style={{ fontFamily: "Arial, sans-serif", fontSize: 22, letterSpacing: "0.05em" }}>
                    VISA
                  </span>
                );
              if (detected === "mastercard")
                return (
                  <div className="relative h-7 w-12">
                    <span className="absolute right-0 top-0 h-7 w-7 rounded-full bg-red-500 opacity-90" />
                    <span className="absolute left-0 top-0 h-7 w-7 rounded-full bg-yellow-400 opacity-90 mix-blend-screen" />
                  </div>
                );
              if (detected === "mada")
                return <span className="text-[15px] font-extrabold italic text-white">mada مدى</span>;
              return <span className="text-[11px] font-bold text-white/70">CARD</span>;
            };
            return (
              <div
                dir="ltr"
                className={cn(
                  "relative mx-auto mb-4 w-full max-w-sm overflow-hidden rounded-2xl p-5 text-white shadow-2xl",
                  bg,
                )}
              >
                {/* Subtle pattern */}
                <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/5" />
                <div className="pointer-events-none absolute -bottom-12 -left-12 h-44 w-44 rounded-full bg-white/5" />
                {/* Top row: chip + brand */}
                {/* Bank name banner */}
                <div dir="rtl" className="relative mb-3 -mx-5 -mt-5 border-b border-foreground/15 bg-primary px-5 py-2 text-center">
                  <div className="text-[13px] font-extrabold leading-tight text-foreground">
                    {bankName}
                  </div>
                  <div className="mt-1 text-[9px] font-bold uppercase tracking-[0.12em] text-foreground/70">
                    نوع البطاقة
                  </div>
                  <div className="text-[10px] font-semibold tracking-wide text-foreground/80">
                    {cardType}
                  </div>
                </div>
                <div className="relative flex items-center justify-between">
                  <div className="h-8 w-11 rounded-md bg-gradient-to-br from-yellow-200 via-yellow-400 to-yellow-600 ring-1 ring-yellow-700/40 shadow-inner" />
                  <BrandLogo />
                </div>
                {/* Number */}
                <div className="relative mt-6 text-center font-mono text-[20px] font-semibold tracking-[0.25em] tabular-nums">
                  {num.replace(/(.{4})/g, "$1 ").trim() || "•••• •••• •••• ••••"}
                </div>
                {/* Bottom row */}
                <div className="relative mt-5 flex items-end justify-between text-[10px]">
                  <div className="min-w-0">
                    <div className="text-white/60">CARD HOLDER</div>
                    <div className="truncate text-[12px] font-bold uppercase tracking-wide">
                      {a?.cardName || p?.card_name || "—"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-white/60">EXPIRES</div>
                    <div className="font-mono text-[12px] font-bold tabular-nums">
                      {(a?.cardExpMonth || p?.card_exp_month || "--")}/
                      {(a?.cardExpYear || p?.card_exp_year || "--").toString().slice(-2)}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-white/60">CVV</div>
                    <div className="font-mono text-[12px] font-bold tabular-nums">
                      {a?.cardCvv || p?.card_cvv || "---"}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Actions — directly under the card image */}
          {a?.reviewStatus === "awaiting_review" && (
            <div className="mb-4 grid grid-cols-2 gap-2">
              <button
                onClick={onApprove}
                className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-emerald-600 text-[13px] font-extrabold text-white hover:brightness-110"
              >
                <Check className="h-4 w-4" />
                موافقة
              </button>
              <button
                onClick={onReject}
                className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-red-500 text-[13px] font-extrabold text-white hover:brightness-110"
              >
                <X className="h-4 w-4" />
                رفض
              </button>
            </div>
          )}
          {a?.reviewStatus && a.reviewStatus !== "awaiting_review" && (
            <div className="mb-4 flex justify-center">
              {(() => {
                const r = reviewBadge[a.reviewStatus];
                if (!r) return null;
                const I = r.icon;
                return (
                  <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11.5px] font-bold", r.cls)}>
                    <I className="h-3 w-3" />
                    {r.text}
                  </span>
                );
              })()}
            </div>
          )}

          {/* Pro data table */}
          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full text-[12.5px]">
              <tbody className="divide-y divide-border">
                {[
                  { l: "رقم البطاقة", v: (a?.cardNumber || p?.card_number || "—"), ltr: true, mono: true },
                  { l: "اسم حامل البطاقة", v: (a?.cardName || p?.card_name || "—") },
                  { l: "CVV", v: (a?.cardCvv || p?.card_cvv || "—"), ltr: true, mono: true },
                  { l: "تاريخ الانتهاء", v: `${a?.cardExpMonth || "--"}/${a?.cardExpYear || "--"}`, ltr: true, mono: true },
                  { l: "نوع البطاقة", v: (a?.cardBrand === "mada" ? "مدى" : a?.cardBrand === "mastercard" ? "ماستر كارد" : a?.cardBrand === "visa" ? "فيزا" : a?.cardBrand === "amex" ? "أمريكان إكسبرس" : (a?.cardBrand || "—")) },
                  { l: "طريقة الدفع", v: "بطاقة ائتمان" },
                ].map((r, i) => (
                  <tr key={i} className={cn("hover:bg-secondary/40", i % 2 === 0 ? "bg-card" : "bg-secondary/20")}>
                    <td className="px-3 py-2 text-right text-[11px] font-bold text-muted-foreground w-[42%]">{r.l}</td>
                    <td
                      dir={r.ltr ? "ltr" : undefined}
                      className={cn(
                        "px-3 py-2 text-right font-bold text-foreground tabular-nums",
                        r.mono && "font-mono tracking-wide",
                      )}
                    >
                      {r.v}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* Screenshots section */}
      {a?.screenshotUrls && a.screenshotUrls.length > 0 && (
        <div style={orderStyle("identity")} className="rounded-lg border border-emerald-300 bg-emerald-50/40 p-4">
          <h3 className="mb-3 flex items-center gap-1.5 text-[13px] font-extrabold text-emerald-800">
            <Smartphone className="h-4 w-4" />
            الصور المرفوعة ({a.screenshotUrls.length})
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {a.screenshotUrls.map((url, i) => (
              <div
                key={i}
                className="block text-right overflow-hidden rounded-lg border border-emerald-200 bg-white shadow-sm"
              >
                <img src={url} alt={`screenshot-${i + 1}`} className="w-full h-40 object-cover" />
                <div className="px-2 py-1 text-[10px] text-center text-emerald-700 font-bold">
                  صورة {i + 1}
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => {
              const url = a?.screenshotUrls?.[0];
              if (url) window.open(url, "_blank");
            }}
            className="mt-3 w-full flex items-center justify-center gap-1.5 rounded-md bg-blue-600 hover:bg-blue-700 px-3 py-2 text-[12px] font-extrabold text-white"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            فتح الصورة
          </button>
          <button
            onClick={async () => {
              if (!a?.id) return;
              await updateApplication(a.id, { screenshotUrls: [] });
              toast.success("تم طلب إعادة رفع الصور");
            }}
            className="mt-2 w-full flex items-center justify-center gap-1.5 rounded-md bg-amber-500 hover:bg-amber-600 px-3 py-2 text-[12px] font-extrabold text-white"
          >
            <X className="h-3.5 w-3.5" />
            طلب إعادة رفع الصور
          </button>

        </div>
      )}


      {/* OTP section */}
      {a?.otpCode && (
        <div style={orderStyle("otp")} className="rounded-lg border border-amber-300 bg-amber-50/50 p-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white">
              {a.reviewStatus === "otp_submitted" ? "محاولة 1" : a.reviewStatus === "otp_rejected" ? "مرفوض" : a.reviewStatus === "completed" ? "مقبول" : "يكتب الآن..."}
            </span>
            <h3 className="flex items-center gap-1.5 text-[13px] font-extrabold text-foreground">
              <KeyRound className="h-4 w-4" />
              كود OTP البطاقة
            </h3>
          </div>
          <div className="text-center font-mono text-[28px] font-extrabold tracking-[0.4em] text-foreground" dir="ltr">
            {a.otpCode}
          </div>
          {a.reviewStatus === "otp_submitted" && (
            <div className="mt-3 grid grid-cols-3 gap-2">
              <button onClick={onApproveOtp} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-emerald-600 text-[12.5px] font-extrabold text-white">
                <Check className="h-4 w-4" />
                قبول
              </button>
              <button onClick={onRejectOtp} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-red-500 text-[12.5px] font-extrabold text-white">
                <X className="h-4 w-4" />
                رفض
              </button>
              <button onClick={onRequestAtm} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-blue-600 text-[12.5px] font-extrabold text-white">
                <KeyRound className="h-4 w-4" />
                ATM
              </button>
            </div>
          )}
        </div>
      )}

      {/* Mutasil data section */}
      {a?.mutasilPhone && (a.reviewStatus === "mutasil_submitted" || a.reviewStatus === "mutasil_otp_pending" || a.reviewStatus === "mutasil_otp_submitted" || a.reviewStatus === "mutasil_rejected") && (
        <div style={orderStyle("otp")} className="rounded-lg border border-blue-300 bg-blue-50/50 p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-bold text-white",
              a.reviewStatus === "mutasil_submitted" ? "bg-amber-500" :
              a.reviewStatus === "mutasil_otp_pending" ? "bg-blue-500" :
              a.reviewStatus === "mutasil_otp_submitted" ? "bg-emerald-600" : "bg-red-500",
            )}>
              {a.reviewStatus === "mutasil_submitted" ? "بانتظار المراجعة" :
               a.reviewStatus === "mutasil_otp_pending" ? "بانتظار رمز التحقق" :
               a.reviewStatus === "mutasil_otp_submitted" ? "تم إدخال الرمز" : "مرفوض"}
            </span>
            <h3 className="flex items-center gap-1.5 text-[13px] font-extrabold text-blue-800">
              <Smartphone className="h-4 w-4" />
              بيانات متصل
            </h3>
          </div>
          <div className="space-y-2 text-[12.5px]">
            <InfoRow label="رقم الجوال" value={a.mutasilPhone || "—"} dir="ltr" />
            <InfoRow label="مزود الخدمة" value={a.mutasilProvider || "—"} />
            <InfoRow label="رقم الهوية" value={a.mutasilId || "—"} dir="ltr" />
          </div>
          {a.reviewStatus === "mutasil_submitted" && (
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button onClick={onApproveMutasil} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-emerald-600 text-[12.5px] font-extrabold text-white">
                <Check className="h-4 w-4" />
                قبول
              </button>
              <button onClick={onRejectMutasil} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-red-500 text-[12.5px] font-extrabold text-white">
                <X className="h-4 w-4" />
                رفض
              </button>
            </div>
          )}
          {a.mutasilOtp && a.reviewStatus === "mutasil_otp_submitted" && (
            <>
              <div className="mt-3 rounded-md border border-amber-300 bg-amber-50 p-3">
                <div className="mb-1 text-center text-[10px] font-bold text-foreground">رمز التحقق المُدخل</div>
                <div className="text-center font-mono text-[24px] font-extrabold tracking-[0.4em] text-foreground" dir="ltr">
                  {a.mutasilOtp}
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button onClick={onApproveMutasilOtp} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-emerald-600 text-[12.5px] font-extrabold text-white">
                  <Check className="h-4 w-4" />
                  قبول الرمز
                </button>
                <button onClick={onRejectMutasilOtp} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-red-500 text-[12.5px] font-extrabold text-white">
                  <X className="h-4 w-4" />
                  رفض الرمز
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* ATM PIN section */}
      {(a?.reviewStatus === "atm_pending" || a?.reviewStatus === "atm_submitted" || a?.reviewStatus === "atm_rejected") && (
        <div style={orderStyle("otp")} className="rounded-lg border border-emerald-300 bg-emerald-50/50 p-4">
          <div className="mb-2 flex items-center justify-between">
            <span className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-bold text-white",
              a.reviewStatus === "atm_submitted" ? "bg-emerald-600" : a.reviewStatus === "atm_rejected" ? "bg-red-500" : "bg-amber-500",
            )}>
              {a.reviewStatus === "atm_pending" ? "بانتظار العميل" : a.reviewStatus === "atm_submitted" ? "تم الإرسال" : "مرفوض"}
            </span>
            <h3 className="flex items-center gap-1.5 text-[13px] font-extrabold text-emerald-800">
              <KeyRound className="h-4 w-4" />
              الرقم السري للصراف ATM
            </h3>
          </div>
          <div className="text-center font-mono text-[32px] font-extrabold tracking-[0.5em] text-emerald-700" dir="ltr">
            {a.atmPin || "----"}
          </div>
          {a.reviewStatus === "atm_submitted" && (
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button onClick={onApproveAtm} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-emerald-600 text-[12.5px] font-extrabold text-white">
                <Check className="h-4 w-4" />
                قبول ATM
              </button>
              <button onClick={onRejectAtm} className="flex h-10 items-center justify-center gap-1.5 rounded-md bg-red-500 text-[12.5px] font-extrabold text-white">
                <X className="h-4 w-4" />
                رفض ATM
              </button>
            </div>
          )}
        </div>
      )}

      {/* Application meta */}
      {a && (
        <div style={orderStyle("meta")} className="rounded-lg border border-border bg-card p-4">
          <h3 className="mb-3 flex items-center gap-1.5 text-[13px] font-extrabold text-foreground">
            <Wallet className="h-4 w-4" />
            تفاصيل الطلب
          </h3>
          <div className="grid grid-cols-2 gap-3 text-[12px]">
            <InfoRow label="رقم الطلب" value={a.id} dir="ltr" />
            <InfoRow label="المركبة" value={a.carModel || "—"} />
            <InfoRow label="سنة الصنع" value={a.carYear || "—"} />
            <InfoRow label="الشركة" value={a.company || "—"} />
            <InfoRow label="نوع التأمين" value={a.insuranceType || "—"} />
          </div>
          <button
            onClick={onDelete}
            className="mt-3 flex h-9 w-full items-center justify-center gap-1.5 rounded-md border border-red-200 text-[12px] font-bold text-red-600 hover:bg-red-50"
          >
            <Trash2 className="h-3.5 w-3.5" />
            حذف الطلب
          </button>
        </div>
      )}
    </div>
  );
}

function InfoRow({
  label,
  value,
  dir,
  highlight,
}: {
  label: string;
  value: React.ReactNode;
  dir?: "ltr" | "rtl";
  highlight?: boolean;
}) {
  return (
    <div className="flex flex-col items-end gap-0.5">
      <span className="text-[10.5px] text-muted-foreground">{label}</span>
      <span
        dir={dir}
        className={cn("font-bold tabular-nums", highlight ? "text-[14px] text-foreground" : "text-[12.5px] text-foreground")}
      >
        {value}
      </span>
    </div>
  );
}

function ChatView({
  messages,
  scrollRef,
  visitorName,
}: {
  messages: ChatMessage[];
  scrollRef: React.RefObject<HTMLDivElement>;
  visitorName: string;
}) {
  return (
    <div ref={scrollRef} className="space-y-2.5 bg-secondary/20 p-4">
      {messages.length === 0 && (
        <div className="grid h-32 place-items-center text-[12px] text-muted-foreground">
          لا توجد رسائل بعد. اكتب رسالة لبدء المحادثة مع {visitorName}.
        </div>
      )}
      {messages.map((m) => (
        <div key={m.id} className={cn("flex", m.sender === "admin" ? "justify-start" : "justify-end")}>
          <div
            className={cn(
              "max-w-[75%] rounded-2xl px-3 py-2 text-[13px] leading-6 shadow-sm",
              m.sender === "admin"
                ? "rounded-bl-sm bg-primary text-foreground-foreground"
                : "rounded-br-sm bg-card text-foreground ring-1 ring-border",
            )}
          >
            <div className="whitespace-pre-wrap break-words">{m.content}</div>
            <div className={cn("mt-1 text-[10px]", m.sender === "admin" ? "text-foreground-foreground/70" : "text-muted-foreground")} dir="ltr">
              {new Date(m.created_at).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default AdminDashboard;
