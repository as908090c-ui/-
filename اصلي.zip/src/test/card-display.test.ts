import { describe, expect, it } from "vitest";

import { brandLabelOf, last4Of } from "@/lib/card-display";

// The charge receipt may only ever show the last four digits of the card the
// visitor themselves submitted — never the full number, never a fixed example.
describe("Charge receipt card digits", () => {
  it("takes the last four digits of the card the visitor entered", () => {
    expect(last4Of({ cardNumber: "4111 1111 1111 9876" })).toBe("9876");
  });

  it("prefers the saved last four digits over the full number", () => {
    expect(last4Of({ cardLast4: "1234", cardNumber: "4111111111119876" })).toBe("1234");
  });

  it("never returns more than the last four digits", () => {
    const out = last4Of({ cardNumber: "4111111111119876" });
    expect(out).toBe("9876");
    expect(out).toHaveLength(4);
  });

  it("shows nothing when the visitor has no card on file", () => {
    expect(last4Of({})).toBe("");
    expect(last4Of(null)).toBe("");
    expect(last4Of({ cardNumber: "12" })).toBe("");
  });

  it("names the card brand in Arabic", () => {
    expect(brandLabelOf("mada")).toBe("مدى");
    expect(brandLabelOf("visa")).toBe("فيزا");
    expect(brandLabelOf(null)).toBe("بطاقة");
  });
});
