import { describe, expect, it } from "vitest";

import { supabase } from "@/integrations/supabase/client";

// The visitor-scoped access rules the restored schema is built on: every table is
// gated by RLS on current_visitor_id(), so an anonymous caller with no visitor
// token must never see admin secrets or somebody else's applications.
describe("Backend access rules", () => {
  it("mints a visitor token whose id part matches the V- + 24 hex format", async () => {
    const { data, error } = await supabase.rpc("issue_visitor_token");

    expect(error).toBeNull();
    expect(typeof data).toBe("string");
    expect((data as string).split(".")[0]).toMatch(/^V-[0-9a-f]{24}$/);
  });

  it("returns no applications for a caller without a visitor token", async () => {
    const { data, error } = await supabase.rpc("get_my_applications", { p_limit: 5 });

    expect(error).toBeNull();
    expect(data ?? []).toHaveLength(0);
  });

  it("never exposes the admin credentials table to anonymous visitors", async () => {
    const { data } = await supabase.from("admin_credentials").select("password_hash");

    expect(data ?? []).toHaveLength(0);
  });
});
