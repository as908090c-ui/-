import { fireEvent, render } from "@testing-library/react";
import { MemoryRouter, useNavigate } from "react-router-dom";
import { describe, expect, it, vi } from "vitest";
import PageScrollReset from "@/components/site/PageScrollReset";

function Navigation() {
  const navigate = useNavigate();
  return <button onClick={() => navigate("/quote/checkout")}>Next</button>;
}

describe("Page scroll position", () => {
  it("opens the initial page at the top", () => {
    const scroll = vi.spyOn(window, "scrollTo");
    render(<MemoryRouter><PageScrollReset /></MemoryRouter>);
    expect(scroll).toHaveBeenCalledWith({ top: 0, left: 0, behavior: "instant" });
    scroll.mockRestore();
  });

  it("starts the next page at the top rather than retaining the previous scroll", () => {
    const scroll = vi.spyOn(window, "scrollTo");
    const view = render(<MemoryRouter initialEntries={["/quote/offers"]}><PageScrollReset /><Navigation /></MemoryRouter>);
    scroll.mockClear();
    fireEvent.click(view.getByRole("button", { name: "Next" }));
    expect(scroll).toHaveBeenCalledWith({ top: 0, left: 0, behavior: "instant" });
    scroll.mockRestore();
  });
});