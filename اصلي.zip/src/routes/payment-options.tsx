import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import mada from "@/assets/payments/mada.png";
import visa from "@/assets/payments/visa.svg";
import mastercard from "@/assets/payments/mastercard.svg";
import sab from "@/assets/payments/sab.jpeg";
import alinma from "@/assets/payments/alinma.png";
import fransi from "@/assets/payments/fransi.png";
import riyad from "@/assets/payments/riyad.png";
import tiqmo from "@/assets/payments/tiqmo.png";
import stcBank from "@/assets/payments/stc-bank.jpeg";
import d360 from "@/assets/payments/d360.jpeg";
import barq from "@/assets/payments/barq.jpeg";
import meem from "@/assets/payments/meem.png";
import albilad from "@/assets/payments/albilad.jpeg";
import anb from "@/assets/payments/anb.png";
import urpay from "@/assets/payments/urpay.png";
import snb from "@/assets/snb-logo.png";
import visionBank from "@/assets/payments/vision-bank.svg";
import saib from "@/assets/payments/saib.png";
import mobilyPay from "@/assets/payments/mobily-pay.png";
import figein from "@/assets/payments/figein.jpeg";

export const Route = createFileRoute("/payment-options")({
  head: () => ({
    meta: [
      { title: "نموذج خيارات الدفع | بي كير" },
      { name: "description", content: "نموذج مستقل لعرض البنوك وطرق الدفع المتاحة دون إدخال بيانات بطاقة أو تنفيذ دفعات." },
      { property: "og:title", content: "نموذج خيارات الدفع | بي كير" },
      { property: "og:description", content: "عرض البنوك وطرق الدفع المتاحة دون جمع أي بيانات." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PaymentOptions,
});

const options = [
  { id: "mada", label: "مدى" },
  { id: "visa-mastercard", label: "فيزا - ماستر كارد" },
  { id: "amex", label: "أمريكان إكسبرس" },
];

const banks = [
  { src: mada, name: "مدى" },
  { src: sab, name: "SAB" },
  { src: alinma, name: "مصرف الإنماء" },
  { src: fransi, name: "البنك السعودي الفرنسي" },
  { src: riyad, name: "بنك الرياض" },
  { src: tiqmo, name: "Tiqmo" },
  { src: stcBank, name: "STC Bank" },
  { src: d360, name: "D360" },
  { src: barq, name: "بارق" },
  { src: meem, name: "بنك ميم" },
  { src: albilad, name: "بنك البلاد" },
  { src: anb, name: "البنك العربي الوطني" },
  { src: urpay, name: "urpay" },
  { src: snb, name: "البنك الأهلي السعودي" },
  { src: visionBank, name: "فيجن بنك" },
  { src: saib, name: "البنك السعودي للاستثمار" },
  { src: mobilyPay, name: "موبايلي باي" },
  { src: figein, name: "فيجين" },
];

function PaymentOptions() {
  const [selected, setSelected] = useState("");

  return (
    <main dir="rtl" className="min-h-screen w-full bg-background px-4 py-10 sm:px-8 sm:py-14">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-10">
        <section aria-labelledby="banks-heading">
          <h2 id="banks-heading" className="mb-6 text-center text-lg font-black uppercase tracking-[0.15em] text-brand-blue sm:text-2xl">
            البنوك المتاحة
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
            {banks.map((bank) => (
              <span
                key={bank.name}
                title={bank.name}
                className="flex h-24 items-center justify-center rounded-2xl border border-input bg-card px-3 sm:h-28"
              >
                <img src={bank.src} alt={bank.name} className="h-16 w-full max-w-full object-contain sm:h-20" loading="lazy" />
              </span>
            ))}
          </div>
        </section>

        <section aria-labelledby="payment-heading">
          <h1 id="payment-heading" className="mb-6 text-2xl font-extrabold text-brand-blue sm:text-3xl">اختر طريقة الدفع</h1>
          <RadioGroup value={selected} onValueChange={setSelected} dir="rtl" aria-labelledby="payment-heading" className="gap-4">
            {options.map((option) => (
              <label
                key={option.id}
                htmlFor={option.id}
                className="flex min-h-28 cursor-pointer items-center gap-4 rounded-lg border border-input bg-card px-5 py-5 transition-colors has-[[data-state=checked]]:border-brand-blue has-[[data-state=checked]]:bg-brand-blue/5 sm:gap-6 sm:px-7"
              >
                <RadioGroupItem id={option.id} value={option.id} aria-label={option.label} className="h-6 w-6 shrink-0 border-brand-blue text-brand-blue [&_svg]:h-3.5 [&_svg]:w-3.5 [&_svg]:fill-brand-blue" />
                <span className="flex-1 text-base font-bold text-muted-foreground sm:text-xl">{option.label}</span>
                <span className="flex w-24 shrink-0 items-center justify-end gap-2" dir="ltr">
                  {option.id === "mada" && <img src={mada} alt="mada" className="max-h-10 w-24 object-contain" />}
                  {option.id === "visa-mastercard" && (
                    <>
                      <img src={visa} alt="Visa" className="h-7 w-14 object-contain" />
                      <img src={mastercard} alt="Mastercard" className="h-7 w-8 object-contain" />
                    </>
                  )}
                  {option.id === "amex" && (
                    <span className="rounded-sm bg-brand-blue px-2 py-2 text-center text-xs font-extrabold leading-tight text-primary-foreground">
                      AMERICAN<br />EXPRESS
                    </span>
                  )}
                </span>
              </label>
            ))}
          </RadioGroup>
        </section>
      </div>
    </main>
  );
}
