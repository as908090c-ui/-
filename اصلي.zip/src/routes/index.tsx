import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "بي كير | مقارنة تأمين السيارات في السعودية" },
      {
        name: "description",
        content: "قارن عروض تأمين السيارات في السعودية واختر العرض الأنسب بإصدار إلكتروني سريع.",
      },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "بي كير | مقارنة تأمين السيارات في السعودية" },
      {
        property: "og:description",
        content: "قارن عروض تأمين السيارات في السعودية واختر العرض الأنسب بإصدار إلكتروني سريع.",
      },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndexRoute,
});

function IndexRoute() {
  const [App, setApp] = useState<React.ComponentType | null>(null);
  useEffect(() => {
    import("../App").then((m) => setApp(() => m.default));
  }, []);
  if (!App) return null;
  return <App />;
}
