import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/$")({
  head: () => ({ meta: [
    { title: "خدمات التأمين | بي كير" },
    { name: "description", content: "تابع خطوات مقارنة عروض تأمين السيارات عبر بي كير." },
    { property: "og:title", content: "خدمات التأمين | بي كير" },
    { property: "og:description", content: "خطوات مقارنة عروض تأمين السيارات عبر بي كير." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: AppRoute,
});

function AppRoute() {
  const [App, setApp] = useState<React.ComponentType | null>(null);
  useEffect(() => {
    import("../App").then((m) => setApp(() => m.default));
  }, []);
  if (!App) return null;
  return <App />;
}
