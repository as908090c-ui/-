import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/ASas1010/login")({
  head: () => ({ meta: [
    { title: "دخول الموظفين | بي كير" },
    { name: "description", content: "تسجيل دخول الموظفين المخولين إلى إدارة بي كير." },
    { property: "og:title", content: "دخول الموظفين | بي كير" },
    { property: "og:description", content: "تسجيل دخول الموظفين إلى بي كير." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: AdminLoginAppRoute,
});

function AdminLoginAppRoute() {
  const [App, setApp] = useState<React.ComponentType | null>(null);

  useEffect(() => {
    import("../App").then((m) => setApp(() => m.default));
  }, []);

  if (!App) return null;
  return <App />;
}
