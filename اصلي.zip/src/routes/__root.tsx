import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "بي كير — المنصة الأذكى لمقارنة عروض تأمين السيارات في السعودية" },
      { name: "description", content: "قارن عروض أكثر من 20 شركة تأمين سيارات في السعودية، احصل على أرخص تأمين بإصدار فوري وربط مباشر بنجم." },
      { name: "author", content: "Bcare" },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "بي كير — المنصة الأذكى لمقارنة عروض تأمين السيارات في السعودية" },
      { property: "og:description", content: "قارن عروض أكثر من 20 شركة تأمين سيارات في السعودية، احصل على أرخص تأمين بإصدار فوري وربط مباشر بنجم." },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "بي كير — المنصة الأذكى لمقارنة عروض تأمين السيارات في السعودية" },
      { name: "twitter:description", content: "قارن عروض أكثر من 20 شركة تأمين سيارات في السعودية، احصل على أرخص تأمين بإصدار فوري وربط مباشر بنجم." },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
