import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/ASas1010")({
  head: () => ({ meta: [
    { title: "الإدارة | بي كير" },
    { name: "description", content: "مساحة إدارة بي كير المخصصة للموظفين المخولين." },
    { property: "og:title", content: "الإدارة | بي كير" },
    { property: "og:description", content: "مساحة إدارة بي كير." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: AdminAppRoute,
});

function AdminAppRoute() {
  const [App, setApp] = useState<React.ComponentType | null>(null);

  useEffect(() => {
    import("../App").then((m) => setApp(() => m.default));
  }, []);

  if (!App) return null;
  return <App />;
}
