import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Check, CreditCard, Landmark, ShieldCheck, Smartphone, Wallet } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import mada from "@/assets/payments/mada.png";
import visa from "@/assets/payments/visa.svg";
import mastercard from "@/assets/payments/mastercard.svg";
import applePay from "@/assets/apple-pay.svg";
import alinma from "@/assets/payments/alinma.png";
import riyad from "@/assets/payments/riyad.png";
import anb from "@/assets/payments/anb.png";
import albilad from "@/assets/payments/albilad.jpeg";
import stcBank from "@/assets/payments/stc-bank.jpeg";
import urpay from "@/assets/payments/urpay.png";

export const Route = createFileRoute("/payment-models")({
  head: () => ({
    meta: [
      { title: "خمسة نماذج لواجهة الدفع | بي كير" },
      {
        name: "description",
        content:
          "خمسة تصاميم مختلفة لصفحة اختيار طريقة الدفع لعرضها والاختيار بينها، بدون إدخال أي بيانات بطاقة.",
      },
      { property: "og:title", content: "خمسة نماذج لواجهة الدفع | بي كير" },
      {
        property: "og:description",
        content: "قارن بين خمسة تصاميم لصفحة الدفع واختر المناسب.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PaymentModels,
});

const methods = [
  { id: "mada", label: "مدى", logo: mada, icon: CreditCard },
  { id: "visa", label: "فيزا", logo: visa, icon: CreditCard },
  { id: "mastercard", label: "ماستر كارد", logo: mastercard, icon: CreditCard },
  { id: "apple-pay", label: "Apple Pay", logo: applePay, icon: Smartphone },
];

const wallets = [
  { id: "stc", label: "STC Bank", logo: stcBank },
  { id: "urpay", label: "urpay", logo: urpay },
];

const bankList = [
  { id: "alinma", label: "مصرف الإنماء", logo: alinma },
  { id: "riyad", label: "بنك الرياض", logo: riyad },
  { id: "anb", label: "البنك العربي الوطني", logo: anb },
  { id: "albilad", label: "بنك البلاد", logo: albilad },
];

const models = [
  { id: 1, name: "النموذج الأول", hint: "قائمة كلاسيكية" },
  { id: 2, name: "النموذج الثاني", hint: "بطاقات مربعة" },
  { id: 3, name: "النموذج الثالث", hint: "شريط مضغوط" },
  { id: 4, name: "النموذج الرابع", hint: "ملخص الطلب" },
  { id: 5, name: "النموذج الخامس", hint: "أقسام مفصّلة" },
];

function Shell({ children, title }: { children: React.ReactNode; title: string }) {
  return (
    <section className="rounded-3xl border border-input bg-card p-5 sm:p-8">
      <h2 className="mb-6 text-xl font-extrabold text-brand-blue sm:text-2xl">{title}</h2>
      {children}
    </section>
  );
}

function ModelOne() {
  const [value, setValue] = useState("mada");
  return (
    <Shell title="اختر طريقة الدفع">
      <RadioGroup value={value} onValueChange={setValue} dir="rtl" className="gap-3">
        {methods.map((m) => (
          <label
            key={m.id}
            htmlFor={`m1-${m.id}`}
            className="flex min-h-20 cursor-pointer items-center gap-4 rounded-xl border border-input bg-background px-5 transition-colors has-[[data-state=checked]]:border-brand-blue has-[[data-state=checked]]:bg-brand-blue/5"
          >
            <RadioGroupItem
              id={`m1-${m.id}`}
              value={m.id}
              aria-label={m.label}
              className="h-5 w-5 border-brand-blue text-brand-blue"
            />
            <span className="flex-1 text-base font-bold text-foreground">{m.label}</span>
            <img src={m.logo} alt={m.label} className="h-8 w-16 object-contain" />
          </label>
        ))}
      </RadioGroup>
      <button type="button" className="btn-pay mt-6 h-12 w-full text-base">
        متابعة الدفع
      </button>
    </Shell>
  );
}

function ModelTwo() {
  const [value, setValue] = useState("visa");
  return (
    <Shell title="طرق الدفع المتاحة">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {methods.map((m) => {
          const active = value === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setValue(m.id)}
              aria-pressed={active}
              className={`relative flex h-32 flex-col items-center justify-center gap-3 rounded-2xl border-2 bg-background transition-all ${
                active
                  ? "border-brand-blue bg-brand-blue/5 shadow-lg"
                  : "border-input hover:border-brand-blue/40"
              }`}
            >
              {active && (
                <span className="absolute left-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-brand-blue">
                  <Check className="h-4 w-4 text-primary-foreground" />
                </span>
              )}
              <img src={m.logo} alt={m.label} className="h-9 w-20 object-contain" />
              <span className="text-sm font-bold text-muted-foreground">{m.label}</span>
            </button>
          );
        })}
      </div>
      <button type="button" className="btn-pay mt-6 h-12 w-full text-base">
        متابعة الدفع
      </button>
    </Shell>
  );
}

function ModelThree() {
  const [value, setValue] = useState("apple-pay");
  return (
    <Shell title="الدفع السريع">
      <div className="flex flex-wrap gap-3">
        {[...methods, ...wallets].map((m) => {
          const active = value === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setValue(m.id)}
              aria-pressed={active}
              className={`flex items-center gap-3 rounded-full border px-5 py-3 text-sm font-bold transition-colors ${
                active
                  ? "border-brand-blue bg-brand-blue/10 text-brand-blue"
                  : "border-input bg-background text-muted-foreground hover:border-brand-blue/40"
              }`}
            >
              <img src={m.logo} alt={m.label} className="h-6 w-12 object-contain" />
              {m.label}
            </button>
          );
        })}
      </div>
      <p className="mt-5 flex items-center gap-2 text-sm text-muted-foreground">
        <ShieldCheck className="h-4 w-4 text-brand-blue" />
        جميع العمليات مشفّرة وآمنة
      </p>
      <button type="button" className="btn-pay mt-5 h-12 w-full text-base">
        ادفع الآن
      </button>
    </Shell>
  );
}

function ModelFour() {
  const [value, setValue] = useState("mada");
  return (
    <Shell title="مراجعة الطلب والدفع">
      <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <RadioGroup value={value} onValueChange={setValue} dir="rtl" className="gap-3">
          {methods.map((m) => (
            <label
              key={m.id}
              htmlFor={`m4-${m.id}`}
              className="flex min-h-16 cursor-pointer items-center gap-4 rounded-xl border border-input bg-background px-4 transition-colors has-[[data-state=checked]]:border-brand-blue has-[[data-state=checked]]:bg-brand-blue/5"
            >
              <RadioGroupItem
                id={`m4-${m.id}`}
                value={m.id}
                aria-label={m.label}
                className="h-5 w-5 border-brand-blue text-brand-blue"
              />
              <m.icon className="h-5 w-5 text-brand-blue" />
              <span className="flex-1 text-sm font-bold text-foreground">{m.label}</span>
              <img src={m.logo} alt={m.label} className="h-7 w-14 object-contain" />
            </label>
          ))}
        </RadioGroup>
        <aside className="rounded-2xl border border-input bg-background p-5">
          <h3 className="mb-4 text-base font-extrabold text-foreground">ملخص الطلب</h3>
          <dl className="space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">قيمة الوثيقة</dt>
              <dd className="font-bold text-foreground">٨٥٠ ر.س</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">ضريبة القيمة المضافة</dt>
              <dd className="font-bold text-foreground">١٢٧٫٥٠ ر.س</dd>
            </div>
            <div className="flex justify-between border-t border-input pt-3">
              <dt className="font-extrabold text-foreground">الإجمالي</dt>
              <dd className="font-extrabold text-brand-blue">٩٧٧٫٥٠ ر.س</dd>
            </div>
          </dl>
          <button type="button" className="btn-pay mt-6 h-12 w-full text-base">
            تأكيد الدفع
          </button>
        </aside>
      </div>
    </Shell>
  );
}

function ModelFive() {
  const [value, setValue] = useState("alinma");
  const groups = [
    { title: "البطاقات", icon: CreditCard, items: methods },
    { title: "المحافظ الرقمية", icon: Wallet, items: wallets },
    { title: "البنوك", icon: Landmark, items: bankList },
  ];
  return (
    <Shell title="كل وسائل الدفع">
      <div className="space-y-7">
        {groups.map((group) => (
          <div key={group.title}>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold text-muted-foreground">
              <group.icon className="h-4 w-4 text-brand-blue" />
              {group.title}
            </h3>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {group.items.map((m) => {
                const active = value === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setValue(m.id)}
                    aria-pressed={active}
                    className={`flex h-24 flex-col items-center justify-center gap-2 rounded-xl border bg-background px-2 transition-colors ${
                      active ? "border-brand-blue bg-brand-blue/5" : "border-input hover:border-brand-blue/40"
                    }`}
                  >
                    <img src={m.logo} alt={m.label} className="h-8 w-16 object-contain" />
                    <span className="truncate text-xs font-bold text-muted-foreground">{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <button type="button" className="btn-pay mt-7 h-12 w-full text-base">
        متابعة
      </button>
    </Shell>
  );
}

function PaymentModels() {
  const [active, setActive] = useState(1);

  return (
    <main dir="rtl" className="min-h-screen w-full bg-background px-4 py-10 sm:px-8 sm:py-14">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-8">
        <header className="text-center">
          <h1 className="text-2xl font-black text-brand-blue sm:text-3xl">خمسة نماذج لواجهة الدفع</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            استعرض النماذج واختر الشكل الذي يناسبك. هذه الصفحة للعرض فقط ولا تُنفّذ أي عملية دفع.
          </p>
        </header>

        <nav className="flex flex-wrap justify-center gap-2">
          {models.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setActive(m.id)}
              aria-pressed={active === m.id}
              className={`rounded-full border px-4 py-2 text-sm font-bold transition-colors ${
                active === m.id
                  ? "border-brand-blue bg-brand-blue text-primary-foreground"
                  : "border-input bg-card text-muted-foreground hover:border-brand-blue/40"
              }`}
            >
              {m.name} · {m.hint}
            </button>
          ))}
        </nav>

        {active === 1 && <ModelOne />}
        {active === 2 && <ModelTwo />}
        {active === 3 && <ModelThree />}
        {active === 4 && <ModelFour />}
        {active === 5 && <ModelFive />}
      </div>
    </main>
  );
}
